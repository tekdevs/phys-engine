from __future__ import annotations
import math
from OpenGL.GL import *
from editor.constants import get_text_tex, FONT_SZ_SM


class UIMixin:
    def _draw_rect(self, x, y, w, h, color, border_color=None):
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_LIGHTING)
        glDisable(GL_BLEND)
        glBegin(GL_QUADS)
        glColor3f(*color)
        glVertex2f(x, y)
        glVertex2f(x + w, y)
        glVertex2f(x + w, y + h)
        glVertex2f(x, y + h)
        glEnd()
        if border_color:
            glColor3f(*border_color)
            glLineWidth(1)
            glBegin(GL_LINE_LOOP)
            glVertex2f(x, y)
            glVertex2f(x + w, y)
            glVertex2f(x + w, y + h)
            glVertex2f(x, y + h)
            glEnd()

    def _draw_text(self, x, y, text, color=(1, 1, 1), size=12):
        tc = (int(color[0]*255), int(color[1]*255), int(color[2]*255), 255)
        tex, tw, th = get_text_tex(text, size, tc)
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glBindTexture(GL_TEXTURE_2D, tex)
        glColor3f(1, 1, 1)
        glBegin(GL_QUADS)
        glTexCoord2f(0, 1); glVertex2f(x, y)
        glTexCoord2f(1, 1); glVertex2f(x + tw, y)
        glTexCoord2f(1, 0); glVertex2f(x + tw, y + th)
        glTexCoord2f(0, 0); glVertex2f(x, y + th)
        glEnd()
        glDisable(GL_BLEND)
        glDisable(GL_TEXTURE_2D)
        return tw, th

    def _ortho_mode(self):
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.width, self.height, 0, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_CULL_FACE)

    def _ortho_end(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)

    def _draw_cursor(self, tx, ty, text, cursor_pos, h=16, sel=None):
        if self._editing_field is None:
            return
        glDisable(GL_TEXTURE_2D)
        if sel is not None:
            s, e = sel
            s, e = min(s, e), max(s, e)
            if s != e:
                sx = tx + get_text_tex(text[:s], FONT_SZ_SM, (255,255,255,255))[1]
                ex = tx + get_text_tex(text[:e], FONT_SZ_SM, (255,255,255,255))[1]
                glColor4f(0.3, 0.5, 0.8, 0.4)
                glEnable(GL_BLEND)
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
                glBegin(GL_QUADS)
                glVertex2f(sx, ty - 1); glVertex2f(ex, ty - 1)
                glVertex2f(ex, ty + h + 1); glVertex2f(sx, ty + h + 1)
                glEnd()
                glDisable(GL_BLEND)
        if int(self._edit_cursor_timer * 2) % 2 == 0 and (sel is None or sel[0] == sel[1]):
            prefix = text[:cursor_pos]
            pw = get_text_tex(prefix, FONT_SZ_SM, (255,255,255,255))[1]
            cx = tx + pw
            opacity = (math.sin(self._edit_cursor_timer * math.pi * 2.5) + 1) * 0.5
            opacity = max(0.15, opacity)
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            glColor4f(0.9, 0.9, 0.9, opacity)
            glLineWidth(2)
            glBegin(GL_LINES)
            glVertex2f(cx, ty); glVertex2f(cx, ty + h)
            glEnd()
            glLineWidth(1)
            glDisable(GL_BLEND)
