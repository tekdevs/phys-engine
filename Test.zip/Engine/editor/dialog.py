from __future__ import annotations
import time
from OpenGL.GL import *
from editor.constants import (
    PANEL_BG, PANEL_DARK, PANEL_BORDER, ACCENT, TEXT_COLOR, TEXT_DIM, FONT_SZ_SM, FONT_SZ_MD,
    get_text_tex,
)


class DialogMixin:
    def _open_dialog(self, title, default="", callback=None, items=None):
        self._dialog_active = True
        self._dialog_title = title
        self._dialog_buffer = default
        self._dialog_cursor = len(default)
        self._dialog_sel = None
        self._dialog_callback = callback
        self._dialog_items = items
        self._dialog_scroll = 0

    def _close_dialog(self):
        self._dialog_active = False
        self._dialog_title = ""
        self._dialog_buffer = ""
        self._dialog_cursor = 0
        self._dialog_callback = None
        self._dialog_items = None

    def render_dialog(self):
        if self._dialog_items is not None:
            dw, dh = 400, 300
        else:
            dw, dh = 360, 150
        dx = (self.width - dw) // 2
        dy = (self.height - dh) // 2
        self._draw_rect(dx, dy, dw, dh, (0.1, 0.1, 0.12), (0.3, 0.3, 0.35))
        self._draw_text(dx + 15, dy + 10, self._dialog_title, TEXT_COLOR, FONT_SZ_SM)
        if self._dialog_items is not None:
            item_h = 22
            list_y = dy + 40
            list_h = dh - 80
            glEnable(GL_SCISSOR_TEST)
            glScissor(dx + 10, self.height - (list_y + list_h), dw - 20, list_h)
            for i, item in enumerate(self._dialog_items):
                iy = list_y + i * item_h - self._dialog_scroll
                if iy < list_y - item_h or iy > list_y + list_h:
                    continue
                bg = (0.18, 0.19, 0.24) if self._dialog_buffer.isdigit() and i == int(self._dialog_buffer) else (0.12, 0.12, 0.15)
                self._draw_rect(dx + 10, iy, dw - 20, item_h, bg, (0.2, 0.2, 0.25))
                self._draw_text(dx + 18, iy + 3, item, TEXT_COLOR, FONT_SZ_SM)
            glDisable(GL_SCISSOR_TEST)
            bar_h = max(20, int(list_h * list_h / (len(self._dialog_items) * item_h)))
            bar_y = list_y + int(self._dialog_scroll / max(len(self._dialog_items) * item_h - list_h, 1) * (list_h - bar_h))
            self._draw_rect(dx + dw - 22, list_y, 10, list_h, (0.06, 0.06, 0.06))
            self._draw_rect(dx + dw - 21, bar_y, 8, bar_h, (0.3, 0.3, 0.35))
        else:
            iy = dy + 50
            field_x = dx + 15
            field_w = dw - 30
            self._draw_rect(field_x, iy, field_w, 26, (0.15, 0.15, 0.18), (0.35, 0.35, 0.4))
            glEnable(GL_SCISSOR_TEST)
            scy = self.height - iy - 26
            glScissor(field_x + 2, scy, field_w - 4, 24)
            if self._dialog_sel is not None:
                s, e = self._dialog_sel
                ss, se = min(s, e), max(s, e)
                if ss != se:
                    x1 = get_text_tex(self._dialog_buffer[:ss], FONT_SZ_MD, (255,255,255,255))[1]
                    x2 = get_text_tex(self._dialog_buffer[:se], FONT_SZ_MD, (255,255,255,255))[1]
                    self._draw_rect(field_x + 6 + x1, iy + 3, x2 - x1, 20, ACCENT)
            self._draw_text(field_x + 6, iy + 5, self._dialog_buffer, ACCENT, FONT_SZ_MD)
            if int(time.time() * 2) % 2 == 0:
                tw = get_text_tex(self._dialog_buffer[:self._dialog_cursor], FONT_SZ_MD, (255,255,255,255))[1]
                cx = field_x + 6 + tw
                self._draw_rect(cx, iy + 4, 1.5, 18, (0.8, 0.8, 0.8))
            glDisable(GL_SCISSOR_TEST)
        btn_y = dy + dh - 35
        btn_w = 60
        ok_x = dx + dw - 140
        cancel_x = dx + dw - 70
        self._draw_rect(ok_x, btn_y, btn_w, 26, (0.2, 0.2, 0.25), PANEL_BORDER)
        ok_tw = get_text_tex("OK", FONT_SZ_SM, (255,255,255,255))[1]
        self._draw_text(ok_x + (btn_w - ok_tw) // 2, btn_y + 5, "OK", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(cancel_x, btn_y, btn_w, 26, (0.2, 0.2, 0.25), PANEL_BORDER)
        can_tw = get_text_tex("Cancel", FONT_SZ_SM, (255,255,255,255))[1]
        self._draw_text(cancel_x + (btn_w - can_tw) // 2, btn_y + 5, "Cancel", TEXT_COLOR, FONT_SZ_SM)

    def _dialog_field_bounds(self):
        if self._dialog_items is not None:
            return None
        dw, dh = 360, 150
        dx = (self.width - dw) // 2
        dy = (self.height - dh) // 2
        iy = dy + 50
        field_x = dx + 15
        field_w = dw - 30
        return field_x, iy, field_w

    def _handle_dialog_click(self, mx, my):
        if self._dialog_items is not None:
            dw, dh = 400, 300
        else:
            dw, dh = 360, 150
        dx = (self.width - dw) // 2
        dy = (self.height - dh) // 2
        btn_y = dy + dh - 35
        btn_w = 60
        ok_x = dx + dw - 140
        cancel_x = dx + dw - 70
        if ok_x <= mx <= ok_x + btn_w and btn_y <= my <= btn_y + 26:
            if self._dialog_items is not None:
                idx = int(self._dialog_buffer)
                if 0 <= idx < len(self._dialog_items) and self._dialog_callback:
                    self._dialog_callback(self._dialog_items[idx])
            else:
                if self._dialog_callback:
                    self._dialog_callback(self._dialog_buffer.strip())
            self._close_dialog()
            return True
        if cancel_x <= mx <= cancel_x + btn_w and btn_y <= my <= btn_y + 26:
            self._close_dialog()
            return True
        if self._dialog_items is not None:
            item_h = 22
            list_y = dy + 40
            list_h = dh - 80
            for i in range(len(self._dialog_items)):
                iy = list_y + i * item_h - self._dialog_scroll
                if dx + 10 <= mx <= dx + dw - 20 and iy <= my <= iy + item_h:
                    self._dialog_buffer = str(i)
                    return True
        else:
            iy = dy + 50
            field_x = dx + 15
            field_w = dw - 30
            if field_x <= mx <= field_x + field_w and iy <= my <= iy + 26:
                for i in range(len(self._dialog_buffer) + 1):
                    tw = get_text_tex(self._dialog_buffer[:i], FONT_SZ_MD, (255,255,255,255))[1]
                    if mx <= field_x + 6 + tw:
                        self._dialog_cursor = i
                        self._dialog_sel = (i, i)
                        return True
                self._dialog_cursor = len(self._dialog_buffer)
                self._dialog_sel = (len(self._dialog_buffer), len(self._dialog_buffer))
        return True
