from __future__ import annotations
import glfw
import time
import os
from OpenGL.GL import *
from OpenGL.GLU import *
from engine import (
    Vector3, SimpleLighting, LightingManager, Skybox, EditorCamera,
    GlobalManagerNode, Gizmo, CubeNode, SphereNode, PlayerSpawnNode, EnemyNode,
)
from editor.ui import UIMixin
from editor.constants import lerp
from editor.panels import PanelsMixin
from editor.material_editor import MaterialEditorMixin
from editor.color_picker import ColorPickerMixin
from editor.asset_panel import AssetPanelMixin
from editor.dialog import DialogMixin
from editor.input_handler import InputMixin
from editor.click_dispatchers import ClickMixin
from editor.scene_ops import SceneOpsMixin
from editor.project import ProjectMixin


class Editor(InputMixin, ClickMixin, PanelsMixin, MaterialEditorMixin,
             ColorPickerMixin, AssetPanelMixin, DialogMixin, SceneOpsMixin,
             ProjectMixin, UIMixin):
    NODE_TYPES = {
        "Cube": CubeNode,
        "Sphere": SphereNode,
        "Enemy": EnemyNode,
        "PlayerSpawn": PlayerSpawnNode,
    }

    def __init__(self, width=1280, height=720):
        self.width = width
        self.height = height
        self.nodes = []
        self.global_manager = GlobalManagerNode()
        self.selected_node = None
        self.selected_nodes = set()
        self._select_anchor = None
        self.camera = EditorCamera()
        self.lighting = LightingManager()
        self.lighting.sun_color = self.global_manager.light_color
        self.lighting.sun_intensity = self.global_manager.light_intensity
        self.lighting.sun_direction = self.global_manager.light_direction
        self.lighting.shadow_strength = self.global_manager.shadow_strength
        self.lighting.ambient_intensity = self.global_manager.ambient_intensity
        self.gizmo = None
        blue = (0.15, 0.25, 0.55)
        self.skybox = Skybox(top_color=blue, horizon_color=blue, ground_color=blue)
        self.running = True
        self.delta_time = 0
        self.last_time = time.time()
        self.mouse_x = 0
        self.mouse_y = 0
        self.right_dragging = False
        self.middle_dragging = False
        self.last_mouse = (0, 0)
        self.show_add_menu = False
        self.dragging_value = None
        self.left_dragging = False
        self.message = ""
        self.message_timer = 0
        self.fps = 0
        self.fps_count = 0
        self.fps_time = 0
        self.expanded_nodes = set()
        self._editing_field = None
        self._edit_buffer = ""
        self._edit_cursor = 0
        self._edit_cursor_timer = 0.0
        self._edit_sel = None
        self._material_edit_sel = None
        self._text_drag_active = False
        self.undo_stack = []
        self.redo_stack = []
        self.max_undo = 50
        self.project_name = ""
        self.project_dir = ""
        self._base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self._node_counter = 0
        self._clipboard = None
        self._hierarchy_scroll = 0
        self._hierarchy_scroll_drag = False
        self._sb_hovered = False
        self._sb_grab_offset = 0.0
        self._sb_x = 0
        self._sb_y = 0
        self._sb_h = 0
        self._sb_w = 0
        self._snap_enabled = False
        self._snap_size = 0.5
        self._color_picker_active = False
        self._color_picker_color = [0.25, 0.45, 0.8]
        self._color_picker_original = [0.25, 0.45, 0.8]
        self._color_picker_callback = None
        self._color_picker_target = "skybox"
        self._dialog_active = False
        self._dialog_title = ""
        self._dialog_buffer = ""
        self._dialog_cursor = 0
        self._dialog_callback = None
        self._dialog_items = None
        self._dialog_scroll = 0
        self._key_repeat_timer = 0.0
        self._key_repeat_delay = 0.4
        self._key_repeat_rate = 0.04
        self._key_repeat_active = False
        self._init_glfw()
        self._init_gl()
        self.tex_cube = self._init_tex() # Fix: Load texture here
        self._init_materials()
        self.gizmo = Gizmo()
        self._resolve_materials()
        self.project_name = "Untitled"
        glfw.set_window_title(self.window, f"Phys Engine - {self.project_name}")
        self.hierarchy_width = 260
        self.inspector_width = 360
        self._border_drag = None
        self._border_drag_start_x = 0
        self._border_drag_start_w = 0
        self.show_file_menu = False
        self.asset_height = 180
        self.asset_min_h = 80
        self._asset_border_drag = False
        self._asset_border_start_y = 0
        self._asset_border_start_h = 0
        self._asset_path = ""
        self._asset_scroll = 0
        self._asset_selected = None
        self._asset_selected_set = set()
        self._asset_select_anchor = None
        self._asset_rename = None
        self._asset_rename_buf = ""
        self._asset_context_menu = None
        self._import_dir = ""
        self._asset_last_click = None
        self._asset_last_click_time = 0.0
        self.asset_tree_width = 150
        self.asset_tree_min = 60
        self._asset_tree_drag = False
        self._asset_tree_drag_start_x = 0
        self._asset_tree_drag_start_w = 0
        self._asset_tree_scroll = 0
        self._asset_tree_selected = ""
        self._hierarchy_context_menu = None
        self._material_dropdown_open = False
        self._asset_mode = "files"
        self._material_edit_field = None
        self._material_edit_buffer = ""
        self._material_edit_cursor = 0
        self._material_edit_cursor_timer = 0.0
        self._tex_dropdown_open = False
        self._hierarchy_scroll_target = 0.0
        self._asset_tree_scroll_target = 0.0
        self._asset_scroll_target = 0.0
        self._panel_resize_speed = 12.0
    
    def _init_tex(self): # Helper to load texture
        from engine.textures import make_tex
        return make_tex((220, 0, 220), (35, 0, 55))

    def _init_glfw(self):
        if not glfw.init():
            raise RuntimeError("Failed to init GLFW")
        glfw.window_hint(glfw.RESIZABLE, glfw.TRUE)
        glfw.window_hint(glfw.SAMPLES, 4)
        self.window = glfw.create_window(self.width, self.height, "Phys Engine", None, None)
        if not self.window:
            glfw.terminate()
            raise RuntimeError("Failed to create window")
        glfw.make_context_current(self.window)
        glfw.swap_interval(1)
        glfw.set_cursor_pos_callback(self.window, self._cursor_callback)
        glfw.set_mouse_button_callback(self.window, self._mouse_callback)
        glfw.set_scroll_callback(self.window, self._scroll_callback)
        glfw.set_key_callback(self.window, self._key_callback)
        glfw.set_window_size_callback(self.window, self._resize_callback)
        glfw.set_char_callback(self.window, self._char_callback)
        self._cursor_arrow = glfw.create_standard_cursor(glfw.ARROW_CURSOR)
        self._cursor_hresize = glfw.create_standard_cursor(glfw.HRESIZE_CURSOR)
        self._cursor_vresize = glfw.create_standard_cursor(glfw.VRESIZE_CURSOR)
        self._cursor_crosshair = glfw.create_standard_cursor(glfw.CROSSHAIR_CURSOR)

    def _init_gl(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)

    def run(self):
        while self.running:
            t = time.time()
            self.delta_time = t - self.last_time
            self.last_time = t
            self.fps_count += 1
            if t - self.fps_time > 1:
                self.fps = self.fps_count
                self.fps_count = 0
                self.fps_time = t
            if self.message_timer > 0:
                self.message_timer -= self.delta_time
            glfw.poll_events()
            if glfw.window_should_close(self.window):
                self.running = False
            if self._editing_field is not None:
                del_held = glfw.get_key(self.window, glfw.KEY_DELETE) == glfw.PRESS
                bsp_held = glfw.get_key(self.window, glfw.KEY_BACKSPACE) == glfw.PRESS
                if del_held or bsp_held:
                    self._key_repeat_timer += self.delta_time
                    if self._key_repeat_timer >= (self._key_repeat_delay if not self._key_repeat_active else self._key_repeat_rate):
                        self._key_repeat_active = True
                        self._key_repeat_timer = 0.0
                        if del_held and self._edit_cursor < len(self._edit_buffer):
                            self._edit_buffer = self._edit_buffer[:self._edit_cursor] + self._edit_buffer[self._edit_cursor+1:]
                            self._edit_cursor_timer = 0.0
                        if bsp_held and self._edit_cursor > 0:
                            self._edit_buffer = self._edit_buffer[:self._edit_cursor-1] + self._edit_buffer[self._edit_cursor:]
                            self._edit_cursor -= 1
                            self._edit_cursor_timer = 0.0
                else:
                    self._key_repeat_active = False
                    self._key_repeat_timer = 0.0
            scroll_speed = min(1.0, self.delta_time * 18)
            self._hierarchy_scroll = lerp(self._hierarchy_scroll, self._hierarchy_scroll_target, scroll_speed)
            self._asset_tree_scroll = lerp(self._asset_tree_scroll, self._asset_tree_scroll_target, scroll_speed)
            self._asset_scroll = lerp(self._asset_scroll, self._asset_scroll_target, scroll_speed)
            if abs(self._hierarchy_scroll - self._hierarchy_scroll_target) < 0.5:
                self._hierarchy_scroll = self._hierarchy_scroll_target
            if abs(self._asset_tree_scroll - self._asset_tree_scroll_target) < 0.5:
                self._asset_tree_scroll = self._asset_tree_scroll_target
            if abs(self._asset_scroll - self._asset_scroll_target) < 0.5:
                self._asset_scroll = self._asset_scroll_target
            if self._editing_field is not None:
                self.render()
                glfw.swap_buffers(self.window)
                continue
            ctrl = glfw.get_key(self.window, glfw.KEY_LEFT_CONTROL) == glfw.PRESS or glfw.get_key(self.window, glfw.KEY_RIGHT_CONTROL) == glfw.PRESS
            keys = {
                glfw.KEY_W: glfw.get_key(self.window, glfw.KEY_W) if not ctrl else 0,
                glfw.KEY_S: glfw.get_key(self.window, glfw.KEY_S) if not ctrl else 0,
                glfw.KEY_A: glfw.get_key(self.window, glfw.KEY_A) if not ctrl else 0,
                glfw.KEY_D: glfw.get_key(self.window, glfw.KEY_D) if not ctrl else 0,
                glfw.KEY_LEFT_SHIFT: glfw.get_key(self.window, glfw.KEY_LEFT_SHIFT),
            }
            arrow_delta = None
            if not ctrl:
                ax = 0
                ay = 0
                if glfw.get_key(self.window, glfw.KEY_LEFT) == glfw.PRESS: ax -= 1
                if glfw.get_key(self.window, glfw.KEY_RIGHT) == glfw.PRESS: ax += 1
                if glfw.get_key(self.window, glfw.KEY_UP) == glfw.PRESS: ay -= 1
                if glfw.get_key(self.window, glfw.KEY_DOWN) == glfw.PRESS: ay += 1
                if ax != 0 or ay != 0:
                    arrow_delta = (ax, ay)
            mouse_delta = None
            if self._border_drag:
                if self.left_dragging:
                    dx = self.mouse_x - self._border_drag_start_x
                    if self._border_drag == "hierarchy":
                        self.hierarchy_width = int(max(150, min(self.width - 300, self._border_drag_start_w + dx)))
                    elif self._border_drag == "inspector":
                        self.inspector_width = int(max(150, min(self.width - 300, self._border_drag_start_w - dx)))
                else:
                    self._border_drag = None
            if self._asset_border_drag:
                if self.left_dragging:
                    self._handle_asset_border_drag(self.mouse_x, self.mouse_y)
                else:
                    self._asset_border_drag = False
            if self._asset_tree_drag:
                if self.left_dragging:
                    self._handle_asset_tree_drag(self.mouse_x, self.mouse_y)
                else:
                    self._asset_tree_drag = False
            if self._color_picker_active and self.left_dragging:
                self._handle_color_picker_drag(self.mouse_x, self.mouse_y)
            if not self._dialog_active and not self._hierarchy_scroll_drag and (self.right_dragging or self.middle_dragging):
                dx = self.mouse_x - self.last_mouse[0]
                dy = self.mouse_y - self.last_mouse[1]
                mouse_delta = (dx, dy)
            if not self._dialog_active and not self._hierarchy_scroll_drag:
                self.camera.update(keys, self.delta_time, self.right_dragging, mouse_delta, arrow_delta=arrow_delta)
            if glfw.get_key(self.window, glfw.KEY_DELETE) == glfw.PRESS and self._editing_field is None and not self._hierarchy_scroll_drag and not self._dialog_active and not self._material_edit_field:
                if self._asset_mode == "materials" and self._asset_selected:
                    self._delete_material(self._asset_selected)
                    self._asset_selected = None
                    self._selected_material_name = None
                elif self._asset_selected_set:
                    root = self._asset_root_dir()
                    base = os.path.join(root, self._asset_path) if self._asset_path else root
                    deleted = []
                    for sel in list(self._asset_selected_set):
                        fp = os.path.join(base, sel)
                        if os.path.isdir(fp):
                            import shutil
                            shutil.rmtree(fp, ignore_errors=True)
                            deleted.append(sel + "/")
                        elif os.path.isfile(fp):
                            os.remove(fp)
                            deleted.append(sel)
                    for dname in deleted:
                        rel = (self._asset_path + "/" + dname).lstrip("/") if self._asset_path else dname
                        for mat in self.materials.values():
                            if mat.albedo_texture == rel or mat.albedo_texture == dname:
                                mat.cleanup_tex()
                                mat.albedo_texture = ""
                    self._asset_selected = None
                    self._asset_selected_set.clear()
                elif self.selected_node:
                    self._delete_selected()
            if self.gizmo.drag_axis is not None and self.left_dragging and self.selected_node:
                origin, direction = self._screen_to_ray(self.mouse_x, self.mouse_y)
                if origin:
                    rot = self.selected_node.rot
                    delta = self.gizmo.update_drag(origin, direction,
                        self.selected_node.get_world_pos(), self.gizmo.drag_axis, rot=rot)
                    if self.gizmo.mode == "translate":
                        base_axes = [Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1)]
                        rotated = self.gizmo._rotate_axes([(a, None) for a in base_axes], rot)
                        axis_dir = rotated[self.gizmo.drag_axis][0]
                        if self._snap_enabled:
                            orig = self._snap_drag_start.get(id(self.selected_node), self.selected_node.pos)
                            _, _, t_ax = self.gizmo.ray_axis_distance(origin, direction, orig, axis_dir)
                            orig_t = self._snap_drag_start.get("_t", t_ax)
                            total_delta = t_ax - orig_t
                            snapped = round(total_delta / self._snap_size) * self._snap_size
                            for sel in self.selected_nodes:
                                sel.pos = orig + axis_dir * snapped
                        else:
                            for sel in self.selected_nodes:
                                sel.pos = sel.pos + axis_dir * delta
                    elif self.gizmo.mode == "scale":
                        for sel in self.selected_nodes:
                            self._apply_scale(sel, self.gizmo.drag_axis, delta)
                    elif self.gizmo.mode == "rotate":
                        for sel in self.selected_nodes:
                            if self.gizmo.drag_axis == 0:
                                sel.rot.x += delta
                            elif self.gizmo.drag_axis == 1:
                                sel.rot.y += delta
                            else:
                                sel.rot.z += delta
            elif not self.left_dragging and not self.right_dragging and self.selected_node:
                origin, direction = self._screen_to_ray(self.mouse_x, self.mouse_y)
                if origin:
                    gs = (self.selected_node.get_world_pos() - self.camera.pos).length() * 0.06
                    hover_rot = self.selected_node.rot
                    self.gizmo.hit_test(origin, direction, self.selected_node.get_world_pos(), max(0.5, min(3.0, gs)) * 1.3, rot=hover_rot)
            if self._material_edit_field is not None:
                self._material_edit_cursor_timer += self.delta_time
            if self._editing_field is not None:
                self._edit_cursor_timer += self.delta_time
            if self._hierarchy_scroll_drag and self.left_dragging:
                pw = self.hierarchy_width
                ph = self.height - 40 - 24
                content_top = 42
                content_h = ph - 42
                item_h = 22
                total = len(self.nodes)
                visible_count = int(content_h / item_h)
                max_scroll = max(0, (total - visible_count) * item_h)
                bar_h = max(30, int(content_h * visible_count / total)) if total > visible_count else content_h
                track_h = content_h - bar_h
                new_y = self.mouse_y - self._sb_grab_offset
                new_y = max(content_top, min(content_top + track_h, new_y))
                if track_h > 0:
                    self._hierarchy_scroll = (new_y - content_top) / track_h * max_scroll
                    self._hierarchy_scroll = max(0, min(max_scroll, self._hierarchy_scroll))
                    self._hierarchy_scroll_target = self._hierarchy_scroll
                glfw.set_cursor(self.window, self._cursor_arrow)
            elif self._hierarchy_scroll_drag and not self.left_dragging:
                self._hierarchy_scroll_drag = False
                glfw.set_cursor(self.window, None)
            self._sb_hovered = False
            if not self._hierarchy_scroll_drag:
                mx2, my2 = glfw.get_cursor_pos(self.window)
                mx2, my2 = int(mx2), int(my2)
                pw = self.hierarchy_width
                ph = self.height - 40 - 24
                content_top = 42
                content_h = ph - 42
                item_h = 22
                total = len(self.nodes)
                visible_count = int(content_h / item_h)
                if total > visible_count and pw - 15 <= mx2 <= pw - 3 and content_top <= my2 <= content_top + content_h:
                    self._sb_hovered = True
            self.last_mouse = (self.mouse_x, self.mouse_y)
            self.render()
            glfw.swap_buffers(self.window)

    def render(self):
        self.render_scene()
        self._ortho_mode()
        self.render_toolbar()
        self.render_hierarchy()
        self.render_inspector()
        self.render_asset_panel()
        self.render_status_bar()
        self.render_file_menu()
        if self._color_picker_active:
            self._render_color_picker_dialog()
        elif self._dialog_active:
            self.render_dialog()
        self._ortho_end()
