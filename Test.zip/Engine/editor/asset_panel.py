from __future__ import annotations
import os
import sys
import time
import subprocess
import glfw
from OpenGL.GL import *
from editor.constants import (
    PANEL_BG, PANEL_DARK, PANEL_BORDER, ACCENT, TEXT_COLOR, TEXT_DIM, FONT_SZ_SM,
    get_text_tex,
)


class AssetPanelMixin:
    def _asset_root_dir(self):
        if self.project_dir:
            return os.path.join(self.project_dir, "assets")
        return ""

    def _asset_ensure_dirs(self):
        root = self._asset_root_dir()
        os.makedirs(root, exist_ok=True)

    def _asset_list(self, rel=""):
        root = self._asset_root_dir()
        full = os.path.join(root, rel)
        if not os.path.isdir(full):
            return [], []
        folders = []
        files = []
        for name in sorted(os.listdir(full)):
            fp = os.path.join(full, name)
            if os.path.isdir(fp):
                folders.append(name)
            else:
                files.append(name)
        return folders, files

    def _collect_images(self):
        root = self._asset_root_dir()
        if not root or not os.path.isdir(root):
            return []
        imgs = []
        exts = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga")
        for dirpath, _, filenames in os.walk(root):
            for fn in sorted(filenames):
                if os.path.splitext(fn)[1].lower() in exts:
                    full = os.path.join(dirpath, fn)
                    rel = os.path.relpath(full, root).replace("\\", "/")
                    imgs.append(rel)
        return imgs

    def _asset_color(self, name, is_dir):
        if is_dir:
            return (0.90, 0.75, 0.28)
        ext = os.path.splitext(name)[1].lower()
        if ext in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga"):
            return (0.42, 0.78, 0.52)
        if ext in (".mp4", ".avi", ".mov", ".mkv", ".webm"):
            return (0.58, 0.52, 0.88)
        if ext in (".wav", ".mp3", ".ogg", ".flac"):
            return (0.88, 0.58, 0.32)
        if ext in (".py", ".js", ".cpp", ".c", ".h", ".cs"):
            return (0.40, 0.62, 0.92)
        return (0.55, 0.55, 0.58)

    def _draw_folder_icon(self, cx, cy, size, color):
        w = size
        h = int(size * 0.75)
        tab = int(w * 0.35)
        tab_h = int(h * 0.28)
        r, g, b = color
        glColor3f(r * 0.55, g * 0.55, b * 0.55)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy)
        glVertex2f(cx + w, cy)
        glVertex2f(cx + w, cy + h)
        glVertex2f(cx, cy + h)
        glEnd()
        glColor3f(r, g, b)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy + tab_h)
        glVertex2f(cx + tab, cy + tab_h)
        glVertex2f(cx + tab, cy)
        glVertex2f(cx, cy)
        glEnd()
        glColor3f(r * 0.82, g * 0.82, b * 0.82)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy + tab_h)
        glVertex2f(cx + w, cy + tab_h)
        glVertex2f(cx + w, cy + h)
        glVertex2f(cx, cy + h)
        glEnd()

    def _draw_file_icon(self, cx, cy, size, color):
        w = int(size * 0.7)
        h = size
        fold = int(size * 0.22)
        r, g, b = color
        glColor3f(r * 0.45, g * 0.45, b * 0.45)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy)
        glVertex2f(cx + w, cy)
        glVertex2f(cx + w, cy + h)
        glVertex2f(cx, cy + h)
        glEnd()
        glColor3f(r, g, b)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy + h - fold)
        glVertex2f(cx + fold, cy + h)
        glVertex2f(cx + w, cy + h)
        glVertex2f(cx + w, cy + h - fold)
        glEnd()
        glColor3f(r * 0.65, g * 0.65, b * 0.65)
        glBegin(GL_QUADS)
        glVertex2f(cx, cy)
        glVertex2f(cx + w, cy)
        glVertex2f(cx + w, cy + h - fold)
        glVertex2f(cx, cy + h - fold)
        glEnd()

    def _draw_asset_icon(self, cx, cy, size, name, is_dir):
        ic = self._asset_color(name, is_dir)
        if is_dir:
            self._draw_folder_icon(cx, cy, size, ic)
        else:
            self._draw_file_icon(cx, cy, size, ic)

    def _asset_truncate(self, text, max_w, font_size=FONT_SZ_SM):
        if get_text_tex(text, font_size, (255,255,255,255))[1] <= max_w:
            return text
        for i in range(len(text) - 1, 0, -1):
            if get_text_tex(text[:i] + "...", font_size, (255,255,255,255))[1] <= max_w:
                return text[:i] + "..."
        return "..."

    def render_asset_panel(self):
        y = self.height - 24 - self.asset_height
        bh = self.asset_height
        tw = self.asset_tree_width
        self._draw_rect(0, y, self.width, bh, PANEL_BG, PANEL_BORDER)

        self._draw_rect(0, y, self.width, 2, (0.22, 0.22, 0.26), PANEL_BORDER)

        tb_h = 28
        tb_y = y + bh - tb_h
        self._draw_rect(0, tb_y, self.width, tb_h, PANEL_DARK, PANEL_BORDER)

        parts = self._asset_path.split("/") if self._asset_path else []
        bc_x = 10
        bc_y = tb_y + 7
        self._draw_text(bc_x, bc_y, "Assets", ACCENT, FONT_SZ_SM)
        tw2 = get_text_tex("Assets", FONT_SZ_SM, (255,255,255,255))[1]
        self._asset_bc_targets = [(bc_x, bc_y - 4, tw2, 18, "")]
        bc_x += tw2 + 2
        for i, p in enumerate(parts):
            self._draw_text(bc_x, bc_y, " > ", TEXT_DIM, FONT_SZ_SM)
            bc_x += 18
            self._draw_text(bc_x, bc_y, p, ACCENT, FONT_SZ_SM)
            pw2 = get_text_tex(p, FONT_SZ_SM, (255,255,255,255))[1]
            path_so_far = "/".join(parts[:i+1])
            self._asset_bc_targets.append((bc_x, bc_y - 4, pw2, 18, path_so_far))
            bc_x += pw2 + 4

        self._draw_rect(tw, y, 2, bh - tb_h, (0.22, 0.22, 0.26), PANEL_BORDER)

        tree_item_h = 20
        tree_pad = 4
        tree_top = y + 2
        tree_vis = bh - tb_h - 4
        glEnable(GL_SCISSOR_TEST)
        glScissor(tw + 2, self.height - (tree_top + tree_vis), self.width - tw - 4, tree_vis)
        if self._asset_mode == "materials":
            mat_names = sorted(self.materials.keys())
            row_idx = 0
            for mname in mat_names:
                ty = tree_top + row_idx * tree_item_h - self._asset_tree_scroll
                if ty + tree_item_h < tree_top or ty > tree_top + tree_vis:
                    row_idx += 1
                    continue
                is_sel = self._asset_selected == mname
                is_multi = mname in self._asset_selected_set
                mat_hover = (tw + 2 <= self.mouse_x <= self.width - 2 and ty <= self.mouse_y <= ty + tree_item_h)
                if is_sel:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.20, 0.28, 0.44), (0.32, 0.38, 0.58))
                elif is_multi:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.14, 0.18, 0.30))
                elif mat_hover:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.10, 0.14, 0.24))
                elif int((ty - tree_top) / tree_item_h) % 2 == 0:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.09, 0.09, 0.11))
                mat = self.materials[mname]
                mat_r, mat_g, mat_b = mat.albedo_color
                sw = 12
                self._draw_rect(tw + 4, ty + 4, sw, 12, (mat_r, mat_g, mat_b), (0.4, 0.4, 0.4))
                label_x = tw + 20
                max_label_w = self.width - tw - 26
                label = self._asset_truncate(mname, max_label_w)
                self._draw_text(label_x, ty + 3, label, TEXT_COLOR if is_sel else TEXT_DIM, FONT_SZ_SM)
                tx_x = tw + max_label_w
                if mat.albedo_texture:
                    self._draw_text(tx_x - 70, ty + 3, "[T]", (0.42, 0.78, 0.52), FONT_SZ_SM)
                row_idx += 1
            if row_idx == 0:
                self._draw_text(tw + 20, tree_top + 10, "No materials...", TEXT_DIM, FONT_SZ_SM)
            glDisable(GL_SCISSOR_TEST)
            tree_total = len(mat_names)
            tree_max_scroll = max(0, tree_total * tree_item_h - tree_vis)
            self._asset_tree_scroll = max(0, min(self._asset_tree_scroll, tree_max_scroll))
        else:
            folders, files = self._asset_list(self._asset_path)
            all_items = [(f, True) for f in folders] + [(f, False) for f in files]
            row_idx = 0
            for name, is_dir in all_items:
                ty = tree_top + row_idx * tree_item_h - self._asset_tree_scroll
                if ty + tree_item_h < tree_top or ty > tree_top + tree_vis:
                    row_idx += 1
                    continue
                is_sel = self._asset_selected == name
                is_multi = name in self._asset_selected_set
                item_hover = (tw + 2 <= self.mouse_x <= self.width - 2 and ty <= self.mouse_y <= ty + tree_item_h)
                if is_sel:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.20, 0.28, 0.44), (0.32, 0.38, 0.58))
                elif is_multi:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.14, 0.18, 0.30))
                elif item_hover:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.10, 0.14, 0.24))
                elif int((ty - tree_top) / tree_item_h) % 2 == 0:
                    self._draw_rect(tw + 2, ty, self.width - tw - 4, tree_item_h, (0.09, 0.09, 0.11))
                ic = self._asset_color(name, is_dir)
                icon_sz = 12
                ix = tw + 6
                iy2 = ty + (tree_item_h - icon_sz) // 2
                if is_dir:
                    self._draw_folder_icon(ix, iy2, icon_sz, ic)
                else:
                    self._draw_file_icon(ix, iy2, icon_sz, ic)
                label_x = tw + 22
                max_label_w = self.width - tw - 28
                label = self._asset_truncate(name, max_label_w)
                self._draw_text(label_x, ty + 3, label, TEXT_COLOR if is_sel else TEXT_DIM, FONT_SZ_SM)
                row_idx += 1
            if row_idx == 0:
                self._draw_text(tw + 20, tree_top + 10, "No assets...", TEXT_DIM, FONT_SZ_SM)
            glDisable(GL_SCISSOR_TEST)
            tree_total = len(all_items)
            tree_max_scroll = max(0, tree_total * tree_item_h - tree_vis)
            self._asset_tree_scroll = max(0, min(self._asset_tree_scroll, tree_max_scroll))

        glEnable(GL_SCISSOR_TEST)
        glScissor(2, self.height - (tree_top + tree_vis), tw - 4, tree_vis)
        self._draw_rect(2, tree_top, tw - 4, tree_vis, (0.08, 0.08, 0.10))
        counter = [0]
        ty_root = tree_top + counter[0] * tree_item_h - self._asset_tree_scroll
        if ty_root + tree_item_h >= tree_top and ty_root <= tree_top + tree_vis:
            is_sel_root = self._asset_tree_selected == ""
            tree_item_hover = (2 <= self.mouse_x <= tw - 2 and ty_root <= self.mouse_y <= ty_root + tree_item_h)
            if is_sel_root:
                self._draw_rect(2, ty_root, tw - 4, tree_item_h, (0.20, 0.28, 0.44))
            elif tree_item_hover:
                self._draw_rect(2, ty_root, tw - 4, tree_item_h, (0.10, 0.14, 0.24))
            self._draw_folder_icon(8, ty_root + (tree_item_h - 12) // 2, 12, (0.90, 0.75, 0.28))
            self._draw_text(24, ty_root + 3, "Assets", TEXT_COLOR if is_sel_root else TEXT_DIM, FONT_SZ_SM)
        counter[0] += 1
        def _tree_draw(rel, depth, name_prefix):
            folders2, _ = self._asset_list(rel)
            for fn in folders2:
                ty = tree_top + counter[0] * tree_item_h - self._asset_tree_scroll
                full_label = (name_prefix + "/" + fn) if name_prefix else fn
                if ty + tree_item_h >= tree_top and ty <= tree_top + tree_vis:
                    indent = 8 + depth * 14
                    is_sel = self._asset_tree_selected == full_label
                    folder_hover = (2 <= self.mouse_x <= tw - 2 and ty <= self.mouse_y <= ty + tree_item_h)
                    if is_sel:
                        self._draw_rect(2, ty, tw - 4, tree_item_h, (0.20, 0.28, 0.44))
                    elif folder_hover:
                        self._draw_rect(2, ty, tw - 4, tree_item_h, (0.10, 0.14, 0.24))
                    iw = max(20, tw - indent - 8)
                    label = self._asset_truncate(fn, iw)
                    ic = self._asset_color(fn, True)
                    icon_sz2 = 12
                    ix2 = indent
                    iy3 = ty + (tree_item_h - icon_sz2) // 2
                    self._draw_folder_icon(ix2, iy3, icon_sz2, ic)
                    self._draw_text(indent + 16, ty + 3, label, TEXT_COLOR if is_sel else TEXT_DIM, FONT_SZ_SM)
                counter[0] += 1
                _tree_draw(full_label, depth + 1, full_label)
        _tree_draw("", 1, "")
        mat_root_y = tree_top + counter[0] * tree_item_h - self._asset_tree_scroll
        if mat_root_y + tree_item_h >= tree_top and mat_root_y <= tree_top + tree_vis:
            is_mat_sel = self._asset_tree_selected == "__materials__"
            mat_root_hover = (2 <= self.mouse_x <= tw - 2 and mat_root_y <= self.mouse_y <= mat_root_y + tree_item_h)
            if is_mat_sel:
                self._draw_rect(2, mat_root_y, tw - 4, tree_item_h, (0.20, 0.28, 0.44))
            elif mat_root_hover:
                self._draw_rect(2, mat_root_y, tw - 4, tree_item_h, (0.10, 0.14, 0.24))
            self._draw_folder_icon(8, mat_root_y + (tree_item_h - 12) // 2, 12, (0.55, 0.55, 0.85))
            self._draw_text(24, mat_root_y + 3, "Materials", TEXT_COLOR if is_mat_sel else TEXT_DIM, FONT_SZ_SM)
        counter[0] += 1
        glDisable(GL_SCISSOR_TEST)

        if self._asset_context_menu:
            mx2, my2, items = self._asset_context_menu
            mw = 140
            mh2 = len(items) * 24 + 8
            if mx2 + mw > self.width:
                mx2 = self.width - mw - 4
            if my2 + mh2 > y + bh:
                my2 = y + bh - mh2 - 4
            self._draw_rect(mx2, my2, mw, mh2, PANEL_BG, PANEL_BORDER)
            for ii, (label, cb) in enumerate(items):
                iy = my2 + 4 + ii * 24
                cm_hover = (mx2 + 4 <= self.mouse_x <= mx2 + mw - 4 and iy <= self.mouse_y <= iy + 20)
                self._draw_rect(mx2 + 4, iy, mw - 8, 20, (0.14, 0.18, 0.28) if cm_hover else (0.10, 0.10, 0.14), PANEL_BORDER)
                self._draw_text(mx2 + 12, iy + 3, label, ACCENT if cm_hover else TEXT_COLOR, FONT_SZ_SM)

    def _handle_asset_click(self, mx, my):
        y = self.height - 24 - self.asset_height
        bh = self.asset_height
        tb_h = 28
        tb_y = y + bh - tb_h
        tw = self.asset_tree_width

        if self._asset_context_menu:
            cmx, cmy, items = self._asset_context_menu
            cmw = 140
            cmh = len(items) * 24 + 8
            y = self.height - 24 - self.asset_height
            bh = self.asset_height
            if cmx + cmw > self.width:
                cmx = self.width - cmw - 4
            if cmy + cmh > y + bh:
                cmy = y + bh - cmh - 4
            for ii, (label, cb) in enumerate(items):
                iy = cmy + 4 + ii * 24
                if cmx + 4 <= mx <= cmx + cmw - 4 and iy <= my <= iy + 20:
                    cb()
                    self._asset_context_menu = None
                    return True
            self._asset_context_menu = None
            return True

        if my < y or my > y + bh:
            return False

        self._select_node(None)
        self._asset_context_menu = None

        if my >= tb_y:
            if hasattr(self, '_asset_bc_targets'):
                for bx, by, bw, bh2, path in self._asset_bc_targets:
                    if bx <= mx <= bx + bw and by <= my <= by + bh2:
                        self._asset_path = path
                        self._asset_scroll = 0
                        self._asset_tree_scroll = 0
                        self._asset_selected = None
                        self._asset_tree_selected = path
                        self._asset_mode = "files"
                        return True
            return True
            return True

        if mx < tw:
            self._asset_tree_click(mx, my)
            return True

        tree_item_h = 20
        tree_top = y + 2
        now = time.time()

        if self._asset_mode == "materials":
            mat_names = sorted(self.materials.keys())
            row_idx = 0
            for mname in mat_names:
                ty = tree_top + row_idx * tree_item_h - self._asset_tree_scroll
                if tw + 2 <= mx <= self.width and ty <= my <= ty + tree_item_h:
                    self._asset_selected = mname
                    self._asset_selected_set.clear()
                    self._selected_material_name = mname
                    return True
                row_idx += 1
            return True

        folders, files = self._asset_list(self._asset_path)
        all_items = [(f, True) for f in folders] + [(f, False) for f in files]
        row_idx = 0
        for name, is_dir in all_items:
            ty = tree_top + row_idx * tree_item_h - self._asset_tree_scroll
            if tw + 2 <= mx <= self.width and ty <= my <= ty + tree_item_h:
                if self._asset_rename == name:
                    return True
                is_double = (self._asset_last_click == name and
                             now - self._asset_last_click_time < 0.35)
                self._asset_last_click = name
                self._asset_last_click_time = now
                if is_double and is_dir:
                    if self._asset_path:
                        self._asset_path += "/" + name
                    else:
                        self._asset_path = name
                    self._asset_scroll = 0
                    self._asset_tree_scroll = 0
                    self._asset_selected = None
                    self._asset_tree_selected = self._asset_path
                    self._asset_last_click = None
                    self._asset_mode = "files"
                elif is_double and not is_dir:
                    root = self._asset_root_dir()
                    full = os.path.join(root, self._asset_path, name) if self._asset_path else os.path.join(root, name)
                    try:
                        if os.name == 'nt':
                            os.startfile(full)
                        elif sys.platform == 'darwin':
                            subprocess.call(('open', full))
                        else:
                            subprocess.call(('xdg-open', full))
                    except Exception as e:
                        self._set_message(f"Cannot open: {e}")
                else:
                    shift = glfw.get_key(self.window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
                    ctrl = glfw.get_key(self.window, glfw.KEY_LEFT_CONTROL) == glfw.PRESS
                    if ctrl:
                        if name in self._asset_selected_set:
                            self._asset_selected_set.discard(name)
                        else:
                            self._asset_selected_set.add(name)
                        self._asset_selected = name
                        self._asset_select_anchor = name
                    elif shift and self._asset_select_anchor:
                        folders2, files2 = self._asset_list(self._asset_path)
                        all_names = folders2 + files2
                        try:
                            a = all_names.index(self._asset_select_anchor)
                            b = all_names.index(name)
                            lo, hi = min(a, b), max(a, b)
                            self._asset_selected_set = set(all_names[lo:hi+1])
                        except ValueError:
                            self._asset_selected_set = {name}
                        self._asset_selected = name
                    else:
                        self._asset_selected_set = {name}
                        self._asset_selected = name
                        self._asset_select_anchor = name
                        if self._selected_material_name and not is_dir:
                            ext = os.path.splitext(name)[1].lower()
                            if ext in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga"):
                                mat = self.materials.get(self._selected_material_name)
                                if mat:
                                    root = self._asset_root_dir()
                                    rel = os.path.join(self._asset_path, name) if self._asset_path else name
                                    mat.albedo_texture = rel.replace("\\", "/")
                                    mat.load_texture(root)
                                    self._set_message(f"Assigned '{name}' to material")
                    self._asset_tree_selected = (self._asset_path + "/" + name) if self._asset_path else name
                return True
            row_idx += 1

        self._asset_selected = None
        self._asset_selected_set.clear()
        self._asset_tree_selected = ""
        return True

    def _asset_tree_click(self, mx, my):
        y = self.height - 24 - self.asset_height
        bh = self.asset_height
        tb_h = 28
        tw = self.asset_tree_width
        tree_item_h = 20
        tree_top = y + 2

        ty_root = tree_top - self._asset_tree_scroll
        if 2 <= mx <= tw - 2 and ty_root <= my <= ty_root + tree_item_h:
            full_label = ""
            is_double = (self._asset_last_click == full_label and
                         time.time() - self._asset_last_click_time < 0.35)
            self._asset_last_click = full_label
            self._asset_last_click_time = time.time()
            if is_double:
                self._asset_path = full_label
                self._asset_tree_scroll = 0
                self._asset_tree_selected = full_label
                self._asset_last_click = None
            else:
                self._asset_tree_selected = full_label
                self._asset_selected = None
            self._asset_mode = "files"
            return True

        counter = [1]
        def _find(rel, depth, name_prefix):
            folders2, _ = self._asset_list(rel)
            for fn in folders2:
                ty = tree_top + counter[0] * tree_item_h - self._asset_tree_scroll
                full_label = (name_prefix + "/" + fn) if name_prefix else fn
                if 2 <= mx <= tw - 2 and ty <= my <= ty + tree_item_h:
                    is_double = (self._asset_last_click == full_label and
                                 time.time() - self._asset_last_click_time < 0.35)
                    self._asset_last_click = full_label
                    self._asset_last_click_time = time.time()
                    if is_double:
                        self._asset_path = full_label
                        self._asset_tree_scroll = 0
                        self._asset_tree_selected = full_label
                        self._asset_last_click = None
                    else:
                        self._asset_tree_selected = full_label
                        self._asset_selected = None
                    self._asset_mode = "files"
                    return True
                counter[0] += 1
                if _find(full_label, depth + 1, full_label):
                    return True
            return False
        _find("", 1, "")
        mat_idx = 1 + self._count_tree_items("")
        mat_ty = tree_top + mat_idx * tree_item_h - self._asset_tree_scroll
        if 2 <= mx <= tw - 2 and mat_ty <= my <= mat_ty + tree_item_h:
            self._asset_last_click = "__materials__"
            self._asset_last_click_time = time.time()
            self._asset_tree_selected = "__materials__"
            self._asset_selected = None
            self._asset_mode = "materials"
            self._asset_path = ""
            return True

    def _handle_asset_tree_click_border(self, mx, my):
        y = self.height - 24 - self.asset_height
        bh = self.asset_height
        tw = self.asset_tree_width
        if abs(mx - tw) < 4 and my >= y and my <= y + bh - 28:
            self._asset_tree_drag = True
            self._asset_tree_drag_start_x = mx
            self._asset_tree_drag_start_w = tw
            return True
        return False

    def _handle_asset_tree_drag(self, mx, my):
        if self._asset_tree_drag:
            dx = mx - self._asset_tree_drag_start_x
            self.asset_tree_width = int(max(self.asset_tree_min,
                                            min(self.width // 2, self._asset_tree_drag_start_w + dx)))
            return True
        return False

    def _handle_asset_right_click(self, mx, my):
        y = self.height - 24 - self.asset_height
        bh = self.asset_height
        if my < y or my > y + bh:
            return False

        if self._asset_mode == "materials":
            def _new_mat_cb():
                base = "NewMaterial"
                n = 1
                while base in self.materials:
                    base = f"NewMaterial{n}"
                    n += 1
                self._add_material(base)
                self._selected_material_name = base
                self._asset_selected = base
            def _dup_cb():
                if self._asset_selected:
                    self._duplicate_material(self._asset_selected)
                    self._asset_selected = None
            def _rename_cb():
                if self._asset_selected:
                    self._open_dialog("Rename Material", self._asset_selected, callback=self._asset_mat_rename)
            def _delete_cb():
                if self._asset_selected:
                    self._delete_material(self._asset_selected)
                    self._asset_selected = None
                    if self._selected_material_name == self._asset_selected:
                        self._selected_material_name = None
            items = [("New Material", _new_mat_cb)]
            if self._asset_selected:
                items.append(("Duplicate", _dup_cb))
                items.append(("Rename", _rename_cb))
                items.append(("Delete", _delete_cb))
            self._asset_context_menu = (mx, my, items)
            return True

        root = self._asset_root_dir()
        full = os.path.join(root, self._asset_path) if self._asset_path else root

        def _new_folder_cb():
            self._open_dialog("New Folder Name", "", callback=self._asset_create_folder)

        def _rename_cb():
            if self._asset_selected:
                self._open_dialog("Rename", self._asset_selected, callback=self._asset_rename_finish)

        def _import_cb():
            self._do_asset_import()

        def _delete_cb():
            root = self._asset_root_dir()
            base = os.path.join(root, self._asset_path) if self._asset_path else root
            targets = list(self._asset_selected_set) if self._asset_selected_set else ([self._asset_selected] if self._asset_selected else [])
            for sel in targets:
                fp = os.path.join(base, sel)
                if os.path.isdir(fp):
                    import shutil
                    shutil.rmtree(fp, ignore_errors=True)
                elif os.path.isfile(fp):
                    os.remove(fp)
            self._asset_selected = None
            self._asset_selected_set.clear()

        items = [("New Folder", _new_folder_cb), ("Import...", _import_cb)]
        if self._asset_selected:
            items.append(("Rename", _rename_cb))
            items.append(("Delete", _delete_cb))
        elif self._asset_selected_set:
            items.append(("Delete", _delete_cb))
        self._asset_context_menu = (mx, my, items)
        return True

    def _asset_mat_rename(self, new_name):
        new_name = new_name.strip()
        if new_name and new_name != self._asset_selected and new_name not in self.materials:
            old_name = self._asset_selected
            self.materials[new_name] = self.materials.pop(old_name)
            self.materials[new_name].name = new_name
            for node in self.nodes:
                if hasattr(node, 'material_name') and node.material_name == old_name:
                    node.material_name = new_name
            self._selected_material_name = new_name
            self._asset_selected = new_name
            self._resolve_materials()

    def _asset_rename_finish(self, new_name):
        new_name = new_name.strip()
        if new_name and new_name != self._asset_selected:
            root = self._asset_root_dir()
            base = os.path.join(root, self._asset_path) if self._asset_path else root
            old_path = os.path.join(base, self._asset_selected)
            new_path = os.path.join(base, new_name)
            if os.path.exists(old_path) and not os.path.exists(new_path):
                os.rename(old_path, new_path)
                self._asset_selected = new_name

    def _asset_create_folder(self, name):
        name = name.strip()
        if not name:
            return
        root = self._asset_root_dir()
        base = os.path.join(root, self._asset_path) if self._asset_path else root
        path = os.path.join(base, name)
        os.makedirs(path, exist_ok=True)
        self._asset_selected = name

    def _do_asset_import(self):
        self._import_dir = os.path.join(self._asset_root_dir(), self._asset_path) if self._asset_path else self._asset_root_dir()
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            paths = filedialog.askopenfilenames(
                title="Import Assets",
                initialdir=self._import_dir if os.path.isdir(self._import_dir) else None,
                filetypes=[
                    ("All Files", "*.*"),
                    ("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.tga"),
                    ("Videos", "*.mp4 *.avi *.mov *.mkv *.webm"),
                    ("Audio", "*.wav *.mp3 *.ogg *.flac"),
                ]
            )
            root.destroy()
            if paths:
                import shutil
                dest_dir = self._import_dir
                os.makedirs(dest_dir, exist_ok=True)
                for p in paths:
                    shutil.copy2(p, os.path.join(dest_dir, os.path.basename(p)))
                self._set_message(f"Imported {len(paths)} file(s)")
        except Exception as e:
            self._set_message(f"Import failed: {e}")

    def _handle_asset_scroll(self, y, mx):
        tw = self.asset_tree_width
        y_pos = self.height - 24 - self.asset_height
        bh = self.asset_height
        tb_h = 28
        tree_vis = bh - tb_h - 4
        tree_item_h = 20
        if mx < tw:
            self._asset_tree_scroll_target = max(0, self._asset_tree_scroll_target - y * 24)
            total = self._count_tree_items("") + 2
            max_scroll = max(0, total * tree_item_h - tree_vis)
            self._asset_tree_scroll_target = min(self._asset_tree_scroll_target, max_scroll)
            return True
        h = bh - tb_h
        if self._asset_mode == "materials":
            self._asset_scroll_target = max(0, self._asset_scroll_target - y * 24)
            total_items = len(self.materials)
            max_scroll = max(0, total_items * tree_item_h - h + 20)
            self._asset_scroll_target = min(self._asset_scroll_target, max_scroll)
            return True
        self._asset_scroll_target = max(0, self._asset_scroll_target - y * 24)
        folders, files = self._asset_list(self._asset_path)
        total_items = len(folders) + len(files)
        max_scroll = max(0, total_items * tree_item_h - h + 20)
        self._asset_scroll_target = min(self._asset_scroll_target, max_scroll)
        return True

    def _count_tree_items(self, rel):
        folders, _ = self._asset_list(rel)
        count = len(folders)
        for fn in folders:
            child = (rel + "/" + fn) if rel else fn
            count += self._count_tree_items(child)
        return count

    def _handle_asset_border_click(self, mx, my):
        y = self.height - 24 - self.asset_height
        if abs(my - y) < 4 and mx < self.width:
            self._asset_border_drag = True
            self._asset_border_start_y = my
            self._asset_border_start_h = self.asset_height
            return True
        return False

    def _handle_asset_border_drag(self, mx, my):
        if self._asset_border_drag:
            dy = self._asset_border_start_y - my
            self.asset_height = int(max(self.asset_min_h,
                                        min(self.height - 100, self._asset_border_start_h + dy)))
            return True
        return False
