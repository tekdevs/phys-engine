from __future__ import annotations
import os
from OpenGL.GL import *
from PIL import Image, ImageDraw, ImageFont

PANEL_BG = (0.10, 0.10, 0.13)
PANEL_DARK = (0.05, 0.05, 0.07)
PANEL_BORDER = (0.16, 0.16, 0.20)
HEADER_BG = (0.06, 0.06, 0.08)
ACCENT = (0.50, 0.68, 1.0)
ACCENT_HOVER = (0.62, 0.78, 1.0)
TEXT_COLOR = (0.90, 0.90, 0.94)
TEXT_DIM = (0.52, 0.52, 0.58)
TEXT_BRIGHT = (1.0, 1.0, 1.0)
GRID_COLOR = (0.4, 0.6, 1.0)
GIZMO_X = (1, 0.25, 0.25)
GIZMO_Y = (0.25, 1, 0.25)
GIZMO_Z = (0.25, 0.45, 1)
GIZMO_HOVER = (1, 1, 0.3)
SELECTION_COLOR = (0.50, 0.68, 1.0)
MAT_PINK = (0.86, 0.08, 0.24)
MAT_GRAY = (0.45, 0.45, 0.45)
FIELD_BG = (0.09, 0.09, 0.12)
FIELD_BORDER = (0.22, 0.22, 0.28)
FIELD_ACTIVE = (0.50, 0.68, 1.0)
HOVER_BG = (0.14, 0.18, 0.28)

FONT_SZ_SM = 13
FONT_SZ_MD = 14
FONT_SZ_LG = 15

def lerp(a, b, t):
    return a + (b - a) * t

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

texture_cache = {}
def get_text_tex(text, font_size=12, color=(255, 255, 255, 255)):
    key = (text, font_size, color)
    if key in texture_cache:
        return texture_cache[key]
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()
    dummy = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
    bbox = ImageDraw.Draw(dummy).textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0] + 4
    th = bbox[3] - bbox[1] + 4
    img = Image.new('RGBA', (tw, th), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.text((2, 2), text, font=font, fill=color)
    data = img.tobytes("raw", "RGBA", 0, -1)
    tex = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, tex)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
    result = (tex, img.width, img.height)
    texture_cache[key] = result
    return result
