from __future__ import annotations
import re
import copy
import random
from OpenGL.GL import *
from OpenGL.GLU import *
from engine import (
    Vector3, CubeNode, SphereNode, PlayerSpawnNode, EnemyNode,
    ray_aabb_intersection, _euler_to_axes, ray_obb_intersection,
)


class SceneOpsMixin:
    def _init_scene(self):
        ps = PlayerSpawnNode()
        self.nodes.append(ps)
        for _ in range(5):
            ex = random.uniform(-15, 15)
            ez = random.uniform(-15, 15)
            if abs(ex) < 4 and abs(ez) < 4:
                ex += 8 + random.uniform(0, 5)
            en = EnemyNode(Vector3(ex, 1.5, ez))
            self.nodes.append(en)
        for _ in range(6):
            px = random.uniform(-20, 20)
            pz = random.uniform(-20, 20)
            if abs(px) < 6 and abs(pz) < 6:
                px += 10
            ph = random.uniform(2.0, 6.0)
            pw = random.uniform(1.0, 3.0)
            cn = CubeNode(Vector3(px, ph/2, pz))
            cn.scale = Vector3(pw, ph, pw)
            self.nodes.append(cn)

    def _delete_selected(self):
        if self.selected_nodes:
            self._snapshot()
            for n in list(self.selected_nodes):
                if n in self.nodes and n is not self.global_manager:
                    self.nodes.remove(n)
            self.selected_nodes.discard(self.global_manager)
            if self.selected_node is self.global_manager:
                self.selected_node = None

    def _duplicate_selected(self):
        if not self.selected_node:
            return
        self._snapshot()
        new_nodes = []
        for node in list(self.selected_nodes):
            new_node = copy.deepcopy(node)
            new_node.name = self._next_name(node.name)
            new_node.pos = Vector3(node.pos.x, node.pos.y, node.pos.z)
            new_node.rot = Vector3(node.rot.x, node.rot.y, node.rot.z)
            new_node.scale = Vector3(node.scale.x, node.scale.y, node.scale.z)
            new_node.selected = False
            self.nodes.append(new_node)
            new_nodes.append(new_node)
            self._node_counter += 1
        for n in self.selected_nodes:
            n.selected = False
        self.selected_nodes.clear()
        for nn in new_nodes:
            nn.selected = True
            self.selected_nodes.add(nn)
        self.selected_node = new_nodes[-1] if new_nodes else None

    def _copy_selected(self):
        if self.selected_node:
            self._clipboard = copy.deepcopy(self.selected_node)

    def _paste_clipboard(self):
        if not self._clipboard:
            return
        self._snapshot()
        new_node = copy.deepcopy(self._clipboard)
        new_node.name = self._next_name(self._clipboard.name)
        new_node.pos = Vector3(self._clipboard.pos.x, self._clipboard.pos.y, self._clipboard.pos.z)
        new_node.rot = Vector3(self._clipboard.rot.x, self._clipboard.rot.y, self._clipboard.rot.z)
        new_node.scale = Vector3(self._clipboard.scale.x, self._clipboard.scale.y, self._clipboard.scale.z)
        new_node.selected = False
        self.nodes.append(new_node)
        for n in self.selected_nodes:
            n.selected = False
        self.selected_nodes.clear()
        new_node.selected = True
        self.selected_nodes.add(new_node)
        self.selected_node = new_node
        self._node_counter += 1

    def _next_name(self, base):
        match = re.search(r'\((\d+)\)$', base)
        if match:
            num = int(match.group(1))
            prefix = base[:match.start()]
            return f"{prefix}({num + 1})"
        return f"{base}(2)"

    def _add_node(self, type_name):
        self._snapshot()
        fwd = self.camera.get_forward()
        pos = self.camera.pos + fwd * 10
        cls = self.NODE_TYPES.get(type_name)
        if not cls: return
        self._node_counter += 1
        node = cls(pos)
        if type_name == "Cube":
            node.name = f"Cube {self._node_counter}"
        elif type_name == "Sphere":
            node.name = f"Sphere {self._node_counter}"
        elif type_name == "Enemy":
            node.name = f"Enemy {self._node_counter}"
        elif type_name == "PlayerSpawn":
            node.name = "PlayerSpawn"
        if type_name == "PlayerSpawn":
            node.pos.y = 1.5
        elif fwd.y < -0.001:
            t = -self.camera.pos.y / fwd.y
            if t > 0:
                node.pos = self.camera.pos + fwd * t
        if hasattr(node, "height"):
            node.pos.y = node.height / 2
        elif type_name == "Sphere":
            node.pos.y = node.scale.y / 2
        elif type_name != "PlayerSpawn":
            node.pos.y = 0
        if type_name in ("Cube", "Sphere") and hasattr(node, 'tex_id'):
            node.tex_id = self.tex_cube

        self.nodes.append(node)
        self._resolve_materials()
        self._select_node(node)

    def _apply_scale(self, node, axis, delta):
        if hasattr(node, "scale"):
            scales = [node.scale.x, node.scale.y, node.scale.z]
            factor = 1.0 + delta / max(scales[axis], 0.01)
            scales[axis] = max(0.1, scales[axis] * factor)
            node.scale = Vector3(scales[0], scales[1], scales[2])
        elif hasattr(node, "size"):
            factor = 1.0 + delta / max(node.size, 0.01)
            node.size = max(0.1, node.size * factor)
        elif hasattr(node, "radius"):
            factor = 1.0 + delta / max(node.radius, 0.01)
            node.radius = max(0.1, node.radius * factor)

    def _screen_to_ray(self, mx, my):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = self.width / self.height
        gluPerspective(90, aspect, 0.1, 500.0)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        self.camera.look_at()
        viewport = glGetIntegerv(GL_VIEWPORT)
        modelview = glGetDoublev(GL_MODELVIEW_MATRIX)
        projection = glGetDoublev(GL_PROJECTION_MATRIX)
        wy = viewport[3] - my
        try:
            near = gluUnProject(mx, wy, 0, modelview, projection, viewport)
            far = gluUnProject(mx, wy, 1, modelview, projection, viewport)
        except Exception:
            return None, None
        origin = Vector3(near[0], near[1], near[2])
        fv = Vector3(far[0] - near[0], far[1] - near[1], far[2] - near[2])
        fl = fv.length()
        if fl < 1e-8: return None, None
        direction = fv * (1.0 / fl)
        return origin, direction

    def _raycast_scene(self, origin, direction):
        best_dist = 1e9
        best_node = None
        for node in self.nodes:
            if not node.visible:
                continue
            aabb_min, aabb_max = node.get_bounds()
            rot = node.rot if hasattr(node, 'rot') else Vector3()
            if rot.x == 0 and rot.y == 0 and rot.z == 0:
                d = ray_aabb_intersection(origin, direction,
                    (aabb_min.x, aabb_min.y, aabb_min.z),
                    (aabb_max.x, aabb_max.y, aabb_max.z))
            else:
                cx = (aabb_min.x + aabb_max.x) / 2
                cy = (aabb_min.y + aabb_max.y) / 2
                cz = (aabb_min.z + aabb_max.z) / 2
                hw = (aabb_max.x - aabb_min.x) / 2
                hh = (aabb_max.y - aabb_min.y) / 2
                hd = (aabb_max.z - aabb_min.z) / 2
                axes = _euler_to_axes(rot.x, rot.y, rot.z)
                d = ray_obb_intersection(origin, direction, Vector3(cx, cy, cz), (hw, hh, hd), axes)
            if d is not None and 0 < d < best_dist:
                best_dist = d
                best_node = node
        return best_node, best_dist

    def _mouse_in_viewport(self, mx, my):
        ph = 40
        asset_top = self.height - 24 - self.asset_height
        if my <= ph or my >= asset_top:
            return False
        if mx < self.hierarchy_width + 5 or mx > self.width - self.inspector_width - 5:
            return False
        return True
