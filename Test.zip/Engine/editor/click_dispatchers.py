from __future__ import annotations
import glfw
import copy
from OpenGL.GL import *
from engine import Vector3
from editor.constants import (
    PANEL_BG, PANEL_DARK, PANEL_BORDER, ACCENT, TEXT_COLOR, TEXT_DIM, SELECTION_COLOR,
    GIZMO_X, GIZMO_Y, GIZMO_Z, FONT_SZ_SM,
)


class ClickMixin:
    def _handle_hierarchy_right_click(self, mx, my):
        items = [
            ("Cube", lambda: self._add_node("Cube")),
            ("Sphere", lambda: self._add_node("Sphere")),
            ("PlayerSpawn", lambda: self._add_node("PlayerSpawn")),
            ("Enemy", lambda: self._add_node("Enemy")),
        ]
        self._hierarchy_context_menu = (mx, my, items)

    def _handle_left_click(self):
        mx, my = self.mouse_x, self.mouse_y
        if self._color_picker_active:
            self._handle_color_picker_click(mx, my)
            return
        if self._dialog_active:
            self._handle_dialog_click(mx, my)
            return
        if self._hierarchy_scroll_drag:
            return
        if self._material_dropdown_open and not (mx > self.width - self.inspector_width and my > 40 and my < self.height - 24 - self.asset_height):
            self._material_dropdown_open = False
        if self._tex_dropdown_open and not (mx > self.width - self.inspector_width and my > 40 and my < self.height - 24 - self.asset_height):
            self._tex_dropdown_open = False
        if self._selected_material_name:
            if mx > self.width - self.inspector_width and my > 40 and my < self.height - 24 - self.asset_height:
                self._handle_material_editor_click(mx, my)
                return
            else:
                self._selected_material_name = None
        if self._editing_field is not None:
            if not (mx > self.width - self.inspector_width and my > 40 and my < self.height - 24 - self.asset_height):
                self._finish_editing()
                return
        if self.show_file_menu:
            self._handle_toolbar_click(mx, my)
            return
        ph = 40
        if my < ph:
            self._handle_toolbar_click(mx, my)
            return
        asset_top = self.height - 24 - self.asset_height
        if my >= asset_top and my < self.height - 24:
            self._handle_asset_click(mx, my)
            return
        if mx < self.hierarchy_width and my > ph and my < asset_top:
            if self._hierarchy_context_menu:
                mx2, my2, items = self._hierarchy_context_menu
                mw = 120
                for ii, (label, cb) in enumerate(items):
                    iy = my2 + 4 + ii * 24
                    if mx2 + 4 <= mx <= mx2 + mw - 4 and iy <= my <= iy + 20:
                        cb()
                        self._hierarchy_context_menu = None
                        return
                self._hierarchy_context_menu = None
                return
            self._handle_hierarchy_click(mx, my - ph)
            return
        if mx > self.width - self.inspector_width and my > 40 and my < asset_top:
            self._handle_inspector_click(mx, my)
            return
        self._hierarchy_context_menu = None
        origin, direction = self._screen_to_ray(mx, my)
        if origin is None: return
        if self.selected_node:
            gs = (self.selected_node.get_world_pos() - self.camera.pos).length() * 0.06
            rot = None if self.gizmo.mode == "rotate" else self.selected_node.rot
            hit = self.gizmo.hit_test(origin, direction, self.selected_node.get_world_pos(), max(0.5, min(3.0, gs)) * 1.3, rot=rot)
            if hit is not None:
                self._snapshot()
                self.gizmo.start_drag(origin, direction, self.selected_node.get_world_pos(), hit, rot=rot)
                self._snap_drag_start = {id(n): Vector3(n.pos.x, n.pos.y, n.pos.z) for n in self.selected_nodes}
                base_axes = [Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1)]
                rotated = self.gizmo._rotate_axes([(a, None) for a in base_axes], rot)
                axis_dir = rotated[hit][0]
                orig = self.selected_node.get_world_pos()
                _, _, t_ax = self.gizmo.ray_axis_distance(origin, direction, orig, axis_dir)
                self._snap_drag_start["_t"] = t_ax
                return
        node, dist = self._raycast_scene(origin, direction)
        shift = glfw.get_key(self.window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS or glfw.get_key(self.window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
        ctrl = glfw.get_key(self.window, glfw.KEY_LEFT_CONTROL) == glfw.PRESS or glfw.get_key(self.window, glfw.KEY_RIGHT_CONTROL) == glfw.PRESS
        mode = "range" if shift else ("toggle" if ctrl else "set")
        if node:
            self._select_node(node, mode=mode)
        else:
            if mode == "set":
                self._select_node(None)

    def _handle_toolbar_click(self, mx, my):
        btn_y = 7
        btn_h = 26
        pw = 40
        cx = self.width // 2
        px = cx - pw // 2
        if px <= mx <= px + pw and btn_y <= my <= btn_y + btn_h:
            self._play_game()
            return
        if 8 <= mx <= 58 and btn_y <= my <= btn_y + btn_h:
            self.show_file_menu = not self.show_file_menu
            return
        if self.show_file_menu:
            menu_x = 8
            menu_y = btn_y + btn_h + 2
            menu_w = 140
            items = [("New", "new"), ("Save", "save"), ("Load", "load")]
            for i, (label, action) in enumerate(items):
                iy = menu_y + 4 + i * 24
                if menu_x + 4 <= mx <= menu_x + menu_w - 4 and iy <= my <= iy + 22:
                    self.show_file_menu = False
                    if action == "new":
                        self._new_scene()
                    elif action == "save":
                        self._save_dialog()
                    elif action == "load":
                        self._load_dialog()
                    return
            self.show_file_menu = False

    def _handle_add_menu_click(self, mx, mouse_y):
        x, y = 0, 40
        pw = self.hierarchy_width
        menu_y = y + 40
        items = ["Cube", "Sphere", "PlayerSpawn", "Enemy"]
        for i, item in enumerate(items):
            iy = menu_y + 4 + i * 26
            if x + 10 <= mx <= x + pw - 10 and iy <= mouse_y <= iy + 24:
                self._add_node(item)
                self.show_add_menu = False
                return
        self.show_add_menu = False

    def _handle_inspector_click(self, mx, my):
        node = self.selected_node
        if not node:
            return
        if node is self.global_manager:
            gm = self.global_manager
            x = self.width - self.inspector_width
            pw = self.inspector_width
            y = 40
            line_h = 24
            gap = 6
            pad = 10
            label_w = 80
            field_x = x + label_w
            field_w = pw - label_w - pad
            sw = 30
            cy = y + 32
            sx = x + pw - sw - 10
            if sx <= mx <= sx + sw and cy + 2 <= my <= cy + line_h - 2:
                self._open_color_picker(gm.skybox_color, self._on_skybox_color_picked, target="skybox")
                return
            cy += line_h + gap
            cy += line_h + gap
            sx2 = x + pw - sw - 10
            if sx2 <= mx <= sx2 + sw and cy + 2 <= my <= cy + line_h - 2:
                self._open_color_picker(gm.light_color, self._on_light_color_picked, target="light")
                return
            cy += line_h + gap
            if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
                self._snapshot()
                self._editing_field = ("light_intensity", None, gm)
                val_str = f"{gm.light_intensity:.2f}".rstrip('0').rstrip('.')
                if '.' not in val_str: val_str = f"{val_str}.0"
                self._edit_buffer = val_str
                self._edit_cursor = len(self._edit_buffer)
                self._edit_sel = None
                self._edit_cursor_timer = 0.0
                return
            cy += line_h + gap
            if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
                self._snapshot()
                self._editing_field = ("ambient_intensity", None, gm)
                val_str = f"{gm.ambient_intensity:.2f}".rstrip('0').rstrip('.')
                if '.' not in val_str: val_str = f"{val_str}.0"
                self._edit_buffer = val_str
                self._edit_cursor = len(self._edit_buffer)
                self._edit_sel = None
                self._edit_cursor_timer = 0.0
                return
            cy += line_h + gap
            if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
                self._snapshot()
                self._editing_field = ("shadow_strength", None, gm)
                val_str = f"{gm.shadow_strength:.2f}".rstrip('0').rstrip('.')
                if '.' not in val_str: val_str = f"{val_str}.0"
                self._edit_buffer = val_str
                self._edit_cursor = len(self._edit_buffer)
                self._edit_sel = None
                self._edit_cursor_timer = 0.0
                return
            cy += line_h + gap + 4
            cy += line_h + 4
            d = gm.light_direction
            dir_vals = [d.x, d.y, d.z]
            field_gap = 4
            avail = pw - pad * 2 - field_gap * 2
            fw = avail / 3
            for i in range(3):
                fx = x + pad + i * (fw + field_gap)
                if fx <= mx <= fx + fw and cy + 2 <= my <= cy + line_h - 2:
                    self._snapshot()
                    edit_key = f"light_dir_{i}"
                    self._editing_field = (edit_key, None, gm)
                    val_str = f"{dir_vals[i]:.2f}".rstrip('0').rstrip('.')
                    if '.' not in val_str: val_str = f"{val_str}.0"
                    self._edit_buffer = val_str
                    self._edit_cursor = len(self._edit_buffer)
                    self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                    return
            return
        x = self.width - self.inspector_width
        pw = self.inspector_width
        cy = 72
        line_h = 24
        pad = 10
        label_w = 60
        field_x = x + label_w
        field_w = pw - label_w - pad
        if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
            self._snapshot()
            self._editing_field = ("name", None, node)
            self._edit_buffer = node.name
            self._edit_cursor = len(self._edit_buffer)
            self._edit_sel = None
            self._edit_cursor_timer = 0.0
            return
        cy += line_h + 1
        gap = 4
        avail = pw - label_w - pad - gap * 4
        fw = avail / 3
        for prefix, vec in [("pos", node.pos), ("rot", node.rot), ("scale", node.scale)]:
            for i, (label, axis) in enumerate([("X", 0), ("Y", 1), ("Z", 2)]):
                fx = x + label_w + gap + i * (fw + gap)
                if fx <= mx <= fx + fw and cy + 2 <= my <= cy + line_h - 2:
                    self._snapshot()
                    self._editing_field = (prefix, i, node)
                    val_str = f"{[vec.x, vec.y, vec.z][i]:.2f}".rstrip('0').rstrip('.')
                    if '.' not in val_str: val_str = f"{val_str}.0"
                    self._edit_buffer = val_str
                    self._edit_cursor = len(self._edit_buffer)
                    self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                    return
            cy += line_h + 1
        props = node.get_properties()
        for key, val in props.items():
            if key == "pos" and isinstance(val, Vector3):
                continue
            elif isinstance(val, (int, float)):
                if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
                    self._snapshot()
                    self._editing_field = (key, None, node)
                    val_str = f"{val:.2f}".rstrip('0').rstrip('.')
                    if '.' not in val_str: val_str = f"{val_str}.0"
                    self._edit_buffer = val_str
                    self._edit_cursor = len(self._edit_buffer)
                    self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                    return
                cy += line_h + 1
            else:
                cy += line_h + 1
        if hasattr(node, 'material_name'):
            mat_field_w = field_w
            if field_x <= mx <= field_x + mat_field_w and cy + 2 <= my <= cy + line_h - 2:
                self._material_dropdown_open = not self._material_dropdown_open
                return
            if self._material_dropdown_open:
                dd_h = (len(self.materials) + 1) * 20
                inspector_bottom = self.height - 24 - self.asset_height
                if cy + line_h + 2 + dd_h > inspector_bottom:
                    dd_y = cy - dd_h
                else:
                    dd_y = cy + line_h + 2
                if field_x <= mx <= field_x + mat_field_w and dd_y <= my <= dd_y + 20:
                    self._snapshot()
                    node.material_name = "None"
                    self._resolve_materials()
                    self._material_dropdown_open = False
                    return
                for mi, mname in enumerate(self.materials):
                    miy = dd_y + (mi + 1) * 20
                    if field_x <= mx <= field_x + mat_field_w and miy <= my <= miy + 20:
                        self._snapshot()
                        node.material_name = mname
                        self._resolve_materials()
                        self._material_dropdown_open = False
                        return
            cy += line_h + 1

    def _handle_material_editor_click(self, mx, my):
        if not self._selected_material_name:
            return
        mat = self.materials.get(self._selected_material_name)
        if not mat:
            return
        x = self.width - self.inspector_width
        y = 40
        pw = self.inspector_width
        line_h = 24
        gap = 4
        pad = 6
        label_w = 55
        field_x = x + label_w
        field_w = pw - label_w - pad
        sw = 28
        al_sw = sw + 8
        cy = y + 42

        if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
            self._material_edit_field = "name"
            self._material_edit_buffer = mat.name
            self._material_edit_cursor = len(mat.name)
            self._material_edit_cursor_timer = 0.0
            return
        cy += line_h + gap

        sx_al = x + pw - al_sw - pad
        if sx_al <= mx <= sx_al + al_sw and cy + 2 <= my <= cy + line_h - 2:
            self._open_color_picker(mat.albedo_color, self._on_material_albedo_picked, target="material_albedo")
            return
        cy += line_h + gap

        if field_x <= mx <= field_x + field_w and cy + 2 <= my <= cy + line_h - 2:
            self._tex_dropdown_open = not self._tex_dropdown_open
            return
        if self._tex_dropdown_open:
            images = self._collect_images()
            inspector_bottom = self.height - 24 - self.asset_height
            dd_h = (len(images) + 1) * 20
            if cy + line_h + 2 + dd_h > inspector_bottom:
                dd_tex_y = cy - dd_h
            else:
                dd_tex_y = cy + line_h + 2
            if field_x <= mx <= field_x + field_w and dd_tex_y <= my <= dd_tex_y + 20:
                self._snapshot()
                mat.albedo_texture = ""
                mat.cleanup_tex()
                self._tex_dropdown_open = False
                return
            for ii, ipath in enumerate(images):
                iy = dd_tex_y + (ii + 1) * 20
                if field_x <= mx <= field_x + field_w and iy <= my <= iy + 20:
                    self._snapshot()
                    mat.albedo_texture = ipath
                    mat.load_texture(self._asset_root_dir())
                    self._tex_dropdown_open = False
                    return
        cy += line_h + gap

        for attr_u, attr_v in [("tiling_u", "tiling_v"), ("offset_u", "offset_v")]:
            gap2 = 4
            fw2 = (field_w - gap2) / 2
            for i, aname in enumerate([attr_u, attr_v]):
                fx2 = field_x + i * (fw2 + gap2)
                if fx2 <= mx <= fx2 + fw2 and cy + 2 <= my <= cy + line_h - 2:
                    self._material_edit_field = f"mat_{aname}"
                    val = getattr(mat, aname)
                    self._material_edit_buffer = f"{val:.2f}".rstrip('0').rstrip('.')
                    if '.' not in self._material_edit_buffer:
                        self._material_edit_buffer = f"{self._material_edit_buffer}.0"
                    self._material_edit_cursor = len(self._material_edit_buffer)
                    self._material_edit_cursor_timer = 0.0
                    return
            cy += line_h + gap

        sl_x = field_x
        sl_w = field_w - 28
        sl_y = cy + 3
        if sl_x <= mx <= sl_x + sl_w and sl_y <= my <= sl_y + line_h - 6:
            t = (mx - sl_x) / sl_w
            mat.shininess = int(max(0, min(128, t * 128)))
            self._resolve_materials()
            return
        cy += line_h + gap

        sp_x = x + pw - al_sw - pad
        if sp_x <= mx <= sp_x + al_sw and cy + 2 <= my <= cy + line_h - 2:
            self._open_color_picker(mat.specular, self._on_material_specular_picked, target="material_specular")
            return
        cy += line_h + gap + 4

        btn_w = (pw - pad - 4) // 2
        btn_h = 22
        by = cy
        if x + 2 <= mx <= x + 2 + btn_w and by <= my <= by + btn_h:
            self._delete_material(self._selected_material_name)
            self._selected_material_name = None
            return
        if x + 2 + btn_w + 4 <= mx <= x + 2 + btn_w * 2 + 4 and by <= my <= by + btn_h:
            self._duplicate_material(self._selected_material_name)
            return

    def _handle_hierarchy_click(self, mx, my):
        pw = self.hierarchy_width
        ph = self.height - 40 - 24 - self.asset_height
        content_top = 10
        content_h = ph - 10
        item_h = 22
        gm = self.global_manager
        if content_top <= my < content_top + item_h:
            self._select_node(gm)
            return
        node_content_top = content_top + item_h
        node_content_h = content_h - item_h
        total = len(self.nodes)
        visible_count = int(node_content_h / item_h)
        max_scroll = max(0, (total - visible_count) * item_h)
        if total > visible_count and mx >= pw - 18 and node_content_top <= my <= node_content_top + node_content_h:
            bar_h = max(30, int(node_content_h * visible_count / total))
            bar_y = node_content_top + int((self._hierarchy_scroll / max(max_scroll, 1)) * (node_content_h - bar_h))
            self._sb_grab_offset = my - bar_y
            self._hierarchy_scroll_drag = True
            return
        shift = glfw.get_key(self.window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS or glfw.get_key(self.window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
        ctrl = glfw.get_key(self.window, glfw.KEY_LEFT_CONTROL) == glfw.PRESS or glfw.get_key(self.window, glfw.KEY_RIGHT_CONTROL) == glfw.PRESS
        mode = "range" if shift else ("toggle" if ctrl else "set")
        scroll_idx = int(self._hierarchy_scroll / item_h)
        for idx in range(scroll_idx, min(scroll_idx + visible_count + 1, total)):
            node = self.nodes[idx]
            y = node_content_top + (idx - scroll_idx) * item_h
            if y <= my < y + item_h:
                self._select_node(node, mode=mode)
                return

    def _select_node(self, node, mode="set"):
        self._selected_material_name = None
        if node is not self.global_manager:
            self._color_picker_active = False
        if mode == "toggle":
            if node:
                node.selected = not node.selected
                if node.selected:
                    self.selected_nodes.add(node)
                else:
                    self.selected_nodes.discard(node)
                if node.selected:
                    self.selected_node = node
                elif self.selected_nodes:
                    self.selected_node = next(iter(self.selected_nodes))
                else:
                    self.selected_node = None
        elif mode == "range" and node and self._select_anchor is not None:
            anchor_idx = -1
            click_idx = -1
            for i, n in enumerate(self.nodes):
                if n == self._select_anchor:
                    anchor_idx = i
                if n == node:
                    click_idx = i
            if anchor_idx != -1 and click_idx != -1:
                start = min(anchor_idx, click_idx)
                end = max(anchor_idx, click_idx)
                for n in self.nodes:
                    n.selected = False
                self.selected_nodes.clear()
                for i in range(start, end + 1):
                    n = self.nodes[i]
                    n.selected = True
                    self.selected_nodes.add(n)
                self.selected_node = node
        else:
            for n in self.nodes:
                n.selected = False
            self.selected_nodes.clear()
            if node:
                node.selected = True
                self.selected_nodes.add(node)
                self._select_anchor = node
            self.selected_node = node if node else (next(iter(self.selected_nodes)) if self.selected_nodes else None)
