from editor import Editor

def main():
    editor = Editor(1280, 720)
    editor.run()

if __name__ == "__main__":
    main()