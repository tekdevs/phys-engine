from OpenGL.GL import *
from engine.math_utils import Vector3

class Skybox:
    def __init__(self, top_color=(0.1,0.1,0.3), horizon_color=(0.3,0.3,0.6), ground_color=(0.05,0.05,0.1)):
        self.top_color = top_color; self.horizon_color = horizon_color; self.ground_color = ground_color
    def draw(self, camera_pos):
        glPushMatrix()
        glTranslatef(camera_pos.x, camera_pos.y, camera_pos.z)
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_CULL_FACE)
        r = 250
        c = self.horizon_color
        glBegin(GL_QUADS)
        glColor3f(*self.top_color)
        glVertex3f(-r, r, r); glVertex3f( r, r, r); glVertex3f( r, r,-r); glVertex3f(-r, r,-r)
        glColor3f(*self.ground_color)
        glVertex3f(-r,-r,-r); glVertex3f( r,-r,-r); glVertex3f( r,-r, r); glVertex3f(-r,-r, r)
        glColor3f(*c); glVertex3f( r,-r, r); glVertex3f( r, r, r); glVertex3f( r, r,-r); glVertex3f( r,-r,-r)
        glColor3f(*c); glVertex3f(-r,-r,-r); glVertex3f(-r, r,-r); glVertex3f(-r, r, r); glVertex3f(-r,-r, r)
        glColor3f(*c); glVertex3f(-r,-r, r); glVertex3f(-r, r, r); glVertex3f( r, r, r); glVertex3f( r,-r, r)
        glColor3f(*c); glVertex3f( r,-r,-r); glVertex3f( r, r,-r); glVertex3f(-r, r,-r); glVertex3f(-r,-r,-r)
        glEnd()
        glEnable(GL_CULL_FACE)
        glEnable(GL_DEPTH_TEST)
        glPopMatrix()
