import math

class Vector3:
    def __init__(self, x=0, y=0, z=0):
        self.x = x; self.y = y; self.z = z
    def __add__(self, o):
        return Vector3(self.x+o.x, self.y+o.y, self.z+o.z)
    def __sub__(self, o):
        return Vector3(self.x-o.x, self.y-o.y, self.z-o.z)
    def __mul__(self, s):
        return Vector3(self.x*s, self.y*s, self.z*s)
    def __rmul__(self, s):
        return Vector3(self.x*s, self.y*s, self.z*s)
    def __neg__(self):
        return Vector3(-self.x, -self.y, -self.z)
    def __repr__(self):
        return f"Vector3({self.x},{self.y},{self.z})"
    def length(self):
        return math.sqrt(self.x*self.x+self.y*self.y+self.z*self.z)
    def normalize(self):
        l = self.length()
        return Vector3(self.x/l, self.y/l, self.z/l) if l else Vector3()
    def dot(self, o):
        return self.x*o.x+self.y*o.y+self.z*o.z
    def cross(self, o):
        return Vector3(self.y*o.z - self.z*o.y, self.z*o.x - self.x*o.z, self.x*o.y - self.y*o.x)

def lerp(a, b, t):
    return a + (b - a) * t

def clamp(v, lo, hi):
    return max(lo, min(hi, v))
