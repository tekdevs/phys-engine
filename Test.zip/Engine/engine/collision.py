import math
from engine.math_utils import Vector3

def ray_aabb_intersection(origin, direction, aabb_min, aabb_max):
    ox, oy, oz = origin.x, origin.y, origin.z
    dx, dy, dz = direction.x, direction.y, direction.z
    tmin = (aabb_min[0] - ox) / dx if abs(dx) > 1e-8 else -1e9
    tmax = (aabb_max[0] - ox) / dx if abs(dx) > 1e-8 else 1e9
    if tmin > tmax: tmin, tmax = tmax, tmin
    tymin = (aabb_min[1] - oy) / dy if abs(dy) > 1e-8 else -1e9
    tymax = (aabb_max[1] - oy) / dy if abs(dy) > 1e-8 else 1e9
    if tymin > tymax: tymin, tymax = tymax, tymin
    if (tmin > tymax) or (tymin > tmax): return None
    if tymin > tmin: tmin = tymin
    if tymax < tmax: tmax = tymax
    tzmin = (aabb_min[2] - oz) / dz if abs(dz) > 1e-8 else -1e9
    tzmax = (aabb_max[2] - oz) / dz if abs(dz) > 1e-8 else 1e9
    if tzmin > tzmax: tzmin, tzmax = tzmax, tzmin
    if (tmin > tzmax) or (tzmin > tmax): return None
    if tzmin > tmin: tmin = tzmin
    if tzmax < tmax: tmax = tzmax
    return tmin if tmin > 0 else (tmax if tmax > 0 else None)

def ray_sphere_intersection(origin, direction, sphere_pos, sphere_radius):
    oc = origin - sphere_pos
    b = oc.dot(direction)
    c = oc.dot(oc) - sphere_radius * sphere_radius
    if b > 0 and c > 0:
        return None
    discriminant = b * b - c
    if discriminant < 0:
        return None
    t = -b - math.sqrt(discriminant)
    if t < 0:
        t = -b + math.sqrt(discriminant)
    return t if t >= 0 else None


def _euler_to_axes(rx, ry, rz):
    cx, sx = math.cos(math.radians(rx)), math.sin(math.radians(rx))
    cy, sy = math.cos(math.radians(ry)), math.sin(math.radians(ry))
    cz, sz = math.cos(math.radians(rz)), math.sin(math.radians(rz))
    ax = Vector3(cy*cz, sx*sy*cz + cx*sz, -cx*sy*cz + sx*sz)
    ay = Vector3(-cy*sz, -sx*sy*sz + cx*cz, cx*sy*sz + sx*cz)
    az = Vector3(sy, -sx*cy, cx*cy)
    return ax, ay, az


def _obb_overlap(pos_a, ext_a, axes_a, pos_b, ext_b, axes_b):
    axes_a = list(axes_a); axes_b = list(axes_b)
    for axis in axes_a + axes_b:
        if axis.length() < 1e-8:
            continue
        proj_a = ext_a[0] * abs(axes_a[0].dot(axis)) + ext_a[1] * abs(axes_a[1].dot(axis)) + ext_a[2] * abs(axes_a[2].dot(axis))
        proj_b = ext_b[0] * abs(axes_b[0].dot(axis)) + ext_b[1] * abs(axes_b[1].dot(axis)) + ext_b[2] * abs(axes_b[2].dot(axis))
        d = abs((pos_b - pos_a).dot(axis))
        if d > proj_a + proj_b + 1e-6:
            return False
    for a in axes_a:
        for b in axes_b:
            axis = Vector3(a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x)
            if axis.length() < 1e-8:
                continue
            proj_a = ext_a[0] * abs(axes_a[0].dot(axis)) + ext_a[1] * abs(axes_a[1].dot(axis)) + ext_a[2] * abs(axes_a[2].dot(axis))
            proj_b = ext_b[0] * abs(axes_b[0].dot(axis)) + ext_b[1] * abs(axes_b[1].dot(axis)) + ext_b[2] * abs(axes_b[2].dot(axis))
            d = abs((pos_b - pos_a).dot(axis))
            if d > proj_a + proj_b + 1e-6:
                return False
    return True


def _obb_penetration(pos_a, ext_a, axes_a, pos_b, ext_b, axes_b):
    best_axis = None
    best_depth = 1e9
    all_axes = list(axes_a) + list(axes_b)
    for a in axes_a:
        for b in axes_b:
            c = Vector3(a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x)
            if c.length() > 1e-8:
                all_axes.append(c)
    for axis in all_axes:
        if axis.length() < 1e-8:
            continue
        n = axis.normalize()
        proj_a = ext_a[0] * abs(axes_a[0].dot(n)) + ext_a[1] * abs(axes_a[1].dot(n)) + ext_a[2] * abs(axes_a[2].dot(n))
        proj_b = ext_b[0] * abs(axes_b[0].dot(n)) + ext_b[1] * abs(axes_b[1].dot(n)) + ext_b[2] * abs(axes_b[2].dot(n))
        d = abs((pos_b - pos_a).dot(n))
        overlap = proj_a + proj_b - d
        if overlap <= 0:
            return None, 0
        if overlap < best_depth:
            best_depth = overlap
            best_axis = n
    if best_axis is None:
        return None, 0
    if (pos_b - pos_a).dot(best_axis) > 0:
        best_axis = Vector3(-best_axis.x, -best_axis.y, -best_axis.z)
    return best_axis, best_depth


def ray_obb_intersection(origin, direction, box_pos, box_ext, box_axes):
    diff = origin - box_pos
    t_min = -1e9
    t_max = 1e9
    for i in range(3):
        ax = box_axes[i]
        e = diff.dot(ax)
        f = direction.dot(ax)
        if abs(f) > 1e-8:
            t1 = (-box_ext[i] - e) / f
            t2 = (box_ext[i] - e) / f
            if t1 > t2:
                t1, t2 = t2, t1
            t_min = max(t_min, t1)
            t_max = min(t_max, t2)
            if t_min > t_max + 1e-6:
                return None
        else:
            if e < -box_ext[i] or e > box_ext[i]:
                return None
    if t_max < 0:
        return None
    return t_min if t_min >= 0 else t_max
