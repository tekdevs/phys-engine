import glfw
import json
import time
import os
import subprocess
from OpenGL.GL import *
from OpenGL.GLU import *
from engine.math_utils import Vector3
from engine.textures import make_tex, get_text_tex
from engine.lighting import LightingManager
from engine.geometry import Pillar, Sphere, Platform
from engine.skybox import Skybox
from engine.cameras import PlayerCamera
from engine.collision import ray_aabb_intersection, _euler_to_axes, ray_obb_intersection

class GameObjectBase:
    def __init__(self, pos, color=(1,1,1)):
        self.pos = pos
        self.color = color
        self.active = True

class Engine:
    def __init__(self, width=1000, height=800, fov=90, fps_limit=144, retro_mode=True):
        self.width = width
        self.height = height
        self.fov = fov
        self.fps_limit = fps_limit
        self.retro_mode = retro_mode
        self.running = True
        self.delta_time = 0.0
        self.last_time = time.time()
        self.objects = []
        self.terrain = None
        self.skybox = None
        self.lighting = LightingManager()
        self.camera = PlayerCamera()
        self.notifications = []
        self.tex_floor = 0
        self.tex_pillar = 0
        
        if not glfw.init():
            raise RuntimeError("Failed to init GLFW")
            
        glfw.window_hint(glfw.RESIZABLE, glfw.TRUE)
        self.window = glfw.create_window(self.width, self.height, "Game", None, None)
        if not self.window:
            glfw.terminate()
            raise RuntimeError("Failed to create window")
            
        glfw.make_context_current(self.window)
        glfw.set_input_mode(self.window, glfw.CURSOR, glfw.CURSOR_DISABLED)
        
        glfw.set_window_size_callback(self.window, self._resize_callback)
        glfw.set_key_callback(self.window, self._key_callback)
        glfw.set_mouse_button_callback(self.window, self._mouse_button_callback)
        glfw.set_cursor_pos_callback(self.window, self._cursor_pos_callback)
        
        self.tex_cube = make_tex((220, 0, 220), (35, 0, 55))
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        
        self.retro_fbo = 0
        self.retro_tex = 0
        self.retro_depth = 0
        self.retro_w = 480
        self.retro_h = 320
        if self.retro_mode:
            self._init_retro_fbo()
        
        self.last_mouse_x, self.last_mouse_y = glfw.get_cursor_pos(self.window)

    def _init_retro_fbo(self):
        self.retro_fbo = glGenFramebuffers(1)
        self.retro_tex = glGenTextures(1)
        self.retro_depth = glGenRenderbuffers(1)
        glBindFramebuffer(GL_FRAMEBUFFER, self.retro_fbo)
        glBindTexture(GL_TEXTURE_2D, self.retro_tex)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, self.retro_w, self.retro_h, 0, GL_RGB, GL_UNSIGNED_BYTE, None)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, self.retro_tex, 0)
        glBindRenderbuffer(GL_RENDERBUFFER, self.retro_depth)
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, self.retro_w, self.retro_h)
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, self.retro_depth)
        glBindFramebuffer(GL_FRAMEBUFFER, 0)

    def _resize_callback(self, window, w, h):
        self.width = w
        self.height = h

    def _key_callback(self, window, key, scancode, action, mods):
        if hasattr(self, 'on_key'):
            self.on_key(key, scancode, action, mods)
        if key == glfw.KEY_ESCAPE and action == glfw.PRESS:
            self.running = False

    def _mouse_button_callback(self, window, button, action, mods):
        if hasattr(self, 'on_mouse_button'):
            self.on_mouse_button(button, action, mods)

    def _cursor_pos_callback(self, window, x, y):
        dx = x - self.last_mouse_x
        dy = y - self.last_mouse_y
        self.last_mouse_x = x
        self.last_mouse_y = y
        self.camera.yaw += dx * self.camera.mouse_sensitivity
        self.camera.pitch += dy * self.camera.mouse_sensitivity
        self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))

    def show_notification(self, text, duration=3.0, r=1.0, g=1.0, b=1.0):
        self.notifications.append({
            "text": text,
            "timer": duration,
            "color": (r, g, b)
        })

    def init_scene(self):
        pass

    def scene_raycast(self, origin, direction):
        best_t = 1e9
        hit_pos = None
        for obj in self.objects:
            if hasattr(obj, 'scale') and not hasattr(obj, 'width'):
                sx, sy, sz = obj.scale.x/2, obj.scale.y/2, obj.scale.z/2
                rot = getattr(obj, 'rot', Vector3())
                if rot.x == 0 and rot.y == 0 and rot.z == 0:
                    t = ray_aabb_intersection(origin, direction, (obj.pos.x - sx, obj.pos.y - sy, obj.pos.z - sz), (obj.pos.x + sx, obj.pos.y + sy, obj.pos.z + sz))
                else:
                    axes = _euler_to_axes(rot.x, rot.y, rot.z)
                    t = ray_obb_intersection(origin, direction, obj.pos, (sx, sy, sz), axes)
                if t is not None and 0 < t < best_t:
                    best_t = t
                    hit_pos = origin + direction * t
            elif hasattr(obj, 'width') and hasattr(obj, 'height') and hasattr(obj, 'depth'):
                w, h, d = obj.width/2, obj.height/2, obj.depth/2
                rot = getattr(obj, 'rot', Vector3())
                if rot.x == 0 and rot.y == 0 and rot.z == 0:
                    t = ray_aabb_intersection(origin, direction, (obj.pos.x - w, obj.pos.y - h, obj.pos.z - d), (obj.pos.x + w, obj.pos.y + h, obj.pos.z + d))
                else:
                    axes = _euler_to_axes(rot.x, rot.y, rot.z)
                    t = ray_obb_intersection(origin, direction, obj.pos, (w, h, d), axes)
                if t is not None and 0 < t < best_t:
                    best_t = t
                    hit_pos = origin + direction * t
        if abs(direction.y) > 1e-6:
            t = (0.0 - origin.y) / direction.y
            if 0 < t < best_t:
                pt = origin + direction * t
                if self.terrain:
                    hs = self.terrain.size / 2
                    if -hs <= pt.x <= hs and -hs <= pt.z <= hs:
                        best_t = t
                        hit_pos = pt
                else:
                    pass
        return hit_pos

    def run(self):
        if hasattr(self, 'on_init'):
            self.on_init()
        while self.running and not glfw.window_should_close(self.window):
            t = time.time()
            self.delta_time = min(t - self.last_time, 0.1)
            self.last_time = t
            
            glfw.poll_events()
            
            if not getattr(self, 'grappling', False):
                self.camera.momentum_x -= self.camera.momentum_x * (5.0 * self.delta_time)
                self.camera.momentum_z -= self.camera.momentum_z * (5.0 * self.delta_time)
                
                f = self.camera.get_forward()
                ff = Vector3(f.x, 0, f.z).normalize()
                r = self.camera.get_right()
                
                move_dir = Vector3()
                if glfw.get_key(self.window, glfw.KEY_W) == glfw.PRESS: move_dir = move_dir + ff
                if glfw.get_key(self.window, glfw.KEY_S) == glfw.PRESS: move_dir = move_dir - ff
                if glfw.get_key(self.window, glfw.KEY_A) == glfw.PRESS: move_dir = move_dir - r
                if glfw.get_key(self.window, glfw.KEY_D) == glfw.PRESS: move_dir = move_dir + r
                
                if move_dir.length() > 0.1:
                    move_dir = move_dir.normalize()
                
                sprint = 2.0 if glfw.get_key(self.window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS else 1.0
                vx = move_dir.x * self.camera.speed * sprint + self.camera.momentum_x
                vz = move_dir.z * self.camera.speed * sprint + self.camera.momentum_z
                
                self.camera.velocity.y -= 25.0 * self.delta_time
                vy = self.camera.velocity.y

                desired = self.camera.pos + Vector3(vx * self.delta_time, vy * self.delta_time, vz * self.delta_time)

                resolved, grounded = self.camera.resolve_collision(self.camera.pos, desired, self.objects)
                self.camera.pos = resolved
                if grounded and self.camera.velocity.y < 0:
                    self.camera.velocity.y = 0
                    if glfw.get_key(self.window, glfw.KEY_SPACE) == glfw.PRESS:
                        self.camera.velocity.y = getattr(self, 'player_jump', 9.0)
            
            if hasattr(self, 'on_update'):
                self.on_update(self.delta_time)
                
            self.render()
            glfw.swap_buffers(self.window)
        glfw.terminate()

    def render(self):
        if self.retro_mode and self.retro_fbo:
            glBindFramebuffer(GL_FRAMEBUFFER, self.retro_fbo)
            glViewport(0, 0, self.retro_w, self.retro_h)
        else:
            glViewport(0, 0, self.width, self.height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = self.width / self.height if self.height > 0 else 1
        gluPerspective(self.fov, aspect, 0.1, 500.0)
        glMatrixMode(GL_MODELVIEW)
        glClearColor(0.02, 0.0, 0.03, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        
        self.camera.look_at()
        
        if self.skybox:
            self.skybox.draw(self.camera.pos)
            
        self.lighting.enable()
        
        if self.terrain:
            self.terrain.draw()
            
        for obj in self.objects:
            if getattr(obj, 'active', True):
                obj.draw()
                
        if hasattr(self, 'on_draw_3d'):
            self.on_draw_3d()
            
        self.lighting.disable()
            
        if self.retro_mode and self.retro_fbo:
            glBindFramebuffer(GL_FRAMEBUFFER, 0)
            glViewport(0, 0, self.width, self.height)
            glDisable(GL_DEPTH_TEST)
            glDisable(GL_LIGHTING)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.retro_tex)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
            glMatrixMode(GL_PROJECTION)
            glPushMatrix()
            glLoadIdentity()
            glOrtho(0, 1, 0, 1, -1, 1)
            glMatrixMode(GL_MODELVIEW)
            glPushMatrix()
            glLoadIdentity()
            glColor3f(1, 1, 1)
            glBegin(GL_QUADS)
            glTexCoord2f(0, 0); glVertex2f(0, 0)
            glTexCoord2f(1, 0); glVertex2f(1, 0)
            glTexCoord2f(1, 1); glVertex2f(1, 1)
            glTexCoord2f(0, 1); glVertex2f(0, 1)
            glEnd()
            glPopMatrix()
            glMatrixMode(GL_PROJECTION)
            glPopMatrix()
            glMatrixMode(GL_MODELVIEW)
            glEnable(GL_DEPTH_TEST)
            glDisable(GL_TEXTURE_2D)
        
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.width, self.height, 0, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_CULL_FACE)
        
        if hasattr(self, 'on_draw_hud'):
            self.on_draw_hud()
            
        self.notifications = [n for n in self.notifications if n["timer"] > 0]
        cy = self.height - 50
        for n in self.notifications:
            n["timer"] -= self.delta_time
            tc = (int(n["color"][0]*255), int(n["color"][1]*255), int(n["color"][2]*255), 255)
            tex, tw, th = get_text_tex(n["text"], 16, tc)
            glEnable(GL_TEXTURE_2D)
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            glBindTexture(GL_TEXTURE_2D, tex)
            glColor3f(1, 1, 1)
            tx = (self.width - tw) // 2
            glBegin(GL_QUADS)
            glTexCoord2f(0, 1); glVertex2f(tx, cy)
            glTexCoord2f(1, 1); glVertex2f(tx + tw, cy)
            glTexCoord2f(1, 0); glVertex2f(tx + tw, cy + th)
            glTexCoord2f(0, 0); glVertex2f(tx, cy + th)
            glEnd()
            glDisable(GL_BLEND)
            glDisable(GL_TEXTURE_2D)
            cy -= (th + 10)
            
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)

    def load_scene(self, path):
        import json
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict) and "nodes" in data:
            nodes_data = data["nodes"]
            gm_data = data.get("global_manager")
            if gm_data and self.skybox:
                sc = gm_data.get("skybox_color")
                if sc:
                    self.skybox.top_color = (sc[0], sc[1], sc[2])
                    self.skybox.horizon_color = (sc[0], sc[1], sc[2])
                    self.skybox.ground_color = (sc[0], sc[1], sc[2])
                else:
                    st = gm_data.get("skybox_top")
                    if st: self.skybox.top_color = (st[0], st[1], st[2])
                    sh = gm_data.get("skybox_horizon")
                    if sh: self.skybox.horizon_color = (sh[0], sh[1], sh[2])
                    sg = gm_data.get("skybox_ground")
                    if sg: self.skybox.ground_color = (sg[0], sg[1], sg[2])
        else:
            nodes_data = data if isinstance(data, list) else []
        has_terrain = False
        for d in nodes_data:
            t = d.get("type", "")
            p = d.get("pos", [0, 0, 0])
            pos = Vector3(p[0], p[1], p[2])
            if t in ("Pillar", "Cube"):
                s = d.get("scale", None)
                if s:
                    obj = Pillar(pos, height=s[1], width=s[0], depth=s[2])
                else:
                    obj = Pillar(pos, height=d.get("height", 4.0), width=d.get("width", 1.5), depth=d.get("depth", 1.5))
                obj.name = d.get("name", "Unnamed")
                mat_name = d.get("material", None)
                obj.tex_id = 0
                if mat_name == "Default":
                     obj.tex_id = self.tex_cube
                r = d.get("rot", [0, 0, 0])
                obj.rot = Vector3(r[0], r[1], r[2])
                self.objects.append(obj)
            elif t == "Sphere":
                s = d.get("scale", [1, 1, 1])
                radius = max(s[0], s[1], s[2]) / 2
                obj = Sphere(pos, radius=radius)
                obj.name = d.get("name", "Unnamed")
                mat_name = d.get("material", None)
                obj.tex_id = 0
                if mat_name == "Default":
                     obj.tex_id = self.tex_cube
                self.objects.append(obj)
            elif t == "Platform":
                obj = Platform(size=d.get("size", 150), grid_size=10)
                mat_name = d.get("material", None)
                obj.tex_id = 0
                if mat_name == "Default":
                     obj.tex_id = self.tex_floor
                self.terrain = obj
                has_terrain = True
            elif t == "Enemy":
                pass
            elif t == "PlayerSpawn":
                self.camera.pos = pos
                self.camera.speed = d.get("speed", 12.0)
