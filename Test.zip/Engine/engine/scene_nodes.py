import math
from OpenGL.GL import *
from engine.math_utils import Vector3
from engine.geometry import _draw_box_outline, _draw_sphere_outline

SELECTION_COLOR = (1, 1, 0.3)

class SceneNode:
    def __init__(self, name="Node", pos=None):
        self.name = name
        self.pos = pos if pos else Vector3()
        self.rot = Vector3()
        self.scale = Vector3(1, 1, 1)
        self.parent = None
        self.children = []
        self.selected = False
        self.visible = True
        self.expanded = True
        self.color = (0.8, 0.8, 0.8)
    def get_world_pos(self):
        if self.parent:
            return self.parent.get_world_pos() + self.pos
        return self.pos
    def get_type_name(self):
        return "Node"
    def get_properties(self):
        return {"pos": self.pos}
    def apply_properties(self, props):
        if "pos" in props:
            self.pos = props["pos"]
    def render_scene(self): pass
    def render_selected(self): pass
    def get_bounds(self):
        p = self.get_world_pos()
        return (p, p)
    def to_dict(self):
        return {"type": self.get_type_name(), "name": self.name,
                "pos": [self.pos.x, self.pos.y, self.pos.z],
                "rot": [self.rot.x, self.rot.y, self.rot.z],
                "scale": [self.scale.x, self.scale.y, self.scale.z]}
    def from_dict(self, d):
        self.name = d.get("name", self.name)
        p = d.get("pos", [0, 0, 0])
        self.pos = Vector3(p[0], p[1], p[2])
        r = d.get("rot", [0, 0, 0])
        self.rot = Vector3(r[0], r[1], r[2])
        s = d.get("scale", [1, 1, 1])
        self.scale = Vector3(s[0], s[1], s[2])

class CubeNode(SceneNode):
    def __init__(self, pos=None):
        super().__init__("Cube", pos)
        self.color = (0.7, 0.7, 0.8)
        self.material_name = "None"
        self.tex_id = 0
        self.material_obj = None
    def get_type_name(self):
        return "Cube"
    def get_properties(self):
        return {"pos": self.pos}
    def apply_properties(self, props):
        if "pos" in props: self.pos = props["pos"]
        if "material_name" in props: self.material_name = props["material_name"]
        elif "material" in props: self.material_name = props["material"]
    def get_bounds(self):
        p = self.get_world_pos()
        sx, sy, sz = self.scale.x/2, self.scale.y/2, self.scale.z/2
        return (Vector3(p.x-sx, p.y-sy, p.z-sz), Vector3(p.x+sx, p.y+sy, p.z+sz))
    def render_scene(self):
        if not self.visible: return
        p = self.get_world_pos()
        glPushMatrix()
        glTranslatef(p.x, p.y, p.z)
        if self.rot.x or self.rot.y or self.rot.z:
            glRotatef(self.rot.x, 1, 0, 0)
            glRotatef(self.rot.y, 0, 1, 0)
            glRotatef(self.rot.z, 0, 0, 1)
        glScalef(self.scale.x, self.scale.y, self.scale.z)
        if self.material_obj:
            if self.material_obj.tex_id:
                glColor3f(1, 1, 1)
            else:
                glColor3f(*self.material_obj.albedo_color)
            self.material_obj.apply()
        else:
            glColor3f(*self.color)
            if self.tex_id:
                glEnable(GL_TEXTURE_2D)
                glBindTexture(GL_TEXTURE_2D, self.tex_id)
            else:
                glDisable(GL_TEXTURE_2D)
        glDisable(GL_CULL_FACE)
        glBegin(GL_QUADS)
        glNormal3f(0,0,1)
        glTexCoord2f(0,0); glVertex3f(-0.5,-0.5, 0.5)
        glTexCoord2f(1,0); glVertex3f( 0.5,-0.5, 0.5)
        glTexCoord2f(1,1); glVertex3f( 0.5, 0.5, 0.5)
        glTexCoord2f(0,1); glVertex3f(-0.5, 0.5, 0.5)
        glNormal3f(0,0,-1)
        glTexCoord2f(0,0); glVertex3f( 0.5,-0.5,-0.5)
        glTexCoord2f(1,0); glVertex3f(-0.5,-0.5,-0.5)
        glTexCoord2f(1,1); glVertex3f(-0.5, 0.5,-0.5)
        glTexCoord2f(0,1); glVertex3f( 0.5, 0.5,-0.5)
        glNormal3f(0,1,0)
        glTexCoord2f(0,0); glVertex3f(-0.5, 0.5,-0.5)
        glTexCoord2f(1,0); glVertex3f(-0.5, 0.5, 0.5)
        glTexCoord2f(1,1); glVertex3f( 0.5, 0.5, 0.5)
        glTexCoord2f(0,1); glVertex3f( 0.5, 0.5,-0.5)
        glNormal3f(0,-1,0)
        glTexCoord2f(0,0); glVertex3f(-0.5,-0.5, 0.5)
        glTexCoord2f(1,0); glVertex3f( 0.5,-0.5, 0.5)
        glTexCoord2f(1,1); glVertex3f( 0.5,-0.5,-0.5)
        glTexCoord2f(0,1); glVertex3f(-0.5,-0.5,-0.5)
        glNormal3f(1,0,0)
        glTexCoord2f(0,0); glVertex3f( 0.5,-0.5, 0.5)
        glTexCoord2f(1,0); glVertex3f( 0.5,-0.5,-0.5)
        glTexCoord2f(1,1); glVertex3f( 0.5, 0.5,-0.5)
        glTexCoord2f(0,1); glVertex3f( 0.5, 0.5, 0.5)
        glNormal3f(-1,0,0)
        glTexCoord2f(0,0); glVertex3f(-0.5,-0.5,-0.5)
        glTexCoord2f(1,0); glVertex3f(-0.5,-0.5, 0.5)
        glTexCoord2f(1,1); glVertex3f(-0.5, 0.5, 0.5)
        glTexCoord2f(0,1); glVertex3f(-0.5, 0.5,-0.5)
        glEnd()
        glPopMatrix()
        if self.material_obj and self.material_obj.tex_id:
            glDisable(GL_TEXTURE_2D)
            glMatrixMode(GL_TEXTURE)
            glLoadIdentity()
            glMatrixMode(GL_MODELVIEW)
        elif self.tex_id:
            glDisable(GL_TEXTURE_2D)
    def render_selected(self):
        p = self.get_world_pos()
        glDisable(GL_LIGHTING)
        glLineWidth(2)
        glColor3f(*SELECTION_COLOR)
        glPushMatrix()
        glTranslatef(p.x, p.y, p.z)
        if self.rot.x or self.rot.y or self.rot.z:
            glRotatef(self.rot.x, 1, 0, 0)
            glRotatef(self.rot.y, 0, 1, 0)
            glRotatef(self.rot.z, 0, 0, 1)
        glScalef(self.scale.x, self.scale.y, self.scale.z)
        sx = max(self.scale.x, 0.01)
        sy = max(self.scale.y, 0.01)
        sz = max(self.scale.z, 0.01)
        ofs = 0.04
        w, h, d = 0.5 + ofs/sx, 0.5 + ofs/sy, 0.5 + ofs/sz
        corners = [
            (-w,-h,-d),(w,-h,-d),(w,h,-d),(-w,h,-d),
            (-w,-h, d),(w,-h, d),(w,h, d),(-w,h, d),
        ]
        edges = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
        glBegin(GL_LINES)
        for a, b in edges:
            glVertex3f(*corners[a])
            glVertex3f(*corners[b])
        glEnd()
        glPopMatrix()
        glLineWidth(1)
        glEnable(GL_LIGHTING)
    def to_dict(self):
        d = super().to_dict()
        d["material"] = self.material_name
        return d
    def from_dict(self, d):
        super().from_dict(d)
        if "width" in d and "scale" not in d:
            self.scale = Vector3(d.get("width", 1.0), d.get("height", 1.0), d.get("depth", 1.0))
        self.material_name = d.get("material_name", d.get("material", "None"))

class SphereNode(SceneNode):
    def __init__(self, pos=None):
        super().__init__("Sphere", pos if pos else Vector3(0, 0.5, 0))
        self.color = (0.3, 0.7, 0.3)
        self.material_name = "None"
        self.tex_id = 0
        self.material_obj = None
    def get_type_name(self):
        return "Sphere"
    def get_properties(self):
        return {"pos": self.pos}
    def apply_properties(self, props):
        if "pos" in props: self.pos = props["pos"]
        if "material_name" in props: self.material_name = props["material_name"]
        elif "material" in props: self.material_name = props["material"]
    def get_bounds(self):
        p = self.get_world_pos()
        sx, sy, sz = self.scale.x/2, self.scale.y/2, self.scale.z/2
        return (Vector3(p.x-sx, p.y-sy, p.z-sz), Vector3(p.x+sx, p.y+sy, p.z+sz))
    def _build_sphere(self, slices=12, stacks=8):
        vertices = []
        normals = []
        for i in range(stacks + 1):
            phi = math.pi * i / stacks
            for j in range(slices + 1):
                theta = 2.0 * math.pi * j / slices
                nx = math.sin(phi) * math.cos(theta)
                ny = math.cos(phi)
                nz = math.sin(phi) * math.sin(theta)
                vertices.append((nx * 0.5, ny * 0.5, nz * 0.5))
                normals.append((nx, ny, nz))
        faces = []
        for i in range(stacks):
            for j in range(slices):
                a = i * (slices + 1) + j
                b = a + slices + 1
                faces.append((a, b, b + 1))
                faces.append((a, b + 1, a + 1))
        return vertices, normals, faces
    def render_scene(self):
        if not self.visible: return
        p = self.get_world_pos()
        glPushMatrix()
        glTranslatef(p.x, p.y, p.z)
        if self.rot.x or self.rot.y or self.rot.z:
            glRotatef(self.rot.x, 1, 0, 0)
            glRotatef(self.rot.y, 0, 1, 0)
            glRotatef(self.rot.z, 0, 0, 1)
        glScalef(self.scale.x, self.scale.y, self.scale.z)
        if self.material_obj:
            if self.material_obj.tex_id:
                glColor3f(1, 1, 1)
            else:
                glColor3f(*self.material_obj.albedo_color)
            self.material_obj.apply()
        else:
            glColor3f(*self.color)
            if self.tex_id:
                glEnable(GL_TEXTURE_2D)
                glBindTexture(GL_TEXTURE_2D, self.tex_id)
            else:
                glDisable(GL_TEXTURE_2D)
        glDisable(GL_CULL_FACE)
        vertices, normals, faces = self._build_sphere()
        glBegin(GL_TRIANGLES)
        for i0, i1, i2 in faces:
            nx, ny, nz = normals[i0]
            glNormal3f(nx, ny, nz)
            glVertex3f(*vertices[i0])
            nx, ny, nz = normals[i1]
            glNormal3f(nx, ny, nz)
            glVertex3f(*vertices[i1])
            nx, ny, nz = normals[i2]
            glNormal3f(nx, ny, nz)
            glVertex3f(*vertices[i2])
        glEnd()
        glPopMatrix()
        if self.material_obj and self.material_obj.tex_id:
            glDisable(GL_TEXTURE_2D)
            glMatrixMode(GL_TEXTURE)
            glLoadIdentity()
            glMatrixMode(GL_MODELVIEW)
        elif self.tex_id:
            glDisable(GL_TEXTURE_2D)
    def render_selected(self):
        p = self.get_world_pos()
        r = max(self.scale.x, self.scale.y, self.scale.z) * 0.5
        glDisable(GL_LIGHTING)
        glLineWidth(2)
        glColor3f(*SELECTION_COLOR)
        _draw_sphere_outline(p, r)
        glLineWidth(1)
        glEnable(GL_LIGHTING)
    def to_dict(self):
        d = super().to_dict()
        d["material"] = self.material_name
        return d
    def from_dict(self, d):
        super().from_dict(d)
        self.material_name = d.get("material_name", d.get("material", "None"))

class PlayerSpawnNode(SceneNode):
    def __init__(self, pos=None):
        super().__init__("PlayerSpawn", pos if pos else Vector3(0, 1.5, 0))
        self.color = (0.2, 0.8, 1.0)
        self.material_name = "None"
        self.tex_id = 0
        self.material_obj = None
        self.speed = 12.0
        self.health = 100.0
        self.jump_force = 8.0
        self.grapple_speed = 60.0
    def get_type_name(self):
        return "PlayerSpawn"
    def get_bounds(self):
        p = self.get_world_pos()
        return (Vector3(p.x-0.5, p.y-1.5, p.z-0.5), Vector3(p.x+0.5, p.y+0.5, p.z+0.5))
    def get_properties(self):
        return {"pos": self.pos, "speed": self.speed, "health": self.health,
                "jump_force": self.jump_force, "grapple_speed": self.grapple_speed}
    def render_scene(self):
        if not self.visible: return
        p = self.get_world_pos()
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_LIGHTING)
        glPushMatrix()
        glTranslatef(p.x, p.y, p.z)
        glColor3f(*self.color)
        segs = 12
        r = 0.3
        body_h = 1.5
        glBegin(GL_LINE_LOOP)
        for i in range(segs):
            a = 2*math.pi*i/segs
            glVertex3f(math.cos(a)*r, body_h, math.sin(a)*r)
        glEnd()
        glBegin(GL_LINE_LOOP)
        for i in range(segs):
            a = 2*math.pi*i/segs
            glVertex3f(math.cos(a)*r, 0, math.sin(a)*r)
        glEnd()
        glBegin(GL_LINES)
        for i in range(4):
            a = 2*math.pi*i/4
            glVertex3f(math.cos(a)*r, 0, math.sin(a)*r)
            glVertex3f(math.cos(a)*r, body_h, math.sin(a)*r)
        glEnd()
        glColor3f(1, 1, 1)
        glBegin(GL_LINES)
        glVertex3f(0, body_h, 0); glVertex3f(0, body_h + 0.7, 0)
        glEnd()
        glBegin(GL_TRIANGLES)
        glVertex3f(0, body_h + 1.0, 0)
        glVertex3f(-0.15, body_h + 0.6, 0)
        glVertex3f(0.15, body_h + 0.6, 0)
        glEnd()
        glPopMatrix()
        glEnable(GL_LIGHTING)
    def render_selected(self):
        p = self.get_world_pos()
        glDisable(GL_LIGHTING)
        glLineWidth(2)
        glColor3f(*SELECTION_COLOR)
        _draw_box_outline(p, 0.5, 1.0, 0.5, 0.08)
        glLineWidth(1)
        glEnable(GL_LIGHTING)
    def to_dict(self):
        d = super().to_dict()
        d["speed"] = self.speed
        d["health"] = self.health
        d["jump_force"] = self.jump_force
        d["grapple_speed"] = self.grapple_speed
        return d
    def from_dict(self, d):
        super().from_dict(d)
        self.speed = d.get("speed", 12.0)
        self.health = d.get("health", 100.0)
        self.jump_force = d.get("jump_force", 8.0)
        self.grapple_speed = d.get("grapple_speed", 60.0)

class EnemyNode(SceneNode):
    def __init__(self, pos=None):
        super().__init__("Enemy", pos if pos else Vector3(0, 1.5, 0))
        self.color = (1.0, 0.2, 0.15)
        self.radius = 0.8
        self.material_name = "None"
        self.tex_id = 0
        self.material_obj = None
    def get_type_name(self):
        return "Enemy"
    def get_bounds(self):
        p = self.get_world_pos()
        r = self.radius
        return (Vector3(p.x-r, p.y-r, p.z-r), Vector3(p.x+r, p.y+r, p.z+r))
    def get_properties(self):
        return {"pos": self.pos, "radius": self.radius}
    def render_scene(self):
        if not self.visible: return
        p = self.get_world_pos()
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_LIGHTING)
        glPushMatrix()
        glTranslatef(p.x, p.y, p.z)
        glColor3f(*self.color)
        segs = 24
        for plane in range(3):
            glBegin(GL_LINE_LOOP)
            for i in range(segs):
                a = 2*math.pi*i/segs
                c, s = math.cos(a)*self.radius, math.sin(a)*self.radius
                if plane == 0: glVertex3f(c, s, 0)
                elif plane == 1: glVertex3f(c, 0, s)
                else: glVertex3f(0, c, s)
            glEnd()
        glPopMatrix()
        glEnable(GL_LIGHTING)
    def render_selected(self):
        p = self.get_world_pos()
        glDisable(GL_LIGHTING)
        glLineWidth(2)
        glColor3f(*SELECTION_COLOR)
        _draw_sphere_outline(p, self.radius, 0.06)
        glLineWidth(1)
        glEnable(GL_LIGHTING)
    def to_dict(self):
        d = super().to_dict()
        d["radius"] = self.radius
        d["material"] = self.material_name
        return d
    def from_dict(self, d):
        super().from_dict(d)
        self.radius = d.get("radius", 0.8)
        self.material_name = d.get("material_name", d.get("material", "None"))

class GlobalManagerNode(SceneNode):
    def __init__(self):
        super().__init__("GlobalManager")
        self.skybox_color = (0.15, 0.25, 0.55)
        self.light_color = (1.0, 0.96, 0.9)
        self.light_intensity = 1.5
        self.light_direction = Vector3(0.4, 0.8, 0.3).normalize()
        self.shadow_strength = 0.55
        self.ambient_intensity = 0.4
    def get_type_name(self):
        return "GlobalManager"
    def get_properties(self):
        return {}
    def to_dict(self):
        d = super().to_dict()
        d["type"] = "GlobalManager"
        d["skybox_color"] = list(self.skybox_color)
        d["light_color"] = list(self.light_color)
        d["light_intensity"] = self.light_intensity
        d["light_direction"] = [self.light_direction.x, self.light_direction.y, self.light_direction.z]
        d["shadow_strength"] = self.shadow_strength
        d["ambient_intensity"] = self.ambient_intensity
        return d
    def from_dict(self, d):
        super().from_dict(d)
        sc = d.get("skybox_color")
        if sc: self.skybox_color = (sc[0], sc[1], sc[2])
        lc = d.get("light_color")
        if lc: self.light_color = (lc[0], lc[1], lc[2])
        if "light_intensity" in d: self.light_intensity = d["light_intensity"]
        ld = d.get("light_direction")
        if ld: self.light_direction = Vector3(ld[0], ld[1], ld[2]).normalize()
        if "shadow_strength" in d: self.shadow_strength = d["shadow_strength"]
        if "ambient_intensity" in d: self.ambient_intensity = d["ambient_intensity"]
    def render_scene(self): pass
    def render_selected(self): pass
