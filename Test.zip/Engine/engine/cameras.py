import glfw
import math
from OpenGL.GL import *
from OpenGL.GLU import *
from engine.math_utils import Vector3
from engine.collision import _euler_to_axes, _obb_overlap

class EditorCamera:
    def __init__(self):
        self.pos = Vector3(0, 6, 20)
        self.yaw = 30
        self.pitch = -20
        self.speed = 12
        self.mouse_sensitivity = 0.25
        self._sprint = 1.0
        self._move_time = 0.0
    def get_forward(self):
        return Vector3(
            math.sin(math.radians(self.yaw)) * math.cos(math.radians(self.pitch)),
            -math.sin(math.radians(self.pitch)),
            -math.cos(math.radians(self.yaw)) * math.cos(math.radians(self.pitch))
        ).normalize()
    def get_right(self):
        return Vector3(math.cos(math.radians(self.yaw)), 0, math.sin(math.radians(self.yaw))).normalize()
    def look_at(self):
        f = self.get_forward()
        target = self.pos + f
        gluLookAt(self.pos.x, self.pos.y, self.pos.z, target.x, target.y, target.z, 0, 1, 0)
    def update(self, keys, delta_time, right_drag=False, mouse_delta=None, scroll=0, arrow_delta=None):
        if right_drag and mouse_delta:
            self.yaw += mouse_delta[0] * self.mouse_sensitivity
            self.pitch += mouse_delta[1] * self.mouse_sensitivity
            self.pitch = max(-89, min(89, self.pitch))
        if arrow_delta:
            self.yaw += arrow_delta[0] * 60 * delta_time
            self.pitch += arrow_delta[1] * 60 * delta_time
            self.pitch = max(-89, min(89, self.pitch))
        f = self.get_forward()
        r = self.get_right()
        moving = any(keys.get(k) for k in (glfw.KEY_W, glfw.KEY_S, glfw.KEY_A, glfw.KEY_D))
        if moving:
            self._move_time += delta_time
        else:
            self._move_time = 0.0
        sprint = 2.5 if keys.get(glfw.KEY_LEFT_SHIFT) else 1.0
        ramp = 1.0 + self._move_time * 0.5
        spd = self.speed * sprint * ramp * delta_time
        m = Vector3(0, 0, 0)
        if keys.get(glfw.KEY_W): m = m + f * spd
        if keys.get(glfw.KEY_S): m = m - f * spd
        if keys.get(glfw.KEY_A): m = m - r * spd
        if keys.get(glfw.KEY_D): m = m + r * spd
        self.pos = self.pos + m
        fwd = self.get_forward()
        self.pos = self.pos + fwd * scroll * 3.0

class PlayerCamera:
    def __init__(self):
        self.pos = Vector3(0, 1.5, 0)
        self.velocity = Vector3(0, 0, 0)
        self.yaw = 0
        self.pitch = 0
        self.momentum_x = 0.0
        self.momentum_z = 0.0
        self.speed = 8.0
        self.mouse_sensitivity = 0.15
    def get_forward(self):
        return Vector3(
            math.sin(math.radians(self.yaw)) * math.cos(math.radians(self.pitch)),
            -math.sin(math.radians(self.pitch)),
            -math.cos(math.radians(self.yaw)) * math.cos(math.radians(self.pitch))
        ).normalize()
    def get_right(self):
        return Vector3(math.cos(math.radians(self.yaw)), 0, math.sin(math.radians(self.yaw))).normalize()
    def look_at(self):
        f = self.get_forward()
        target = self.pos + f
        gluLookAt(self.pos.x, self.pos.y, self.pos.z, target.x, target.y, target.z, 0, 1, 0)
    def check_collision(self, next_pos, objects):
        p_ext = (0.4, 1.5, 0.4)
        p_axes = [Vector3(1,0,0), Vector3(0,1,0), Vector3(0,0,1)]
        for obj in objects:
            if hasattr(obj, 'width') and hasattr(obj, 'height') and hasattr(obj, 'depth'):
                w, h, d = obj.width/2, obj.height/2, obj.depth/2
                rot = getattr(obj, 'rot', Vector3())
                if rot.x == 0 and rot.y == 0 and rot.z == 0:
                    o_min = (obj.pos.x - w, obj.pos.y - h, obj.pos.z - d)
                    o_max = (obj.pos.x + w, obj.pos.y + h, obj.pos.z + d)
                    if (next_pos.x - p_ext[0] < o_max[0] and next_pos.x + p_ext[0] > o_min[0] and
                        next_pos.y - p_ext[1] < o_max[1] and next_pos.y + p_ext[1] > o_min[1] and
                        next_pos.z - p_ext[2] < o_max[2] and next_pos.z + p_ext[2] > o_min[2]):
                        return True
                else:
                    o_axes = _euler_to_axes(rot.x, rot.y, rot.z)
                    if _obb_overlap(next_pos, p_ext, p_axes, obj.pos, (w, h, d), o_axes):
                        return True
        return False

    def resolve_collision(self, old_pos, desired, objects):
        result = Vector3(desired.x, desired.y, desired.z)
        p_ext = (0.4, 1.5, 0.4)
        p_axes = [Vector3(1,0,0), Vector3(0,1,0), Vector3(0,0,1)]
        grounded = False
        for _ in range(4):
            pushed = False
            for obj in objects:
                if not (hasattr(obj, 'width') and hasattr(obj, 'height') and hasattr(obj, 'depth')):
                    continue
                w, h, d = obj.width/2, obj.height/2, obj.depth/2
                rot = getattr(obj, 'rot', Vector3())
                if rot.x == 0 and rot.y == 0 and rot.z == 0:
                    o_min = Vector3(obj.pos.x - w, obj.pos.y - h, obj.pos.z - d)
                    o_max = Vector3(obj.pos.x + w, obj.pos.y + h, obj.pos.z + d)
                    overlap_x = min(result.x + p_ext[0] - o_min.x, o_max.x - (result.x - p_ext[0]))
                    overlap_y = min(result.y + p_ext[1] - o_min.y, o_max.y - (result.y - p_ext[1]))
                    overlap_z = min(result.z + p_ext[2] - o_min.z, o_max.z - (result.z - p_ext[2]))
                    if overlap_x <= 0 or overlap_y <= 0 or overlap_z <= 0:
                        continue
                    if overlap_x < overlap_y and overlap_x < overlap_z:
                        if result.x < obj.pos.x:
                            result.x = o_min.x - p_ext[0]
                        else:
                            result.x = o_max.x + p_ext[0]
                    elif overlap_y < overlap_z:
                        if result.y < obj.pos.y:
                            result.y = o_min.y - p_ext[1]
                        else:
                            result.y = o_max.y + p_ext[1]
                            grounded = True
                    else:
                        if result.z < obj.pos.z:
                            result.z = o_min.z - p_ext[2]
                        else:
                            result.z = o_max.z + p_ext[2]
                    pushed = True
                else:
                    ax, ay, az = _euler_to_axes(rot.x, rot.y, rot.z)
                    diff = result - obj.pos
                    local = [diff.dot(ax), diff.dot(ay), diff.dot(az)]
                    best_axis = None
                    best_overlap = 1e9
                    for test_n, test_ext in [(ax, w), (ay, h), (az, d)]:
                        obj_proj = test_ext
                        ply_proj = p_ext[0] * abs(p_axes[0].dot(test_n)) + p_ext[1] * abs(p_axes[1].dot(test_n)) + p_ext[2] * abs(p_axes[2].dot(test_n))
                        center_dist = abs(diff.dot(test_n))
                        overlap = obj_proj + ply_proj - center_dist
                        if overlap <= 0:
                            best_axis = None
                            break
                        if overlap < best_overlap:
                            best_overlap = overlap
                            sign = 1.0 if diff.dot(test_n) > 0 else -1.0
                            best_axis = test_n * sign
                    if best_axis is not None and best_overlap > 0:
                        for test_n, test_ext in [(Vector3(1,0,0), p_ext[0]), (Vector3(0,1,0), p_ext[1]), (Vector3(0,0,1), p_ext[2])]:
                            obj_proj = abs(ax.dot(test_n)) * w + abs(ay.dot(test_n)) * h + abs(az.dot(test_n)) * d
                            ply_proj = test_ext
                            center_dist = abs(diff.dot(test_n))
                            overlap = obj_proj + ply_proj - center_dist
                            if overlap <= 0:
                                best_axis = None
                                break
                            if overlap < best_overlap:
                                best_overlap = overlap
                                sign = 1.0 if diff.dot(test_n) > 0 else -1.0
                                best_axis = test_n * sign
                    if best_axis is not None and best_overlap > 0:
                        result = result + best_axis * best_overlap
                        if best_axis.y > 0.5:
                            grounded = True
                        pushed = True
            if not pushed:
                break
        return result, grounded
