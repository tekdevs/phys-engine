import sys
import os
from engine import Engine, Skybox, Vector3

if __name__ == "__main__":
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        g = Engine(width=1280, height=720, fov=90, fps_limit=144, retro_mode=False)
        blue = (0.25, 0.45, 0.8)
        g.skybox = Skybox(top_color=blue, horizon_color=blue, ground_color=blue)
        g.lighting.ambient_color = (0.3, 0.25, 0.35)
        g.lighting.diffuse_color = (0.7, 0.7, 0.8)
        g.lighting.specular_color = (0.4, 0.4, 0.5)
        g.lighting.light_direction = Vector3(1, 1.5, 0.5).normalize()
        g.load_scene(sys.argv[1])
        g.run()
    else:
        print("Usage: python -m engine <scene_file>")
