from OpenGL.GL import *
from engine.math_utils import Vector3

class LightingManager:
    def __init__(self):
        self.sun_color = (1.0, 0.96, 0.9)
        self.sun_intensity = 1.5
        self.sun_direction = Vector3(0.4, 0.8, 0.3).normalize()
        self.ambient_intensity = 0.4
        self.shadow_strength = 0.55

    def enable(self):
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        r, g, b = self.sun_color
        i = self.sun_intensity
        d = self.sun_direction
        glLightfv(GL_LIGHT0, GL_AMBIENT, (r * self.ambient_intensity, g * self.ambient_intensity, b * self.ambient_intensity, 1.0))
        glLightfv(GL_LIGHT0, GL_DIFFUSE, (r * i, g * i, b * i, 1.0))
        glLightfv(GL_LIGHT0, GL_SPECULAR, (min(1.0, r * i * 0.5), min(1.0, g * i * 0.5), min(1.0, b * i * 0.5), 1.0))
        glLightfv(GL_LIGHT0, GL_POSITION, (d.x, d.y, d.z, 0.0))
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_DIFFUSE)
        glShadeModel(GL_SMOOTH)

    def disable(self):
        glDisable(GL_LIGHTING)
        glDisable(GL_LIGHT0)
        glDisable(GL_COLOR_MATERIAL)

    def render_shadow_pass(self, nodes, camera):
        pass


class SimpleLighting:
    def __init__(self):
        self.ambient_color = (0.2, 0.2, 0.3)
        self.diffuse_color = (0.7, 0.7, 0.8)
        self.specular_color = (0.3, 0.3, 0.4)
        self.light_direction = Vector3(1, 1, 1).normalize()
    def enable(self):
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glLightfv(GL_LIGHT0, GL_AMBIENT, (*self.ambient_color, 1.0))
        glLightfv(GL_LIGHT0, GL_DIFFUSE, (*self.diffuse_color, 1.0))
        glLightfv(GL_LIGHT0, GL_SPECULAR, (*self.specular_color, 1.0))
        glLightfv(GL_LIGHT0, GL_POSITION, (self.light_direction.x, self.light_direction.y, self.light_direction.z, 0.0))
