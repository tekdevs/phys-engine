import math
from OpenGL.GL import *
from engine.math_utils import Vector3

class Pillar:
    def __init__(self, pos, height=1.0, width=1.0, depth=1.0, tex_id=0, color=None):
        self.pos = pos; self.height = height; self.width = width; self.depth = depth; self.tex_id = tex_id
        self.rot = Vector3()
        self.color = color if color else (1, 1, 1)
    def draw(self):
        glPushMatrix()
        glTranslatef(self.pos.x, self.pos.y, self.pos.z)
        if self.rot.x or self.rot.y or self.rot.z:
            glRotatef(self.rot.x, 1, 0, 0)
            glRotatef(self.rot.y, 0, 1, 0)
            glRotatef(self.rot.z, 0, 0, 1)
        if self.tex_id:
            glColor3f(1, 1, 1)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.tex_id)
        else:
            glColor3f(self.color[0], self.color[1], self.color[2])
            glDisable(GL_TEXTURE_2D)
        glDisable(GL_CULL_FACE)
        w, h, d = self.width/2, self.height/2, self.depth/2
        glBegin(GL_QUADS)
        glNormal3f(0,0,1)
        glTexCoord2f(0,0); glVertex3f(-w,-h, d)
        glTexCoord2f(1,0); glVertex3f( w,-h, d)
        glTexCoord2f(1,1); glVertex3f( w, h, d)
        glTexCoord2f(0,1); glVertex3f(-w, h, d)
        glNormal3f(0,0,-1)
        glTexCoord2f(0,0); glVertex3f( w,-h,-d)
        glTexCoord2f(1,0); glVertex3f(-w,-h,-d)
        glTexCoord2f(1,1); glVertex3f(-w, h,-d)
        glTexCoord2f(0,1); glVertex3f( w, h,-d)
        glNormal3f(-1,0,0)
        glTexCoord2f(0,0); glVertex3f(-w,-h,-d)
        glTexCoord2f(1,0); glVertex3f(-w,-h, d)
        glTexCoord2f(1,1); glVertex3f(-w, h, d)
        glTexCoord2f(0,1); glVertex3f(-w, h,-d)
        glNormal3f(1,0,0)
        glTexCoord2f(0,0); glVertex3f( w,-h, d)
        glTexCoord2f(1,0); glVertex3f( w,-h,-d)
        glTexCoord2f(1,1); glVertex3f( w, h,-d)
        glTexCoord2f(0,1); glVertex3f( w, h, d)
        glNormal3f(0,1,0)
        glTexCoord2f(0,0); glVertex3f(-w, h,-d)
        glTexCoord2f(1,0); glVertex3f(-w, h, d)
        glTexCoord2f(1,1); glVertex3f( w, h, d)
        glTexCoord2f(0,1); glVertex3f( w, h,-d)
        glNormal3f(0,-1,0)
        glTexCoord2f(0,0); glVertex3f(-w,-h, d)
        glTexCoord2f(1,0); glVertex3f( w,-h, d)
        glTexCoord2f(1,1); glVertex3f( w,-h,-d)
        glTexCoord2f(0,1); glVertex3f(-w,-h,-d)
        glEnd()
        glEnable(GL_CULL_FACE)
        glDisable(GL_TEXTURE_2D)
        glPopMatrix()

class Sphere:
    def __init__(self, pos, radius=0.5, tex_id=0):
        self.pos = pos
        self.radius = radius
        self.width = radius * 2
        self.height = radius * 2
        self.depth = radius * 2
        self.tex_id = tex_id
        self.rot = Vector3()
        self.scale = Vector3(radius * 2, radius * 2, radius * 2)
    def draw(self):
        glPushMatrix()
        glColor3f(1, 1, 1)
        if self.tex_id:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.tex_id)
        else:
            glDisable(GL_TEXTURE_2D)
        slices = 12
        stacks = 8
        r = self.radius
        glBegin(GL_TRIANGLES)
        for i in range(stacks):
            phi0 = math.pi * i / stacks
            phi1 = math.pi * (i + 1) / stacks
            for j in range(slices):
                theta0 = 2.0 * math.pi * j / slices
                theta1 = 2.0 * math.pi * (j + 1) / slices
                v0 = (math.sin(phi0)*math.cos(theta0), math.cos(phi0), math.sin(phi0)*math.sin(theta0))
                v1 = (math.sin(phi1)*math.cos(theta0), math.cos(phi1), math.sin(phi1)*math.sin(theta0))
                v2 = (math.sin(phi1)*math.cos(theta1), math.cos(phi1), math.sin(phi1)*math.sin(theta1))
                v3 = (math.sin(phi0)*math.cos(theta1), math.cos(phi0), math.sin(phi0)*math.sin(theta1))
                glNormal3f(*v0); glVertex3f(v0[0]*r, v0[1]*r, v0[2]*r)
                glNormal3f(*v1); glVertex3f(v1[0]*r, v1[1]*r, v1[2]*r)
                glNormal3f(*v2); glVertex3f(v2[0]*r, v2[1]*r, v2[2]*r)
                glNormal3f(*v0); glVertex3f(v0[0]*r, v0[1]*r, v0[2]*r)
                glNormal3f(*v2); glVertex3f(v2[0]*r, v2[1]*r, v2[2]*r)
                glNormal3f(*v3); glVertex3f(v3[0]*r, v3[1]*r, v3[2]*r)
        glEnd()
        glDisable(GL_TEXTURE_2D)
        glPopMatrix()

class Platform:
    def __init__(self, size=150, grid_size=10, tex_id=0, color=None):
        self.size = size; self.grid_size = grid_size; self.tex_id = tex_id
        self.pos = Vector3(0, -0.1, 0)
        self.color = color if color else (1, 1, 1)
    def draw(self):
        glPushMatrix()
        if self.tex_id:
            glColor3f(1, 1, 1)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.tex_id)
        else:
            glColor3f(self.color[0], self.color[1], self.color[2])
            glDisable(GL_TEXTURE_2D)
        hs = self.size/2; step = self.size/self.grid_size
        glBegin(GL_QUADS)
        glNormal3f(0,1,0)
        for iz in range(self.grid_size):
            for ix in range(self.grid_size):
                x0 = -hs + ix*step; z0 = -hs + iz*step
                glTexCoord2f(0,0); glVertex3f(x0, -0.1, z0+step)
                glTexCoord2f(1,0); glVertex3f(x0+step, -0.1, z0+step)
                glTexCoord2f(1,1); glVertex3f(x0+step, -0.1, z0)
                glTexCoord2f(0,1); glVertex3f(x0, -0.1, z0)
        glEnd()
        glDisable(GL_TEXTURE_2D)
        glPopMatrix()

class Ceiling:
    def __init__(self, size=150, tex_id=0):
        self.size = size; self.tex_id = tex_id; self.pos = Vector3(0, 14, 0)
    def draw(self):
        glPushMatrix()
        glColor3f(1, 1, 1)
        if self.tex_id:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.tex_id)
        else:
            glDisable(GL_TEXTURE_2D)
        hs = self.size/2
        glBegin(GL_QUADS)
        glNormal3f(0,-1,0)
        glTexCoord2f(0,0); glVertex3f(-hs, 14, -hs)
        glTexCoord2f(10,0); glVertex3f(hs, 14, -hs)
        glTexCoord2f(10,10); glVertex3f(hs, 14, hs)
        glTexCoord2f(0,10); glVertex3f(-hs, 14, hs)
        glEnd()
        glDisable(GL_TEXTURE_2D)
        glPopMatrix()

def _draw_box_outline(p, w, h, d, offset=0.04):
    """Draw wireframe box outline around a box at position p with half-extents w,h,d"""
    ow, oh, od = w + offset, h + offset, d + offset
    corners = [
        (-ow, -oh, -od), (ow, -oh, -od), (ow, oh, -od), (-ow, oh, -od),
        (-ow, -oh,  od), (ow, -oh,  od), (ow, oh,  od), (-ow, oh,  od),
    ]
    edges = [
        (0,1),(1,2),(2,3),(3,0),
        (4,5),(5,6),(6,7),(7,4),
        (0,4),(1,5),(2,6),(3,7),
    ]
    glBegin(GL_LINES)
    for a, b in edges:
        ca, cb = corners[a], corners[b]
        glVertex3f(p.x+ca[0], p.y+ca[1], p.z+ca[2])
        glVertex3f(p.x+cb[0], p.y+cb[1], p.z+cb[2])
    glEnd()

def _draw_sphere_outline(p, r, offset=0.04):
    """Draw 3 circles around a sphere"""
    r2 = r + offset
    segs = 32
    for plane in range(3):
        glBegin(GL_LINE_LOOP)
        for i in range(segs):
            a = 2 * math.pi * i / segs
            c, s = math.cos(a) * r2, math.sin(a) * r2
            if plane == 0:
                glVertex3f(p.x + c, p.y + s, p.z)
            elif plane == 1:
                glVertex3f(p.x + c, p.y, p.z + s)
            else:
                glVertex3f(p.x, p.y + c, p.z + s)
        glEnd()
