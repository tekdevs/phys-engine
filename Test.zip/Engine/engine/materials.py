import os
from OpenGL.GL import *
from PIL import Image

class Material:
    def __init__(self, name="Default"):
        self.name = name
        self.albedo_color = (1.0, 1.0, 1.0)
        self.albedo_texture = ""
        self.tex_id = 0
        self.tiling_u = 1.0
        self.tiling_v = 1.0
        self.offset_u = 0.0
        self.offset_v = 0.0
        self.shininess = 32.0
        self.specular = (0.5, 0.5, 0.5)
    def to_dict(self):
        return {"name": self.name, "albedo_color": list(self.albedo_color),
                "albedo_texture": self.albedo_texture,
                "tiling_u": self.tiling_u, "tiling_v": self.tiling_v,
                "offset_u": self.offset_u, "offset_v": self.offset_v,
                "shininess": self.shininess, "specular": list(self.specular)}
    @staticmethod
    def from_dict(d):
        mat = Material(d.get("name", "Default"))
        c = d.get("albedo_color")
        if c: mat.albedo_color = (c[0], c[1], c[2])
        mat.albedo_texture = d.get("albedo_texture", "")
        mat.tiling_u = d.get("tiling_u", 1.0)
        mat.tiling_v = d.get("tiling_v", 1.0)
        mat.offset_u = d.get("offset_u", 0.0)
        mat.offset_v = d.get("offset_v", 0.0)
        mat.shininess = d.get("shininess", 32.0)
        sc = d.get("specular")
        if sc: mat.specular = (sc[0], sc[1], sc[2])
        return mat
    def load_texture(self, asset_root):
        if self.tex_id:
            try: glDeleteTextures(1, [self.tex_id])
            except: pass
            self.tex_id = 0
        if not self.albedo_texture:
            return
        path = os.path.join(asset_root, self.albedo_texture)
        if not os.path.isfile(path):
            return
        try:
            img = Image.open(path).convert("RGBA")
            data = img.tobytes("raw", "RGBA", 0, -1)
            tex = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, tex)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
            self.tex_id = tex
        except Exception as e:
            print(f"Failed to load texture {path}: {e}")
    def apply(self):
        if self.tex_id:
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, self.tex_id)
            glMatrixMode(GL_TEXTURE)
            glLoadIdentity()
            glTranslatef(self.offset_u, self.offset_v, 0.0)
            glScalef(self.tiling_u, self.tiling_v, 1.0)
            glMatrixMode(GL_MODELVIEW)
        else:
            glDisable(GL_TEXTURE_2D)
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, (*self.specular, 1.0))
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, self.shininess)
    def cleanup_tex(self):
        if self.tex_id:
            try: glDeleteTextures(1, [self.tex_id])
            except: pass
            self.tex_id = 0
