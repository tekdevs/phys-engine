from OpenGL.GL import *
from PIL import Image, ImageDraw, ImageFont

texture_cache = {}

def get_text_tex(text, font_size=12, color=(255, 255, 255, 255)):
    key = (text, font_size, color)
    if key in texture_cache:
        return texture_cache[key]
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()
    dummy = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
    bbox = ImageDraw.Draw(dummy).textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0] + 4
    th = bbox[3] - bbox[1] + 4
    img = Image.new('RGBA', (tw, th), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.text((2, 2), text, font=font, fill=color)
    data = img.tobytes("raw", "RGBA", 0, -1)
    tex = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, tex)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
    result = (tex, img.width, img.height)
    texture_cache[key] = result
    return result

def make_tex(c1, c2, size=64):
    from PIL import Image
    img = Image.new('RGB', (size, size))
    for y in range(size):
        for x in range(size):
            col = c1 if (x//8 + y//8) % 2 == 0 else c2
            img.putpixel((x, y), col)
    data = img.tobytes("raw", "RGB", 0, -1)
    tex = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, tex)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, data)
    return tex

def load_sprite(path):
    try:
        img = Image.open(path).convert("RGBA")
        data = img.tobytes("raw", "RGBA", 0, -1)
        tex = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
        return tex, img.width, img.height
    except Exception as e:
        print(f"Failed to load sprite {path}: {e}")
        return 0, 0, 0
