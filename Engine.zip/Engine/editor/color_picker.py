from __future__ import annotations
import math
from OpenGL.GL import *
from editor.constants import (
    TEXT_COLOR, TEXT_DIM, TEXT_BRIGHT, PANEL_BORDER, FONT_SZ_SM, FONT_SZ_LG,
    get_text_tex,
)


class ColorPickerMixin:
    def _open_color_picker(self, color, callback, target="skybox"):
        self._color_picker_active = True
        self._color_picker_color = list(color)
        self._color_picker_original = list(color)
        self._color_picker_callback = callback
        self._color_picker_target = target

    def _on_skybox_color_picked(self, color):
        gm = self.global_manager
        gm.skybox_color = tuple(color)
        self._sync_global_manager()

    def _on_light_color_picked(self, color):
        gm = self.global_manager
        gm.light_color = tuple(color)
        self._sync_global_manager()

    def _hsv_to_rgb(self, h, s, v):
        if s == 0.0:
            return (v, v, v)
        i = int(h * 6.0)
        f = (h * 6.0) - i
        p = v * (1.0 - s)
        q = v * (1.0 - s * f)
        t = v * (1.0 - s * (1.0 - f))
        i %= 6
        if i == 0: return (v, t, p)
        if i == 1: return (q, v, p)
        if i == 2: return (p, v, t)
        if i == 3: return (p, q, v)
        if i == 4: return (t, p, v)
        return (v, p, q)

    def _rgb_to_hsv(self, r, g, b):
        mx = max(r, g, b)
        mn = min(r, g, b)
        d = mx - mn
        v = mx
        s = 0.0 if mx == 0 else d / mx
        if d == 0:
            h = 0.0
        elif mx == r:
            h = ((g - b) / d) % 6.0
        elif mx == g:
            h = (b - r) / d + 2.0
        else:
            h = (r - g) / d + 4.0
        h /= 6.0
        return (h, s, v)

    def _render_color_picker_dialog(self):
        if not self._color_picker_active:
            return
        dw, dh, dx, dy, wheel_r, wheel_cx, wheel_cy, bright_x, bright_y, bright_h = self._color_picker_layout()
        self._draw_rect(dx, dy, dw, dh, (0.1, 0.1, 0.12), (0.3, 0.3, 0.35))
        self._draw_text(dx + 15, dy + 12, "Pick Color", TEXT_COLOR, FONT_SZ_LG)
        c = self._color_picker_color
        h, s, v = self._rgb_to_hsv(c[0], c[1], c[2])
        wheel_r = 100
        wheel_cx = dx + 130
        wheel_cy = dy + 145
        step = 4
        for py in range(-wheel_r, wheel_r + 1, step):
            for px in range(-wheel_r, wheel_r + 1, step):
                dist = math.sqrt(px * px + py * py)
                if dist > wheel_r:
                    continue
                sh = math.atan2(py, px) / (2 * math.pi)
                if sh < 0:
                    sh += 1.0
                ss = dist / wheel_r
                rv = self._hsv_to_rgb(sh, ss, 1.0)
                self._draw_rect(wheel_cx + px, wheel_cy + py, step, step, rv)
        sel_angle = h * 2 * math.pi
        sel_dist = s * wheel_r
        sx = wheel_cx + math.cos(sel_angle) * sel_dist
        sy = wheel_cy + math.sin(sel_angle) * sel_dist
        self._draw_rect(sx - 4, sy - 4, 8, 8, (1, 1, 1), (0, 0, 0))
        bright_x = dx + 260
        bright_y = dy + 45
        bright_w = 30
        bright_h = 200
        for by in range(bright_h):
            bv = 1.0 - by / bright_h
            rv = self._hsv_to_rgb(h, s, bv)
            self._draw_rect(bright_x, bright_y + by, bright_w, 1, rv)
        self._draw_rect(bright_x - 1, bright_y - 1, bright_w + 2, bright_h + 2, (0.3, 0.3, 0.35), (0.4, 0.4, 0.45))
        knob_y = bright_y + int((1.0 - v) * bright_h) - 3
        self._draw_rect(bright_x - 3, knob_y, bright_w + 6, 6, (1, 1, 1), (0.5, 0.5, 0.5))
        preview_y = dy + dh - 80
        self._draw_rect(dx + 15, preview_y, dw - 30, 28, c, (0.5, 0.5, 0.5))
        self._draw_text(dx + 15, preview_y + 32, f"R:{c[0]:.2f}  G:{c[1]:.2f}  B:{c[2]:.2f}", TEXT_DIM, FONT_SZ_SM)
        btn_y = dy + dh - 35
        btn_w = 60
        ok_x = dx + dw - 140
        cancel_x = dx + dw - 70
        self._draw_rect(ok_x, btn_y, btn_w, 26, (0.2, 0.2, 0.25), PANEL_BORDER)
        ok_tw = get_text_tex("OK", FONT_SZ_SM, (255,255,255,255))[1]
        self._draw_text(ok_x + (btn_w - ok_tw) // 2, btn_y + 5, "OK", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(cancel_x, btn_y, btn_w, 26, (0.2, 0.2, 0.25), PANEL_BORDER)
        can_tw = get_text_tex("Cancel", FONT_SZ_SM, (255,255,255,255))[1]
        self._draw_text(cancel_x + (btn_w - can_tw) // 2, btn_y + 5, "Cancel", TEXT_COLOR, FONT_SZ_SM)

    def _color_picker_layout(self):
        dw, dh = 380, 370
        dx = (self.width - dw) // 2
        dy = (self.height - dh) // 2
        wheel_r = 100
        wheel_cx = dx + 130
        wheel_cy = dy + 145
        bright_x = dx + 260
        bright_y = dy + 45
        bright_h = 200
        return dw, dh, dx, dy, wheel_r, wheel_cx, wheel_cy, bright_x, bright_y, bright_h

    def _handle_color_picker_click(self, mx, my):
        if not self._color_picker_active:
            return False
        dw, dh, dx, dy, wheel_r, wheel_cx, wheel_cy, bright_x, bright_y, bright_h = self._color_picker_layout()
        btn_y = dy + dh - 35
        btn_w = 60
        ok_x = dx + dw - 140
        cancel_x = dx + dw - 70
        if ok_x <= mx <= ok_x + btn_w and btn_y <= my <= btn_y + 26:
            if self._color_picker_callback:
                self._color_picker_callback(self._color_picker_color)
            self._color_picker_active = False
            return True
        if cancel_x <= mx <= cancel_x + btn_w and btn_y <= my <= btn_y + 26:
            self._color_picker_color = list(self._color_picker_original)
            if self._color_picker_callback:
                self._color_picker_callback(self._color_picker_color)
            self._color_picker_active = False
            return True
        dx_c = mx - wheel_cx
        dy_c = my - wheel_cy
        dist = math.sqrt(dx_c * dx_c + dy_c * dy_c)
        if dist <= wheel_r:
            angle = math.atan2(dy_c, dx_c)
            h = angle / (2 * math.pi)
            if h < 0:
                h += 1.0
            s = dist / wheel_r
            _, _, v = self._rgb_to_hsv(*self._color_picker_color)
            self._color_picker_color = list(self._hsv_to_rgb(h, s, v))
            if self._color_picker_target in ("material_albedo", "material_specular"):
                self._apply_material_color_picker()
            else:
                self._sync_global_manager()
            return True
        if bright_x <= mx <= bright_x + 30 and bright_y <= my <= bright_y + bright_h:
            v = 1.0 - (my - bright_y) / bright_h
            v = max(0.0, min(1.0, v))
            h, s, _ = self._rgb_to_hsv(*self._color_picker_color)
            self._color_picker_color = list(self._hsv_to_rgb(h, s, v))
            if self._color_picker_target in ("material_albedo", "material_specular"):
                self._apply_material_color_picker()
            else:
                self._sync_global_manager()
            return True
        if not (dx <= mx <= dx + dw and dy <= my <= dy + dh):
            pass
        return True

    def _handle_color_picker_drag(self, mx, my):
        if not self._color_picker_active:
            return
        dw, dh, dx, dy, wheel_r, wheel_cx, wheel_cy, bright_x, bright_y, bright_h = self._color_picker_layout()
        dx_c = mx - wheel_cx
        dy_c = my - wheel_cy
        dist = math.sqrt(dx_c * dx_c + dy_c * dy_c)
        if dist <= wheel_r:
            angle = math.atan2(dy_c, dx_c)
            h = angle / (2 * math.pi)
            if h < 0:
                h += 1.0
            s = dist / wheel_r
            _, _, v = self._rgb_to_hsv(*self._color_picker_color)
            self._color_picker_color = list(self._hsv_to_rgb(h, s, v))
            if self._color_picker_target in ("material_albedo", "material_specular"):
                self._apply_material_color_picker()
            else:
                self._sync_global_manager()
            return
        if bright_x <= mx <= bright_x + 30 and bright_y <= my <= bright_y + bright_h:
            v = 1.0 - (my - bright_y) / bright_h
            v = max(0.0, min(1.0, v))
            h, s, _ = self._rgb_to_hsv(*self._color_picker_color)
            self._color_picker_color = list(self._hsv_to_rgb(h, s, v))
            if self._color_picker_target in ("material_albedo", "material_specular"):
                self._apply_material_color_picker()
            else:
                self._sync_global_manager()

    def _apply_material_color_picker(self):
        mat = self.materials.get(self._selected_material_name)
        if mat:
            c = tuple(self._color_picker_color)
            if self._color_picker_target == "material_albedo":
                mat.albedo_color = c
            elif self._color_picker_target == "material_specular":
                mat.specular = c

    def _on_material_albedo_picked(self, color):
        mat = self.materials.get(self._selected_material_name)
        if mat:
            mat.albedo_color = tuple(color)

    def _on_material_specular_picked(self, color):
        mat = self.materials.get(self._selected_material_name)
        if mat:
            mat.specular = tuple(color)
