from __future__ import annotations
import os
import glfw
from OpenGL.GL import *
from editor.constants import get_text_tex, FONT_SZ_SM


class InputMixin:
    def _char_callback(self, window, char):
        if self._dialog_active and self._dialog_items is None:
            ch = chr(char)
            if ch.isprintable():
                sr = None
                if self._dialog_sel is not None:
                    s, e = self._dialog_sel
                    sr = (min(s, e), max(s, e))
                if sr and sr[0] != sr[1]:
                    self._dialog_buffer = self._dialog_buffer[:sr[0]] + ch + self._dialog_buffer[sr[1]:]
                    self._dialog_cursor = sr[0] + 1
                    self._dialog_sel = None
                else:
                    self._dialog_buffer = self._dialog_buffer[:self._dialog_cursor] + ch + self._dialog_buffer[self._dialog_cursor:]
                    self._dialog_cursor += 1
                    self._dialog_sel = None
            return
        if self._material_edit_field is not None:
            ch = chr(char)
            if ch.isprintable():
                sr = None
                if self._material_edit_sel is not None:
                    s, e = self._material_edit_sel
                    sr = (min(s, e), max(s, e))
                if sr and sr[0] != sr[1]:
                    self._material_edit_buffer = self._material_edit_buffer[:sr[0]] + ch + self._material_edit_buffer[sr[1]:]
                    self._material_edit_cursor = sr[0] + 1
                    self._material_edit_sel = None
                else:
                    self._material_edit_buffer = self._material_edit_buffer[:self._material_edit_cursor] + ch + self._material_edit_buffer[self._material_edit_cursor:]
                    self._material_edit_cursor += 1
                    self._material_edit_sel = None
                self._material_edit_cursor_timer = 0.0
            return
        if self._editing_field is not None:
            ch = chr(char)
            if ch.isprintable():
                sr = None
                if self._edit_sel is not None:
                    s, e = self._edit_sel
                    sr = (min(s, e), max(s, e))
                if sr and sr[0] != sr[1]:
                    self._edit_buffer = self._edit_buffer[:sr[0]] + ch + self._edit_buffer[sr[1]:]
                    self._edit_cursor = sr[0] + 1
                    self._edit_sel = None
                else:
                    self._edit_buffer = self._edit_buffer[:self._edit_cursor] + ch + self._edit_buffer[self._edit_cursor:]
                    self._edit_cursor += 1
                    self._edit_sel = None
                self._edit_cursor_timer = 0.0

    def _text_drag_update(self, mx, my):
        if self._editing_field is not None:
            x = self.width - self.inspector_width
            pw = self.inspector_width
            pad = 10
            label_w = 60
            field_x = x + label_w
            field_w = pw - label_w - pad
            text = self._edit_buffer
            if self._edit_sel is None:
                self._edit_sel = (self._edit_cursor, self._edit_cursor)
            s, e = self._edit_sel
            hit = self._hit_test_text_field(mx, my, field_x, field_w)
            if hit is not None:
                self._edit_sel = (s, hit)
                self._edit_cursor = hit
        elif self._material_edit_field is not None:
            x = self.width - self.inspector_width
            pw = self.inspector_width
            pad = 6
            label_w = 55
            field_x = x + label_w
            field_w = pw - label_w - pad
            if self._material_edit_sel is None:
                self._material_edit_sel = (self._material_edit_cursor, self._material_edit_cursor)
            s, e = self._material_edit_sel
            hit = self._hit_test_text_field(mx, my, field_x, field_w)
            if hit is not None:
                self._material_edit_sel = (s, hit)
                self._material_edit_cursor = hit

    def _hit_test_text_field(self, mx, my, field_x, field_w):
        text = self._edit_buffer if self._editing_field is not None else (self._material_edit_buffer if self._material_edit_field is not None else "")
        if not text:
            return 0
        for i in range(len(text) + 1):
            tw = get_text_tex(text[:i], FONT_SZ_SM, (255,255,255,255))[1]
            px = field_x + 4 + tw
            if mx <= px:
                return i
        return len(text)

    def _resize_callback(self, window, w, h):
        self.width = w
        self.height = h

    def _cursor_callback(self, window, x, y):
        self.mouse_x = x
        self.mouse_y = y
        if self.left_dragging and (self._editing_field is not None or self._material_edit_field is not None or (self._dialog_active and self._dialog_items is None)):
            self._text_drag_update(x, y)
        if self.left_dragging and self._border_drag:
            return
        if self.left_dragging and self._asset_border_drag:
            glfw.set_cursor(self.window, self._cursor_vresize)
            return
        if self.left_dragging and self._asset_tree_drag:
            glfw.set_cursor(self.window, self._cursor_hresize)
            return
        asset_top = self.height - 24 - self.asset_height
        if y >= asset_top and y < self.height - 24:
            tw = self.asset_tree_width
            if abs(x - tw) < 4:
                glfw.set_cursor(self.window, self._cursor_hresize)
                return
        if abs(y - asset_top) < 4 and x < self.width:
            glfw.set_cursor(self.window, self._cursor_vresize)
            return
        if y > 40 and y < asset_top:
            hier_edge = self.hierarchy_width
            insp_edge = self.width - self.inspector_width
            if abs(x - hier_edge) < 5 or abs(x - insp_edge) < 5:
                glfw.set_cursor(self.window, self._cursor_hresize)
                return
        glfw.set_cursor(self.window, self._cursor_arrow)

    def _mouse_callback(self, window, button, action, mods):
        if button == glfw.MOUSE_BUTTON_RIGHT:
            if action == glfw.PRESS:
                in_viewport = self._mouse_in_viewport(self.mouse_x, self.mouse_y)
                self.right_dragging = in_viewport
                if not in_viewport:
                    asset_top = self.height - 24 - self.asset_height
                    if self.mouse_y >= asset_top and self.mouse_y < self.height - 24:
                        self._handle_asset_right_click(self.mouse_x, self.mouse_y)
                    elif self.mouse_y > 40 and self.mouse_y < asset_top and self.mouse_x < self.hierarchy_width:
                        self._handle_hierarchy_right_click(self.mouse_x, self.mouse_y)
            else:
                self.right_dragging = False
        if button == glfw.MOUSE_BUTTON_MIDDLE:
            self.middle_dragging = (action == glfw.PRESS)
        if button == glfw.MOUSE_BUTTON_LEFT:
            self.left_dragging = (action == glfw.PRESS)
            if action == glfw.PRESS:
                asset_top = self.height - 24 - self.asset_height
                if self.mouse_y > 40 and self.mouse_y < asset_top:
                    hier_edge = self.hierarchy_width
                    insp_edge = self.width - self.inspector_width
                    if abs(self.mouse_x - hier_edge) < 5:
                        self._border_drag = "hierarchy"
                        self._border_drag_start_x = self.mouse_x
                        self._border_drag_start_w = self.hierarchy_width
                        return
                    if abs(self.mouse_x - insp_edge) < 5:
                        self._border_drag = "inspector"
                        self._border_drag_start_x = self.mouse_x
                        self._border_drag_start_w = self.inspector_width
                        return
                if self._handle_asset_border_click(self.mouse_x, self.mouse_y):
                    return
                if self._handle_asset_tree_click_border(self.mouse_x, self.mouse_y):
                    return
                self._handle_left_click()
            else:
                self._border_drag = None
                self.gizmo.end_drag()
                self.dragging_value = None

    def _scroll_callback(self, window, x, y):
        if self._dialog_active and self._dialog_items is not None:
            self._dialog_scroll = max(0, self._dialog_scroll - y * 22)
            return
        asset_top = self.height - 24 - self.asset_height
        if self.mouse_y >= asset_top and self.mouse_y < self.height - 24:
            self._handle_asset_scroll(y, self.mouse_x)
            return
        if self.mouse_x < self.hierarchy_width and self.mouse_y > 40 and self.mouse_y < asset_top:
            self._hierarchy_scroll_target -= y * 26
            self._hierarchy_scroll_target = max(0, self._hierarchy_scroll_target)
        else:
            self.camera.update({}, self.delta_time, scroll=y)

    def _key_callback(self, window, key, scancode, action, mods):
        if self._dialog_active:
            if action == glfw.PRESS or action == glfw.REPEAT:
                if self._dialog_items is not None:
                    if key == glfw.KEY_UP:
                        idx = int(self._dialog_buffer) if self._dialog_buffer.isdigit() else 0
                        self._dialog_buffer = str(max(0, idx - 1))
                    elif key == glfw.KEY_DOWN:
                        idx = int(self._dialog_buffer) if self._dialog_buffer.isdigit() else 0
                        self._dialog_buffer = str(min(len(self._dialog_items) - 1, idx + 1))
                    elif key == glfw.KEY_ENTER or key == glfw.KEY_KP_ENTER:
                        idx = int(self._dialog_buffer) if self._dialog_buffer.isdigit() else 0
                        if 0 <= idx < len(self._dialog_items) and self._dialog_callback:
                            self._dialog_callback(self._dialog_items[idx])
                        self._close_dialog()
                    elif key == glfw.KEY_ESCAPE:
                        self._close_dialog()
                else:
                    ctrl = mods & glfw.MOD_CONTROL
                    shift = mods & glfw.MOD_SHIFT
                    if key == glfw.KEY_ENTER or key == glfw.KEY_KP_ENTER:
                        if self._dialog_callback:
                            self._dialog_callback(self._dialog_buffer.strip())
                        self._close_dialog()
                    elif key == glfw.KEY_ESCAPE:
                        self._close_dialog()
                    elif ctrl and key == glfw.KEY_A:
                        self._dialog_sel = (0, len(self._dialog_buffer))
                        self._dialog_cursor = len(self._dialog_buffer)
                    elif key == glfw.KEY_BACKSPACE:
                        sr = None
                        if self._dialog_sel is not None:
                            s, e = self._dialog_sel
                            sr = (min(s, e), max(s, e))
                        if sr and sr[0] != sr[1]:
                            self._dialog_buffer = self._dialog_buffer[:sr[0]] + self._dialog_buffer[sr[1]:]
                            self._dialog_cursor = sr[0]
                            self._dialog_sel = None
                        elif self._dialog_cursor > 0:
                            self._dialog_buffer = self._dialog_buffer[:self._dialog_cursor-1] + self._dialog_buffer[self._dialog_cursor:]
                            self._dialog_cursor -= 1
                            self._dialog_sel = None
                    elif key == glfw.KEY_DELETE:
                        sr = None
                        if self._dialog_sel is not None:
                            s, e = self._dialog_sel
                            sr = (min(s, e), max(s, e))
                        if sr and sr[0] != sr[1]:
                            self._dialog_buffer = self._dialog_buffer[:sr[0]] + self._dialog_buffer[sr[1]:]
                            self._dialog_cursor = sr[0]
                            self._dialog_sel = None
                        elif self._dialog_cursor < len(self._dialog_buffer):
                            self._dialog_buffer = self._dialog_buffer[:self._dialog_cursor] + self._dialog_buffer[self._dialog_cursor+1:]
                            self._dialog_sel = None
                    elif key == glfw.KEY_LEFT:
                        if shift:
                            if self._dialog_sel is None:
                                self._dialog_sel = (self._dialog_cursor, self._dialog_cursor - 1)
                            else:
                                s, e = self._dialog_sel
                                self._dialog_sel = (s, e - 1)
                            self._dialog_cursor = self._dialog_sel[1] if self._dialog_sel else 0
                        else:
                            if self._dialog_sel is not None:
                                s, e = self._dialog_sel
                                self._dialog_cursor = min(s, e)
                                self._dialog_sel = None
                            elif self._dialog_cursor > 0:
                                self._dialog_cursor -= 1
                    elif key == glfw.KEY_RIGHT:
                        if shift:
                            if self._dialog_sel is None:
                                self._dialog_sel = (self._dialog_cursor, self._dialog_cursor + 1)
                            else:
                                s, e = self._dialog_sel
                                self._dialog_sel = (s, e + 1)
                            self._dialog_cursor = self._dialog_sel[1] if self._dialog_sel else len(self._dialog_buffer)
                        else:
                            if self._dialog_sel is not None:
                                s, e = self._dialog_sel
                                self._dialog_cursor = max(s, e)
                                self._dialog_sel = None
                            elif self._dialog_cursor < len(self._dialog_buffer):
                                self._dialog_cursor += 1
                    elif key == glfw.KEY_HOME:
                        self._dialog_cursor = 0
                        self._dialog_sel = None
                    elif key == glfw.KEY_END:
                        self._dialog_cursor = len(self._dialog_buffer)
                        self._dialog_sel = None
            return
        if self._material_edit_field is not None:
            if action == glfw.PRESS or action == glfw.REPEAT:
                ctrl = mods & glfw.MOD_CONTROL
                shift = mods & glfw.MOD_SHIFT
                if key == glfw.KEY_ENTER or key == glfw.KEY_KP_ENTER:
                    self._finish_material_editing()
                elif key == glfw.KEY_ESCAPE:
                    self._material_edit_field = None
                    self._material_edit_buffer = ""
                    self._material_edit_cursor = 0
                    self._material_edit_sel = None
                elif ctrl and key == glfw.KEY_A:
                    self._material_edit_sel = (0, len(self._material_edit_buffer))
                    self._material_edit_cursor = len(self._material_edit_buffer)
                elif ctrl and key == glfw.KEY_Z:
                    self._material_edit_field = None
                    self._material_edit_buffer = ""
                    self._material_edit_cursor = 0
                    self._material_edit_sel = None
                    return
                elif ctrl and key == glfw.KEY_Y:
                    return
                elif key == glfw.KEY_BACKSPACE:
                    sr = None
                    if self._material_edit_sel is not None:
                        s, e = self._material_edit_sel
                        sr = (min(s, e), max(s, e))
                    if sr and sr[0] != sr[1]:
                        self._material_edit_buffer = self._material_edit_buffer[:sr[0]] + self._material_edit_buffer[sr[1]:]
                        self._material_edit_cursor = sr[0]
                        self._material_edit_sel = None
                    elif self._material_edit_cursor > 0:
                        self._material_edit_buffer = self._material_edit_buffer[:self._material_edit_cursor-1] + self._material_edit_buffer[self._material_edit_cursor:]
                        self._material_edit_cursor -= 1
                        self._material_edit_sel = None
                    self._material_edit_cursor_timer = 0.0
                elif key == glfw.KEY_DELETE:
                    sr = None
                    if self._material_edit_sel is not None:
                        s, e = self._material_edit_sel
                        sr = (min(s, e), max(s, e))
                    if sr and sr[0] != sr[1]:
                        self._material_edit_buffer = self._material_edit_buffer[:sr[0]] + self._material_edit_buffer[sr[1]:]
                        self._material_edit_cursor = sr[0]
                        self._material_edit_sel = None
                    elif self._material_edit_cursor < len(self._material_edit_buffer):
                        self._material_edit_buffer = self._material_edit_buffer[:self._material_edit_cursor] + self._material_edit_buffer[self._material_edit_cursor+1:]
                        self._material_edit_sel = None
                    self._material_edit_cursor_timer = 0.0
                elif key == glfw.KEY_LEFT:
                    if shift:
                        if self._material_edit_sel is None:
                            self._material_edit_sel = (self._material_edit_cursor, self._material_edit_cursor - 1)
                        else:
                            s, e = self._material_edit_sel
                            self._material_edit_sel = (s, e - 1)
                        self._material_edit_cursor = self._material_edit_sel[1] if self._material_edit_sel else 0
                    else:
                        if self._material_edit_sel is not None:
                            s, e = self._material_edit_sel
                            self._material_edit_cursor = min(s, e)
                            self._material_edit_sel = None
                        elif self._material_edit_cursor > 0:
                            self._material_edit_cursor -= 1
                    self._material_edit_cursor_timer = 0.0
                elif key == glfw.KEY_RIGHT:
                    if shift:
                        if self._material_edit_sel is None:
                            self._material_edit_sel = (self._material_edit_cursor, self._material_edit_cursor + 1)
                        else:
                            s, e = self._material_edit_sel
                            self._material_edit_sel = (s, e + 1)
                        self._material_edit_cursor = self._material_edit_sel[1] if self._material_edit_sel else len(self._material_edit_buffer)
                    else:
                        if self._material_edit_sel is not None:
                            s, e = self._material_edit_sel
                            self._material_edit_cursor = max(s, e)
                            self._material_edit_sel = None
                        elif self._material_edit_cursor < len(self._material_edit_buffer):
                            self._material_edit_cursor += 1
                    self._material_edit_cursor_timer = 0.0
                elif key == glfw.KEY_HOME:
                    self._material_edit_cursor = 0
                    self._material_edit_sel = None
                    self._material_edit_cursor_timer = 0.0
                elif key == glfw.KEY_END:
                    self._material_edit_cursor = len(self._material_edit_buffer)
                    self._material_edit_sel = None
                    self._material_edit_cursor_timer = 0.0
            return
        if self._editing_field is not None:
            if action == glfw.PRESS or action == glfw.REPEAT:
                ctrl = mods & glfw.MOD_CONTROL
                shift = mods & glfw.MOD_SHIFT
                if ctrl:
                    if key == glfw.KEY_S:
                        self._finish_editing()
                        self._save_dialog()
                        return
                    elif key == glfw.KEY_Z:
                        self._cancel_editing()
                        return
                    elif key == glfw.KEY_Y:
                        self._cancel_editing()
                        return
                    elif key == glfw.KEY_A:
                        self._edit_sel = (0, len(self._edit_buffer))
                        self._edit_cursor = len(self._edit_buffer)
                        return
                if key == glfw.KEY_ENTER or key == glfw.KEY_KP_ENTER:
                    self._finish_editing()
                elif key == glfw.KEY_ESCAPE:
                    self._cancel_editing()
                elif key == glfw.KEY_BACKSPACE:
                    sr = None
                    if self._edit_sel is not None:
                        s, e = self._edit_sel
                        sr = (min(s, e), max(s, e))
                    if sr and sr[0] != sr[1]:
                        self._edit_buffer = self._edit_buffer[:sr[0]] + self._edit_buffer[sr[1]:]
                        self._edit_cursor = sr[0]
                        self._edit_sel = None
                    elif self._edit_cursor > 0:
                        self._edit_buffer = self._edit_buffer[:self._edit_cursor-1] + self._edit_buffer[self._edit_cursor:]
                        self._edit_cursor -= 1
                        self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                elif key == glfw.KEY_DELETE:
                    sr = None
                    if self._edit_sel is not None:
                        s, e = self._edit_sel
                        sr = (min(s, e), max(s, e))
                    if sr and sr[0] != sr[1]:
                        self._edit_buffer = self._edit_buffer[:sr[0]] + self._edit_buffer[sr[1]:]
                        self._edit_cursor = sr[0]
                        self._edit_sel = None
                    elif self._edit_cursor < len(self._edit_buffer):
                        self._edit_buffer = self._edit_buffer[:self._edit_cursor] + self._edit_buffer[self._edit_cursor+1:]
                        self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                elif key == glfw.KEY_LEFT:
                    if shift:
                        if self._edit_sel is None:
                            self._edit_sel = (self._edit_cursor, self._edit_cursor - 1)
                        else:
                            s, e = self._edit_sel
                            self._edit_sel = (s, e - 1)
                        self._edit_cursor = max(0, self._edit_sel[1]) if self._edit_sel else 0
                    else:
                        if self._edit_sel is not None:
                            s, e = self._edit_sel
                            self._edit_cursor = min(s, e)
                            self._edit_sel = None
                        elif self._edit_cursor > 0:
                            self._edit_cursor -= 1
                    self._edit_cursor_timer = 0.0
                elif key == glfw.KEY_RIGHT:
                    if shift:
                        if self._edit_sel is None:
                            self._edit_sel = (self._edit_cursor, self._edit_cursor + 1)
                        else:
                            s, e = self._edit_sel
                            self._edit_sel = (s, e + 1)
                        self._edit_cursor = min(len(self._edit_buffer), self._edit_sel[1]) if self._edit_sel else len(self._edit_buffer)
                    else:
                        if self._edit_sel is not None:
                            s, e = self._edit_sel
                            self._edit_cursor = max(s, e)
                            self._edit_sel = None
                        elif self._edit_cursor < len(self._edit_buffer):
                            self._edit_cursor += 1
                    self._edit_cursor_timer = 0.0
                elif key == glfw.KEY_HOME:
                    self._edit_cursor = 0
                    self._edit_sel = None
                    self._edit_cursor_timer = 0.0
                elif key == glfw.KEY_END:
                    self._edit_cursor = len(self._edit_buffer)
                    self._edit_sel = None
                    self._edit_cursor_timer = 0.0
            return
        if self._hierarchy_scroll_drag:
            return
        if action == glfw.PRESS:
            ctrl = mods & glfw.MOD_CONTROL
            if key == glfw.KEY_DELETE or key == glfw.KEY_BACKSPACE:
                if not self._asset_selected_set and not self._material_edit_field:
                    self._delete_selected()
            elif ctrl:
                if key == glfw.KEY_S:
                    self._save_dialog()
                elif key == glfw.KEY_O:
                    self._load_dialog()
                elif key == glfw.KEY_N:
                    self._new_project_dialog()
                elif key == glfw.KEY_Z:
                    self._undo()
                elif key == glfw.KEY_Y:
                    self._redo()
                elif key == glfw.KEY_D:
                    self._duplicate_selected()
                elif key == glfw.KEY_C:
                    self._copy_selected()
                elif key == glfw.KEY_V:
                    self._paste_clipboard()
            elif key == glfw.KEY_E:
                self.gizmo.mode = "translate"
            elif key == glfw.KEY_R:
                self.gizmo.mode = "rotate"
            elif key == glfw.KEY_F:
                self.gizmo.mode = "scale"
            elif key == glfw.KEY_G and self.selected_node:
                p = self.selected_node.get_world_pos()
                fwd = self.camera.get_forward()
                d = (p - self.camera.pos).length()
                self.camera.pos = p - fwd * max(d, 3)
            elif key == glfw.KEY_N:
                self._snap_enabled = not self._snap_enabled
                self._set_message(f"Snap {'ON' if self._snap_enabled else 'OFF'} ({self._snap_size})")
            elif key == glfw.KEY_LEFT_BRACKET:
                sizes = [0.1, 0.25, 0.5, 1.0, 2.0, 5.0]
                idx = sizes.index(self._snap_size) if self._snap_size in sizes else 2
                self._snap_size = sizes[max(0, idx - 1)]
                self._set_message(f"Snap size: {self._snap_size}")
            elif key == glfw.KEY_RIGHT_BRACKET:
                sizes = [0.1, 0.25, 0.5, 1.0, 2.0, 5.0]
                idx = sizes.index(self._snap_size) if self._snap_size in sizes else 2
                self._snap_size = sizes[min(len(sizes) - 1, idx + 1)]
                self._set_message(f"Snap size: {self._snap_size}")
            elif key == glfw.KEY_F2:
                if self._asset_mode == "materials" and self._asset_selected:
                    old = self._asset_selected
                    def _cb(new_name):
                        if new_name and new_name != old:
                            self._asset_selected = old
                            self._asset_mat_rename(new_name)
                    self._open_dialog("Rename Material", old, _cb)
                elif self._asset_selected_set and self._asset_mode != "materials":
                    items = sorted(self._asset_selected_set)
                    old = items[0]
                    name_part, ext = os.path.splitext(old)
                    def _cb_file(new_name):
                        if new_name and new_name != name_part:
                            self._asset_selected = old
                            self._asset_rename_finish(new_name + ext)
                    self._open_dialog("Rename", name_part, _cb_file)
                elif self.selected_node and self.selected_node is not self.global_manager:
                    old = self.selected_node.name
                    def _cb_node(new_name):
                        if new_name and new_name != old:
                            self.selected_node.name = new_name
                    self._open_dialog("Rename", old, _cb_node)
            elif key == glfw.KEY_TAB:
                if self.nodes:
                    shift = mods & glfw.MOD_SHIFT
                    if self.selected_node and self.selected_node in self.nodes:
                        idx = self.nodes.index(self.selected_node)
                        idx = (idx - 1 if shift else idx + 1) % len(self.nodes)
                    else:
                        idx = len(self.nodes) - 1 if shift else 0
                    self._select_node(self.nodes[idx])
            elif key == glfw.KEY_ESCAPE:
                if self._color_picker_active:
                    self._color_picker_color = list(self._color_picker_original)
                    self._sync_global_manager()
                    self._color_picker_active = False
                elif self.selected_node:
                    self._select_node(None)
                elif self.show_file_menu:
                    self.show_file_menu = False
            elif ctrl and key == glfw.KEY_A:
                self.selected_nodes.clear()
                for n in self.nodes:
                    self.selected_nodes.add(n)
                if self.nodes:
                    self.selected_node = self.nodes[-1]
                self._set_message(f"Selected {len(self.selected_nodes)} objects")
