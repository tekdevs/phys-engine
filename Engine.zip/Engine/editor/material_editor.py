from __future__ import annotations
import os
from OpenGL.GL import *
from engine import Material
from editor.constants import (
    PANEL_BG, PANEL_DARK, PANEL_BORDER, ACCENT, TEXT_COLOR, TEXT_DIM,
    FIELD_BG, FIELD_BORDER, FONT_SZ_SM, FONT_SZ_MD,
    get_text_tex,
)


class MaterialEditorMixin:
    def _init_materials(self):
        self.materials = {}
        self._selected_material_name = None
        self._add_material("Default")
        self._resolve_materials()

    def _add_material(self, name):
        if name not in self.materials:
            self.materials[name] = Material(name)
            return True
        return False

    def _delete_material(self, name):
        if name == "Default":
            return False
        if name in self.materials:
            self.materials[name].cleanup_tex()
            del self.materials[name]
            for node in self.nodes:
                if hasattr(node, 'material_name') and node.material_name == name:
                    node.material_name = "None"
            self._resolve_materials()
            return True
        return False

    def _duplicate_material(self, name):
        if name not in self.materials:
            return False
        new_name = f"{name} (Copy)"
        n = 2
        while new_name in self.materials:
            new_name = f"{name} ({n})"
        mat = Material.from_dict(self.materials[name].to_dict())
        mat.name = new_name
        mat.tex_id = 0
        self.materials[new_name] = mat
        self._resolve_materials()
        return True

    def _resolve_materials(self):
        for node in self.nodes:
            if hasattr(node, 'material_name') and hasattr(node, 'tex_id'):
                mat = self.materials.get(node.material_name)
                if mat:
                    node.material_obj = mat
                    node.tex_id = mat.tex_id
                else:
                    node.material_obj = None
                    node.tex_id = 0

    def _load_material_textures(self):
        root = self._asset_root_dir()
        if not root:
            return
        for mat in self.materials.values():
            mat.load_texture(root)
        self._resolve_materials()

    def _finish_material_editing(self):
        if self._material_edit_field is not None:
            field = self._material_edit_field
            mat = self.materials.get(self._selected_material_name)
            if mat:
                buf = self._material_edit_buffer.strip()
                if field == "name":
                    new_name = buf
                    if new_name and new_name != mat.name and new_name not in self.materials:
                        old_name = mat.name
                        self.materials[new_name] = self.materials.pop(old_name)
                        self.materials[new_name].name = new_name
                        for node in self.nodes:
                            if hasattr(node, 'material_name') and node.material_name == old_name:
                                node.material_name = new_name
                        self._selected_material_name = new_name
                        self._resolve_materials()
                else:
                    try:
                        val = float(buf)
                        if field in ("mat_tiling_u", "mat_tiling_v", "mat_offset_u", "mat_offset_v"):
                            setattr(mat, field.replace("mat_", ""), val)
                            self._resolve_materials()
                    except ValueError:
                        pass
        self._material_edit_field = None
        self._material_edit_buffer = ""
        self._material_edit_cursor = 0
        self._material_edit_cursor_timer = 0.0

    def _render_material_editor(self, x, y, pw):
        mat = self.materials.get(self._selected_material_name)
        if not mat:
            self._selected_material_name = None
            return
        line_h = 24
        gap = 4
        pad = 6
        label_w = 55
        field_x = x + label_w
        field_w = pw - label_w - pad
        sw = 28

        self._draw_text(x + 6, y + 12, "Material Editor", ACCENT, FONT_SZ_SM)
        self._draw_text(x + 6, y + 26, mat.name, (0.6, 0.6, 0.8), FONT_SZ_SM)
        cy = y + 42

        bg = (0.08, 0.08, 0.11)
        self._draw_rect(x, cy, pw, line_h, bg)
        self._draw_text(x + 6, cy + 5, "Name", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, FIELD_BG, FIELD_BORDER)
        if self._material_edit_field == "name":
            self._draw_text(field_x + 4, cy + 5, self._material_edit_buffer, ACCENT, FONT_SZ_SM)
            msr = self._material_edit_sel
            if msr is not None:
                s, e = min(msr[0], msr[1]), max(msr[0], msr[1])
                if s != e:
                    glDisable(GL_TEXTURE_2D)
                    sx = field_x + 4 + get_text_tex(self._material_edit_buffer[:s], FONT_SZ_SM, (255,255,255,255))[1]
                    ex = field_x + 4 + get_text_tex(self._material_edit_buffer[:e], FONT_SZ_SM, (255,255,255,255))[1]
                    glEnable(GL_BLEND)
                    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
                    glColor4f(0.3, 0.5, 0.8, 0.4)
                    glBegin(GL_QUADS)
                    glVertex2f(sx, cy + 4); glVertex2f(ex, cy + 4)
                    glVertex2f(ex, cy + 19); glVertex2f(sx, cy + 19)
                    glEnd()
                    glDisable(GL_BLEND)
            if int(self._material_edit_cursor_timer * 2) % 2 == 0 and (msr is None or msr[0] == msr[1]):
                px = field_x + 4 + get_text_tex(self._material_edit_buffer[:self._material_edit_cursor], FONT_SZ_SM, (255,255,255,255))[1]
                glDisable(GL_TEXTURE_2D)
                glColor3f(0.9, 0.9, 0.9)
                glBegin(GL_LINES)
                glVertex2f(px, cy + 5); glVertex2f(px, cy + 5 + 14)
                glEnd()
        else:
            self._draw_text(field_x + 4, cy + 5, mat.name, TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap

        self._draw_rect(x, cy, pw, line_h, bg)
        self._draw_text(x + 6, cy + 5, "Albedo", TEXT_COLOR, FONT_SZ_SM)
        r, g, b = mat.albedo_color
        al_sw = sw + 8
        sx_al = x + pw - al_sw - pad
        self._draw_rect(sx_al, cy + 2, al_sw, line_h - 4, (r, g, b), (0.5, 0.5, 0.5))
        cy += line_h + gap

        self._draw_rect(x, cy, pw, line_h, bg)
        self._draw_text(x + 6, cy + 5, "Tex", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
        tlabel = os.path.basename(mat.albedo_texture) if mat.albedo_texture else "None"
        self._draw_text(field_x + 4, cy + 5, tlabel, TEXT_DIM if not mat.albedo_texture else TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap

        for label, attr_u, attr_v in [("Tiling", "tiling_u", "tiling_v"), ("Offset", "offset_u", "offset_v")]:
            self._draw_rect(x, cy, pw, line_h, bg)
            self._draw_text(x + 6, cy + 5, label, TEXT_COLOR, FONT_SZ_SM)
            gap2 = 4
            fw2 = (field_w - gap2) / 2
            for i, aname in enumerate([attr_u, attr_v]):
                fx2 = field_x + i * (fw2 + gap2)
                self._draw_rect(fx2, cy + 2, fw2, line_h - 4, FIELD_BG, FIELD_BORDER)
                val = getattr(mat, aname)
                ek = f"mat_{aname}"
                if self._material_edit_field == ek:
                    self._draw_text(fx2 + 4, cy + 5, self._material_edit_buffer, ACCENT, FONT_SZ_SM)
                    msr = self._material_edit_sel
                    if msr is not None:
                        s2, e2 = min(msr[0], msr[1]), max(msr[0], msr[1])
                        if s2 != e2:
                            glDisable(GL_TEXTURE_2D)
                            ssx = fx2 + 4 + get_text_tex(self._material_edit_buffer[:s2], FONT_SZ_SM, (255,255,255,255))[1]
                            eex = fx2 + 4 + get_text_tex(self._material_edit_buffer[:e2], FONT_SZ_SM, (255,255,255,255))[1]
                            glEnable(GL_BLEND)
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
                            glColor4f(0.3, 0.5, 0.8, 0.4)
                            glBegin(GL_QUADS)
                            glVertex2f(ssx, cy + 4); glVertex2f(eex, cy + 4)
                            glVertex2f(eex, cy + 19); glVertex2f(ssx, cy + 19)
                            glEnd()
                            glDisable(GL_BLEND)
                    if int(self._material_edit_cursor_timer * 2) % 2 == 0 and (msr is None or msr[0] == msr[1]):
                        px2 = fx2 + 4 + get_text_tex(self._material_edit_buffer[:self._material_edit_cursor], FONT_SZ_SM, (255,255,255,255))[1]
                        glDisable(GL_TEXTURE_2D)
                        glColor3f(0.9, 0.9, 0.9)
                        glBegin(GL_LINES)
                        glVertex2f(px2, cy + 5); glVertex2f(px2, cy + 5 + 14)
                        glEnd()
                else:
                    fv = f"{val:.2f}".rstrip('0').rstrip('.')
                    if '.' not in fv: fv = f"{fv}.0"
                    self._draw_text(fx2 + 4, cy + 5, fv, TEXT_COLOR, FONT_SZ_SM)
            cy += line_h + gap

        self._draw_rect(x, cy, pw, line_h, bg)
        self._draw_text(x + 6, cy + 5, "Shine", TEXT_COLOR, FONT_SZ_SM)
        sh = mat.shininess
        sl_w = field_w - 28
        sl_x = field_x
        sl_y = cy + 3
        self._draw_rect(sl_x, sl_y, sl_w, line_h - 6, (0.15, 0.15, 0.18), (0.25, 0.25, 0.3))
        fill_w = (sh / 128.0) * sl_w
        self._draw_rect(sl_x, sl_y, int(fill_w), line_h - 6, (0.3, 0.5, 0.8))
        self._draw_text(sl_x + sl_w + 2, cy + 5, f"{int(sh)}", TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap

        self._draw_rect(x, cy, pw, line_h, bg)
        self._draw_text(x + 6, cy + 5, "Spec", TEXT_COLOR, FONT_SZ_SM)
        sr, sg, sb = mat.specular
        sp_x = x + pw - al_sw - pad
        self._draw_rect(sp_x, cy + 2, al_sw, line_h - 4, (sr, sg, sb), (0.5, 0.5, 0.5))
        cy += line_h + gap + 4

        btn_w = (pw - pad - 4) // 2
        btn_h = 22
        by = cy
        del_hover = (x + 2 <= self.mouse_x <= x + 2 + btn_w and by <= self.mouse_y <= by + btn_h)
        dup_hover = (x + 2 + btn_w + 4 <= self.mouse_x <= x + 2 + btn_w * 2 + 4 and by <= self.mouse_y <= by + btn_h)
        self._draw_rect(x + 2, by, btn_w, btn_h, (0.35, 0.14, 0.16) if del_hover else (0.22, 0.12, 0.14), (0.5, 0.2, 0.22) if del_hover else (0.35, 0.16, 0.18))
        self._draw_text(x + 12, by + 3, "Delete", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(x + 2 + btn_w + 4, by, btn_w, btn_h, (0.14, 0.22, 0.35) if dup_hover else (0.12, 0.16, 0.24), (0.2, 0.35, 0.5) if dup_hover else (0.16, 0.22, 0.32))
        self._draw_text(x + 12 + btn_w + 4, by + 3, "Duplicate", TEXT_COLOR, FONT_SZ_SM)

        if self._tex_dropdown_open:
            tex_cy = y + 42 + 2 * (line_h + gap)
            images = self._collect_images()
            inspector_bottom = self.height - 24 - self.asset_height
            dd_h = (len(images) + 1) * 20
            if tex_cy + line_h + 2 + dd_h > inspector_bottom:
                dd_tex_y = tex_cy - dd_h
            else:
                dd_tex_y = tex_cy + line_h + 2
            self._draw_rect(field_x, dd_tex_y, field_w, dd_h, (0.10, 0.10, 0.14), PANEL_BORDER)
            is_hov = (field_x <= self.mouse_x <= field_x + field_w and
                      dd_tex_y <= self.mouse_y <= dd_tex_y + 20)
            bg2 = (0.16, 0.22, 0.36) if is_hov else (0.10, 0.10, 0.14)
            self._draw_rect(field_x, dd_tex_y, field_w, 20, bg2)
            self._draw_text(field_x + 4, dd_tex_y + 3, "None", ACCENT if is_hov else TEXT_DIM, FONT_SZ_SM)
            for ii, ipath in enumerate(images):
                iy = dd_tex_y + (ii + 1) * 20
                if iy + 20 > dd_tex_y + dd_h: break
                is_hov2 = (field_x <= self.mouse_x <= field_x + field_w and
                           iy <= self.mouse_y <= iy + 20)
                bg3 = (0.16, 0.22, 0.36) if is_hov2 else (0.10, 0.10, 0.14)
                self._draw_rect(field_x, iy, field_w, 20, bg3)
                self._draw_text(field_x + 4, iy + 3, ipath, ACCENT if is_hov2 else TEXT_DIM, FONT_SZ_SM)

    def _do_material_texture_browse(self, mat):
        root = self._asset_root_dir()
        if not root:
            self._set_message("No project loaded")
            return
        try:
            import tkinter as tk
            from tkinter import filedialog
            root_tk = tk.Tk()
            root_tk.withdraw()
            path = filedialog.askopenfilename(
                title="Select Texture",
                initialdir=root if os.path.isdir(root) else None,
                filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.tga"), ("All Files", "*.*")]
            )
            root_tk.destroy()
            if path:
                rel = os.path.relpath(path, root)
                mat.albedo_texture = rel.replace("\\", "/")
                mat.load_texture(root)
                self._resolve_materials()
        except Exception as e:
            self._set_message(f"Browse failed: {e}")
