from __future__ import annotations
from OpenGL.GL import *
from OpenGL.GLU import *
from engine import Vector3
from editor.constants import (
    PANEL_BG, PANEL_DARK, PANEL_BORDER, ACCENT, ACCENT_HOVER, TEXT_COLOR, TEXT_DIM, TEXT_BRIGHT,
    GIZMO_X, GIZMO_Y, GIZMO_Z, SELECTION_COLOR, FIELD_BG, FIELD_BORDER,
    FONT_SZ_SM, FONT_SZ_LG, get_text_tex, texture_cache, load_icon,
)


class PanelsMixin:
    def render_scene(self):
        viewport_w = self.width
        viewport_h = self.height
        glViewport(0, 0, viewport_w, viewport_h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        aspect = viewport_w / viewport_h if viewport_h > 0 else 1
        gluPerspective(90, aspect, 0.1, 500.0)
        glMatrixMode(GL_MODELVIEW)
        glClearColor(*self.skybox.horizon_color, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        self.camera.look_at()
        if self.skybox:
            self.skybox.draw(self.camera.pos)
        self.lighting.enable()
        self._render_grid()
        for node in self.nodes:
            node.render_scene()
        for node in self.nodes:
            if node.selected:
                node.render_selected()
        if self.selected_node:
            gs = (self.selected_node.get_world_pos() - self.camera.pos).length() * 0.06
            if self.gizmo.mode == "rotate":
                gizmo_rot = self.selected_node.rot if self.gizmo_space == "local" else None
            else:
                gizmo_rot = self.selected_node.rot if self.gizmo_space == "local" else None
            self.gizmo.draw(self.selected_node.get_world_pos(), max(0.5, min(3.0, gs)) * 1.3, rot=gizmo_rot)
        self.lighting.disable()

    def render_toolbar(self):
        h = 40
        self._draw_rect(0, 0, self.width, h, PANEL_DARK, PANEL_BORDER)
        btn_h = 26
        btn_y = 7

        file_w = 50
        file_hover = (8 <= self.mouse_x <= 8 + file_w and btn_y <= self.mouse_y <= btn_y + btn_h)
        file_bg = (0.16, 0.16, 0.22) if self.show_file_menu else ((0.14, 0.16, 0.22) if file_hover else PANEL_BG)
        self._draw_rect(8, btn_y, file_w, btn_h, file_bg, PANEL_BORDER)
        self._draw_text(16, btn_y + 5, "File", ACCENT if file_hover else TEXT_COLOR, FONT_SZ_SM)

        left_x = 68
        if self.project_name:
            self._draw_text(left_x, btn_y + 5, f"{self.project_name}", ACCENT, FONT_SZ_SM)

        pw = 40
        cx = self.width // 2
        px = cx - pw // 2
        play_hover = (px <= self.mouse_x <= px + pw and btn_y <= self.mouse_y <= btn_y + btn_h)
        self._draw_rect(px, btn_y, pw, btn_h, (0.10, 0.14, 0.10) if play_hover else (0.12, 0.12, 0.14), PANEL_BORDER)
        glDisable(GL_TEXTURE_2D)
        glColor3f(0.3, 0.90, 0.3) if not play_hover else glColor3f(0.4, 1.0, 0.4)
        glBegin(GL_TRIANGLES)
        glVertex2f(cx - 5, btn_y + 5); glVertex2f(cx - 5, btn_y + btn_h - 5); glVertex2f(cx + 7, btn_y + btn_h // 2)
        glEnd()

        if self.message and self.message_timer > 0:
            tw = get_text_tex(self.message, FONT_SZ_SM, (255,255,255,255))[1]
            mx = (self.width - tw) // 2
            self._draw_text(mx, 48, self.message, TEXT_COLOR, FONT_SZ_SM)

    def render_gizmo_icons(self):
        bx = self.hierarchy_width + 12
        by = 52
        bw = 28
        bh = 28
        gap = 2
        modes = [
            ("translate", "position"),
            ("rotate", "rotate"),
            ("scale", "scale"),
        ]
        for i, (mode, icon_name) in enumerate(modes):
            iy = by + i * (bh + gap)
            is_active = self.gizmo.mode == mode
            hover = bx <= self.mouse_x <= bx + bw and iy <= self.mouse_y <= iy + bh
            if is_active:
                bg = (0.16, 0.22, 0.36)
            elif hover:
                bg = (0.14, 0.14, 0.18)
            else:
                bg = (0.08, 0.08, 0.10)
            self._draw_rect(bx, iy, bw, bh, bg, PANEL_BORDER)
            icon = load_icon(icon_name, bw - 8)
            glEnable(GL_TEXTURE_2D)
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            if icon:
                tex, iw, ih = icon
                glBindTexture(GL_TEXTURE_2D, tex)
                if is_active:
                    glColor3f(0.5, 0.7, 1.0)
                elif hover:
                    glColor3f(0.7, 0.8, 1.0)
                else:
                    glColor3f(0.6, 0.6, 0.65)
                ix = bx + (bw - iw) // 2
                iy2 = iy + (bh - ih) // 2
                glBegin(GL_QUADS)
                glTexCoord2f(0, 0); glVertex2f(ix, iy2)
                glTexCoord2f(1, 0); glVertex2f(ix + iw, iy2)
                glTexCoord2f(1, 1); glVertex2f(ix + iw, iy2 + ih)
                glTexCoord2f(0, 1); glVertex2f(ix, iy2 + ih)
                glEnd()
            else:
                if is_active:
                    col = ACCENT
                elif hover:
                    col = ACCENT_HOVER
                else:
                    col = TEXT_DIM
                self._draw_text(bx + 6, iy + 7, mode[0].upper(), col, FONT_SZ_LG)
            glDisable(GL_TEXTURE_2D)
            glDisable(GL_BLEND)

    def render_gizmo_space_dropdown(self):
        bw = 80
        bh = 24
        bx = self.width - self.inspector_width - bw - 12
        by = 52
        label = "Local" if self.gizmo_space == "local" else "Global"
        hover = bx <= self.mouse_x <= bx + bw and by <= self.mouse_y <= by + bh
        bg = (0.14, 0.14, 0.18) if hover else (0.10, 0.10, 0.13)
        self._draw_rect(bx, by, bw, bh, bg, PANEL_BORDER)
        self._draw_text(bx + 8, by + 5, label, TEXT_COLOR, FONT_SZ_SM)
        arrow_x = bx + bw - 14
        self._draw_text(arrow_x, by + 5, "\u25BE", TEXT_DIM, FONT_SZ_SM)
        if self._gizmo_space_dropdown_open:
            dd_h = 2 * bh
            dd_y = by + bh + 2
            self._draw_rect(bx, dd_y, bw, dd_h, (0.10, 0.10, 0.13), PANEL_BORDER)
            for i, opt in enumerate(["Global", "Local"]):
                oy = dd_y + i * bh
                oh = bx <= self.mouse_x <= bx + bw and oy <= self.mouse_y <= oy + bh
                obg = (0.16, 0.22, 0.36) if oh else (0.10, 0.10, 0.13)
                self._draw_rect(bx, oy, bw, bh, obg, PANEL_BORDER)
                ocol = ACCENT if oh else TEXT_COLOR
                self._draw_text(bx + 8, oy + 5, opt, ocol, FONT_SZ_SM)

    def render_file_menu(self):
        if not self.show_file_menu:
            return
        btn_y = 7
        btn_h = 26
        menu_x = 8
        menu_y = btn_y + btn_h + 2
        menu_w = 140
        menu_h = 80
        self._draw_rect(menu_x, menu_y, menu_w, menu_h, PANEL_DARK, PANEL_BORDER)
        items = [("New", "new"), ("Save", "save"), ("Load", "load")]
        for i, (label, action) in enumerate(items):
            iy = menu_y + 4 + i * 24
            hover = menu_x + 4 <= self.mouse_x <= menu_x + menu_w - 4 and iy <= self.mouse_y <= iy + 22
            bg = (0.25, 0.25, 0.30) if hover else (0.14, 0.14, 0.17)
            self._draw_rect(menu_x + 4, iy, menu_w - 8, 22, bg)
            self._draw_text(menu_x + 14, iy + 3, label, TEXT_BRIGHT if hover else TEXT_COLOR, FONT_SZ_SM)

    def render_hierarchy(self):
        x, y = 0, 40
        pw = self.hierarchy_width
        ph = self.height - 40 - 24 - self.asset_height
        self._draw_rect(x, y, pw, ph, PANEL_BG, PANEL_BORDER)

        content_top = y + 10
        content_h = ph - 10
        item_h = 22

        glEnable(GL_SCISSOR_TEST)
        glScissor(x, self.height - (content_top + content_h), pw - 2, content_h)

        gm = self.global_manager
        gm_bg = (0.15, 0.20, 0.15) if gm.selected else (0.10, 0.14, 0.10)
        self._draw_rect(x + 2, content_top, pw - 4, item_h, gm_bg)
        gm_label = f"{gm.name} (GlobalManager)"
        gm_max_w = pw - 26
        gm_label = self._asset_truncate(gm_label, gm_max_w)
        self._draw_text(x + 10, content_top + 3, gm_label,
                       SELECTION_COLOR if gm.selected else (0.4, 0.8, 0.4), FONT_SZ_SM)

        cy = content_top + item_h
        total = len(self.nodes)
        visible_count = int((content_h - item_h) / item_h)
        max_scroll = max(0, (total - visible_count) * item_h)
        self._hierarchy_scroll = max(0, min(self._hierarchy_scroll, max_scroll))
        scroll_idx = int(self._hierarchy_scroll / item_h)

        for idx in range(scroll_idx, total):
            node = self.nodes[idx]
            if not node.visible: continue
            if cy + item_h > content_top + content_h + item_h:
                break
            bg = (0.14, 0.18, 0.28) if node.selected else ((0.10, 0.12, 0.18) if (x + 2 <= self.mouse_x <= x + pw - 2 and cy <= self.mouse_y <= cy + item_h) else PANEL_BG)
            self._draw_rect(x + 2, cy, pw - 4, item_h, bg)
            display_name = node.get_type_name()
            full_label = f"{node.name} ({display_name})"
            max_w = pw - 26
            label = self._asset_truncate(full_label, max_w)
            self._draw_text(x + 10, cy + 3, label,
                          SELECTION_COLOR if node.selected else TEXT_COLOR, FONT_SZ_SM)
            cy += item_h

        glDisable(GL_SCISSOR_TEST)

        if total > visible_count:
            bar_h = max(30, int((content_h - item_h) * visible_count / total))
            bar_y = content_top + item_h + int((self._hierarchy_scroll / max(max_scroll, 1)) * (content_h - item_h - bar_h))
            self._draw_rect(x + pw - 16, content_top + item_h, 14, content_h - item_h, (0.06, 0.06, 0.06))
            sb_hover = (not self._hierarchy_scroll_drag and self._sb_hovered) or self._hierarchy_scroll_drag
            bar_col = (0.45, 0.45, 0.55) if sb_hover else (0.3, 0.3, 0.35)
            self._draw_rect(x + pw - 15, bar_y, 12, bar_h, bar_col, PANEL_BORDER)
            self._sb_x = x + pw - 15
            self._sb_y = bar_y
            self._sb_h = bar_h
            self._sb_w = 12

        if self._hierarchy_context_menu:
            mx2, my2, items = self._hierarchy_context_menu
            mw = 120
            mh2 = len(items) * 24 + 8
            if mx2 + mw > self.width:
                mx2 = self.width - mw - 4
            if my2 + mh2 > y + ph:
                my2 = y + ph - mh2 - 4
            self._draw_rect(mx2, my2, mw, mh2, PANEL_BG, PANEL_BORDER)
            for ii, (label, cb) in enumerate(items):
                iy = my2 + 4 + ii * 24
                cm_hover = (mx2 + 4 <= self.mouse_x <= mx2 + mw - 4 and iy <= self.mouse_y <= iy + 20)
                self._draw_rect(mx2 + 4, iy, mw - 8, 20, (0.14, 0.18, 0.28) if cm_hover else (0.10, 0.10, 0.14), PANEL_BORDER)
                self._draw_text(mx2 + 12, iy + 3, label, ACCENT if cm_hover else TEXT_COLOR, FONT_SZ_SM)

    def render_inspector(self):
        x = self.width - self.inspector_width
        y = 40
        pw = self.inspector_width
        ph = self.height - 40 - 24 - self.asset_height
        self._draw_rect(x, y, pw, ph, PANEL_BG, PANEL_BORDER)
        if self._selected_material_name:
            self._render_material_editor(x, y, pw)
            return
        if not self.selected_node:
            self._draw_text(x + 10, y + 15, "No object selected", TEXT_COLOR, FONT_SZ_SM)
            return
        node = self.selected_node
        if node is self.global_manager:
            self._render_global_manager_inspector(x, y, pw)
            return
        display_type = node.get_type_name()
        self._draw_text(x + 10, y + 12, f"{display_type}", TEXT_DIM, FONT_SZ_SM)
        cy = y + 32
        line_h = 24
        pad = 10
        label_w = 60
        field_x = x + label_w
        field_w = pw - label_w - pad
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Name", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
        if self._editing_field and self._editing_field[0] == "name":
            self._draw_text(field_x + 6, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
            self._draw_cursor(field_x + 6, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
        else:
            self._draw_text(field_x + 6, cy + 5, node.name, TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + 1
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Position", TEXT_COLOR, FONT_SZ_SM)
        self._draw_vec3_fields("pos", node.pos, x, cy, pw, line_h, [GIZMO_X, GIZMO_Y, GIZMO_Z])
        cy += line_h + 1
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Rotation", TEXT_COLOR, FONT_SZ_SM)
        self._draw_vec3_fields("rot", node.rot, x, cy, pw, line_h, [GIZMO_X, GIZMO_Y, GIZMO_Z])
        cy += line_h + 1
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Scale", TEXT_COLOR, FONT_SZ_SM)
        self._draw_vec3_fields("scale", node.scale, x, cy, pw, line_h, [TEXT_COLOR, TEXT_COLOR, TEXT_COLOR])
        cy += line_h + 1
        props = node.get_properties()
        for key, val in props.items():
            if key == "pos" and isinstance(val, Vector3):
                continue
            elif isinstance(val, (int, float)):
                self._draw_rect(x, cy, pw, line_h, PANEL_BG)
                self._draw_text(x + 10, cy + 5, key.capitalize(), TEXT_COLOR, FONT_SZ_SM)
                self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
                if self._editing_field and self._editing_field[0] == key:
                    self._draw_text(field_x + 6, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
                    self._draw_cursor(field_x + 6, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
                else:
                    fval = f"{val:.2f}".rstrip('0').rstrip('.')
                    if '.' not in fval: fval = f"{fval}.0"
                    self._draw_text(field_x + 6, cy + 5, fval, TEXT_COLOR, FONT_SZ_SM)
                cy += line_h + 1
            else:
                cy += line_h + 1
        if hasattr(node, 'material_name'):
            self._draw_rect(x, cy, pw, line_h, PANEL_BG)
            self._draw_text(x + 10, cy + 5, "Material", TEXT_COLOR, FONT_SZ_SM)
            mat_field_w = field_w
            self._draw_rect(field_x, cy + 2, mat_field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
            if len(self.selected_nodes) > 1:
                mats = set()
                for sel in self.selected_nodes:
                    if hasattr(sel, 'material_name'):
                        mats.add(sel.material_name)
                mat_label = node.material_name if len(mats) == 1 else "--- Mixed ---"
            else:
                mat_label = node.material_name
            self._draw_text(field_x + 6, cy + 5, mat_label, TEXT_COLOR, FONT_SZ_SM)
            if self._material_dropdown_open:
                dd_h = (len(self.materials) + 1) * 20
                inspector_bottom = self.height - 24 - self.asset_height
                if cy + line_h + 2 + dd_h > inspector_bottom:
                    dd_y = cy - dd_h
                else:
                    dd_y = cy + line_h + 2
                self._draw_rect(field_x, dd_y, mat_field_w, dd_h, (0.14, 0.14, 0.16), (0.3, 0.3, 0.35))
                is_hov = (field_x <= self.mouse_x <= field_x + mat_field_w and
                          dd_y <= self.mouse_y <= dd_y + 20)
                bg = (0.16, 0.22, 0.36) if is_hov else (0.10, 0.10, 0.14)
                self._draw_rect(field_x, dd_y, mat_field_w, 20, bg)
                self._draw_text(field_x + 6, dd_y + 3, "None", ACCENT if is_hov else TEXT_DIM, FONT_SZ_SM)
                for mi, mname in enumerate(self.materials):
                    miy = dd_y + (mi + 1) * 20
                    if miy + 20 > dd_y + dd_h: break
                    is_hov = (field_x <= self.mouse_x <= field_x + mat_field_w and
                              miy <= self.mouse_y <= miy + 20)
                    bg = (0.16, 0.22, 0.36) if is_hov else (0.10, 0.10, 0.14)
                    self._draw_rect(field_x, miy, mat_field_w, 20, bg)
                    self._draw_text(field_x + 6, miy + 3, mname, ACCENT if is_hov else TEXT_DIM, FONT_SZ_SM)
            cy += line_h + 1

    def _draw_vec3_fields(self, prefix, vec, x, cy, pw, line_h, colors):
        label_w = 60
        pad = 10
        gap = 4
        avail = pw - label_w - pad - gap * 4
        fw = avail / 3
        for i, (label, axis) in enumerate([("X", 0), ("Y", 1), ("Z", 2)]):
            fx = x + label_w + gap + i * (fw + gap)
            self._draw_rect(fx, cy + 2, fw, line_h - 4, FIELD_BG, FIELD_BORDER)
            self._draw_text(fx + 4, cy + 5, label, colors[i], FONT_SZ_SM)
            v = [vec.x, vec.y, vec.z][i]
            if self._editing_field and self._editing_field[0] == prefix and self._editing_field[1] == i:
                self._draw_text(fx + 18, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
                self._draw_cursor(fx + 18, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
            else:
                fv = f"{v:.2f}".rstrip('0').rstrip('.')
                if '.' not in fv: fv = f"{fv}.0"
                self._draw_text(fx + 18, cy + 5, fv, TEXT_COLOR, FONT_SZ_SM)

    def _render_global_manager_inspector(self, x, y, pw):
        gm = self.global_manager
        self._draw_text(x + 10, y + 12, "GlobalManager", (0.4, 0.8, 0.4), FONT_SZ_SM)
        cy = y + 32
        line_h = 24
        gap = 6
        pad = 10
        label_w = 80
        field_x = x + label_w
        field_w = pw - label_w - pad
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Skybox", TEXT_COLOR, FONT_SZ_SM)
        sw = 30
        sx = x + pw - sw - 10
        r, g, b = gm.skybox_color
        self._draw_rect(sx, cy + 2, sw, line_h - 4, (r, g, b), (0.5, 0.5, 0.5))
        cy += line_h + gap
        self._draw_rect(x, cy, pw, line_h, (0.06, 0.08, 0.06))
        self._draw_text(x + 10, cy + 5, "--- Lighting ---", (0.4, 0.9, 0.4), FONT_SZ_SM)
        cy += line_h + gap
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Sun Color", TEXT_COLOR, FONT_SZ_SM)
        sx2 = x + pw - sw - 10
        lr, lg, lb = gm.light_color
        self._draw_rect(sx2, cy + 2, sw, line_h - 4, (lr, lg, lb), (0.5, 0.5, 0.5))
        cy += line_h + gap
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Intensity", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
        if self._editing_field and self._editing_field[0] == "light_intensity":
            self._draw_text(field_x + 6, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
            self._draw_cursor(field_x + 6, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
        else:
            fval = f"{gm.light_intensity:.2f}".rstrip('0').rstrip('.')
            if '.' not in fval: fval = f"{fval}.0"
            self._draw_text(field_x + 6, cy + 5, fval, TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Ambient", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
        if self._editing_field and self._editing_field[0] == "ambient_intensity":
            self._draw_text(field_x + 6, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
            self._draw_cursor(field_x + 6, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
        else:
            fval = f"{gm.ambient_intensity:.2f}".rstrip('0').rstrip('.')
            if '.' not in fval: fval = f"{fval}.0"
            self._draw_text(field_x + 6, cy + 5, fval, TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Shadow", TEXT_COLOR, FONT_SZ_SM)
        self._draw_rect(field_x, cy + 2, field_w, line_h - 4, (0.09, 0.09, 0.12), (0.18, 0.18, 0.24))
        if self._editing_field and self._editing_field[0] == "shadow_strength":
            self._draw_text(field_x + 6, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
            self._draw_cursor(field_x + 6, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
        else:
            fval = f"{gm.shadow_strength:.2f}".rstrip('0').rstrip('.')
            if '.' not in fval: fval = f"{fval}.0"
            self._draw_text(field_x + 6, cy + 5, fval, TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + gap + 4
        self._draw_rect(x, cy, pw, line_h, PANEL_BG)
        self._draw_text(x + 10, cy + 5, "Direction", TEXT_COLOR, FONT_SZ_SM)
        cy += line_h + 4
        d = gm.light_direction
        dir_vals = [d.x, d.y, d.z]
        dir_labels = [("X", GIZMO_X), ("Y", GIZMO_Y), ("Z", GIZMO_Z)]
        field_gap = 4
        avail = pw - pad * 2 - field_gap * 2
        fw = avail / 3
        for i, (label, lcolor) in enumerate(dir_labels):
            fx = x + pad + i * (fw + field_gap)
            self._draw_rect(fx, cy + 2, fw, line_h - 4, FIELD_BG, FIELD_BORDER)
            self._draw_text(fx + 4, cy + 5, label, lcolor, FONT_SZ_SM)
            edit_key = f"light_dir_{i}"
            if self._editing_field and self._editing_field[0] == edit_key:
                self._draw_text(fx + 18, cy + 5, self._edit_buffer, ACCENT, FONT_SZ_SM)
                self._draw_cursor(fx + 18, cy + 5, self._edit_buffer, self._edit_cursor, sel=self._edit_sel)
            else:
                fv = f"{dir_vals[i]:.2f}".rstrip('0').rstrip('.')
                if '.' not in fv: fv = f"{fv}.0"
                self._draw_text(fx + 18, cy + 5, fv, TEXT_COLOR, FONT_SZ_SM)

    def _render_grid(self):
        glDisable(GL_LIGHTING)
        glDisable(GL_TEXTURE_2D)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        s = self._snap_size if self._snap_enabled else 1.0
        n = int(150.0 / s) if s > 0 else 300
        n = min(n, 500)
        glBegin(GL_LINES)
        for i in range(-n, n + 1):
            x = i * s
            major = (i % 5 == 0)
            alpha = 0.25 if major else 0.08
            glColor4f(0.4, 0.6, 1.0, alpha)
            glVertex3f(x, 0.01, -n * s)
            glVertex3f(x, 0.01, n * s)
            glVertex3f(-n * s, 0.01, x)
            glVertex3f(n * s, 0.01, x)
        glEnd()
        glDisable(GL_BLEND)

    def render_status_bar(self):
        y = self.height - 24
        self._draw_rect(0, y, self.width, 24, PANEL_DARK, PANEL_BORDER)
        left = 8
        if self.project_name:
            self._draw_text(left, y + 4, f"Project: {self.project_name}", ACCENT, FONT_SZ_SM)
            left += len(self.project_name) * 8 + 80
        if self.selected_node:
            p = self.selected_node.get_world_pos()
            label = f"Selected: {self.selected_node.name} ({p.x:.1f}, {p.y:.1f}, {p.z:.1f})"
            if len(self.selected_nodes) > 1:
                label += f"  [+{len(self.selected_nodes) - 1} more]"
            self._draw_text(left, y + 4, label, TEXT_COLOR, FONT_SZ_SM)
        else:
            self._draw_text(left, y + 4,
                "No selection  |  [W/S/A/D] Fly  [Shift] Sprint  [R]Rotate  [E]Move  [F]Scale",
                TEXT_DIM, FONT_SZ_SM)
        snap_txt = f"Snap: {'ON' if self._snap_enabled else 'OFF'} ({self._snap_size})"
        snap_color = ACCENT if self._snap_enabled else TEXT_DIM
        self._draw_text(self.width - len(snap_txt) * 8 - 12, y + 4, snap_txt, snap_color, FONT_SZ_SM)
