from __future__ import annotations
import re
import json
import os
import subprocess
import glfw
from engine import Vector3, GlobalManagerNode, Material


class ProjectMixin:
    def _sanitize_name(self, name):
        s = re.sub(r'[^a-zA-Z0-9]', '', name.replace(' ', ''))
        return s[:40] if s else "Untitled"

    def _get_project_scene_path(self):
        if self.project_dir:
            return os.path.join(self.project_dir, "scene.json")
        return ""

    def _get_project_game_path(self):
        if self.project_dir:
            return os.path.join(self.project_dir, f"{self.project_name}_game.py")
        return ""

    def _create_project(self, name):
        sanitized = self._sanitize_name(name)
        proj_dir = os.path.join(self._base_dir, "projects", sanitized)
        os.makedirs(proj_dir, exist_ok=True)
        os.makedirs(os.path.join(proj_dir, "assets"), exist_ok=True)
        self.project_name = sanitized
        self.project_dir = proj_dir
        glfw.set_window_title(self.window, f"Phys Engine - {sanitized}")
        self._set_message(f"Project '{sanitized}' created")

    def _save_dialog(self):
        if not self.project_dir:
            self._new_project_dialog()
            return
        scene_path = self._get_project_scene_path()
        self.save_scene(scene_path)
        self._set_message(f"Saved to {self.project_name}")

    def _load_dialog(self):
        from tkinter import filedialog, Tk
        root = Tk()
        root.withdraw()
        root.configure(bg='#1a1a1a')
        proj_dir = filedialog.askdirectory(title="Select Project Folder")
        root.destroy()
        if proj_dir:
            name = os.path.basename(proj_dir)
            scene_file = os.path.join(proj_dir, "scene.json")
            if os.path.exists(scene_file):
                self.project_name = name
                self.project_dir = proj_dir
                glfw.set_window_title(self.window, f"Phys Engine - {name}")
                self.load_scene(scene_file)
                self._set_message(f"Loaded '{name}'")
            else:
                self._set_message("No scene.json found in folder")

    def _new_project_dialog(self):
        def on_name(name):
            if name:
                self._create_project(name)
                self._new_scene()
        self._open_dialog("New Project", callback=on_name)

    def _play_game(self):
        if not self.project_dir:
            self._set_message("Create or load a project first")
            return
        spawn_count = sum(1 for n in self.nodes if n.get_type_name() == "PlayerSpawn")
        if spawn_count == 0:
            self._set_message("Scene needs a PlayerSpawn node to play")
            return
        if spawn_count > 1:
            self._set_message("Only 1 PlayerSpawn allowed")
            return
        scene_path = self._get_project_scene_path()
        self.save_scene(scene_path, show_message=False)
        game_path = self._get_project_game_path()
        if os.path.exists(game_path):
            exe = game_path
        else:
            exe = os.path.join(self._base_dir, "engine.py")
        subprocess.Popen(["python", exe, scene_path],
                         cwd=self._base_dir,
                         env={**os.environ, "PYTHONPATH": self._base_dir},
                         creationflags=subprocess.CREATE_NO_WINDOW)

    def _new_scene(self):
        self.nodes = []
        self.selected_node = None
        self.selected_nodes.clear()
        self._select_anchor = None
        self._snap_drag_start = {}
        self.global_manager = GlobalManagerNode()
        self._init_materials()
        self._sync_global_manager()
        self._set_message("New scene created")

    def _sync_global_manager(self):
        gm = self.global_manager
        if self._color_picker_active and self._color_picker_target == "skybox":
            color = tuple(self._color_picker_color)
        else:
            color = gm.skybox_color
        if self.skybox:
            self.skybox.top_color = color
            self.skybox.horizon_color = color
            self.skybox.ground_color = color
        if self._color_picker_active and self._color_picker_target == "light":
            self.lighting.sun_color = tuple(self._color_picker_color)
        else:
            self.lighting.sun_color = gm.light_color
        self.lighting.sun_intensity = gm.light_intensity
        self.lighting.sun_direction = gm.light_direction
        self.lighting.shadow_strength = gm.shadow_strength
        self.lighting.ambient_intensity = gm.ambient_intensity

    def _set_message(self, msg):
        self.message = msg
        self.message_timer = 3.0

    def _finish_editing(self):
        if self._editing_field is not None:
            key, axis, node = self._editing_field
            if key == "name":
                if node is not self.global_manager:
                    new_name = self._edit_buffer.strip()
                    if new_name:
                        node.name = new_name
            elif key == "light_intensity":
                try:
                    val = float(self._edit_buffer)
                    val = max(0.0, min(3.0, round(val, 3)))
                    node.light_intensity = val
                    self._sync_global_manager()
                except ValueError:
                    pass
            elif key == "ambient_intensity":
                try:
                    val = float(self._edit_buffer)
                    val = max(0.0, min(1.0, round(val, 3)))
                    node.ambient_intensity = val
                    self._sync_global_manager()
                except ValueError:
                    pass
            elif key == "shadow_strength":
                try:
                    val = float(self._edit_buffer)
                    val = max(0.0, min(1.0, round(val, 3)))
                    node.shadow_strength = val
                    self._sync_global_manager()
                except ValueError:
                    pass
            elif key.startswith("light_dir_"):
                try:
                    idx = int(key.split("_")[-1])
                    val = float(self._edit_buffer)
                    val = round(val, 3)
                    d = node.light_direction
                    dirs = [d.x, d.y, d.z]
                    dirs[idx] = val
                    new_dir = Vector3(dirs[0], dirs[1], dirs[2])
                    if new_dir.length() > 0.001:
                        node.light_direction = new_dir.normalize()
                    self._sync_global_manager()
                except (ValueError, IndexError):
                    pass
            else:
                try:
                    val = float(self._edit_buffer)
                    val = round(val, 3)
                    if key in ("pos", "rot", "scale") and axis is not None:
                        v = [getattr(node, key).x, getattr(node, key).y, getattr(node, key).z]
                        v[axis] = val
                        setattr(node, key, Vector3(v[0], v[1], v[2]))
                    elif isinstance(key, str) and hasattr(node, key):
                        setattr(node, key, val)
                except ValueError:
                    pass
        self._editing_field = None
        self._edit_buffer = ""
        self._edit_cursor = 0
        self._edit_cursor_timer = 0.0

    def _cancel_editing(self):
        self._editing_field = None
        self._edit_buffer = ""
        self._edit_cursor = 0
        self._edit_cursor_timer = 0.0

    def _snapshot(self):
        state = json.dumps([n.to_dict() for n in self.nodes])
        if self.undo_stack and self.undo_stack[-1] == state:
            return
        self.undo_stack.append(state)
        self.redo_stack.clear()
        if len(self.undo_stack) > self.max_undo:
            self.undo_stack.pop(0)

    def _load_state_from(self, state):
        data = json.loads(state)
        self.nodes = []
        self.selected_node = None
        self.selected_nodes.clear()
        for d in data:
            t = d.get("type", "Cube")
            cls = self.NODE_TYPES.get(t)
            if cls:
                node = cls()
                node.from_dict(d)
                self.nodes.append(node)
        self._resolve_materials()

    def _undo(self):
        if not self.undo_stack:
            return
        current = json.dumps([n.to_dict() for n in self.nodes])
        self.redo_stack.append(current)
        state = self.undo_stack.pop()
        self._load_state_from(state)

    def _redo(self):
        if not self.redo_stack:
            return
        current = json.dumps([n.to_dict() for n in self.nodes])
        self.undo_stack.append(current)
        state = self.redo_stack.pop()
        self._load_state_from(state)

    def save_scene(self, path, show_message=True):
        mats_dict = {k: v.to_dict() for k, v in self.materials.items()}
        data = {"global_manager": self.global_manager.to_dict(),
                "nodes": [n.to_dict() for n in self.nodes],
                "materials": mats_dict}
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        if show_message:
            self._set_message(f"Saved: {os.path.basename(path)}")

    def load_scene(self, path):
        with open(path, "r") as f:
            data = json.load(f)
        if isinstance(data, dict) and "global_manager" in data:
            self.global_manager.from_dict(data["global_manager"])
            nodes_data = data.get("nodes", [])
            mats_data = data.get("materials", {})
        else:
            self.global_manager = GlobalManagerNode()
            nodes_data = data if isinstance(data, list) else []
            mats_data = {}
        self.nodes = []
        self.selected_node = None
        self.selected_nodes.clear()
        self._init_materials()
        for name, md in mats_data.items():
            mat = Material.from_dict(md)
            self.materials[name] = mat
        self._load_material_textures()
        for d in nodes_data:
            t = d.get("type", "Cube")
            cls = self.NODE_TYPES.get(t)
            if cls:
                node = cls()
                node.from_dict(d)
                self.nodes.append(node)
        self._sync_global_manager()
        self._resolve_materials()
        self._set_message(f"Loaded: {os.path.basename(path)}")
