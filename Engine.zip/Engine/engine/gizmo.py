import math
from OpenGL.GL import *
from OpenGL.GLU import *
from engine.math_utils import Vector3

GIZMO_X = (1, 0.25, 0.25)
GIZMO_Y = (0.25, 1, 0.25)
GIZMO_Z = (0.25, 0.45, 1)
GIZMO_HOVER = (1, 1, 0.3)

class Gizmo:
    def __init__(self):
        self.axis_len = 2.0
        self.axis_thickness = 0.1
        self.cone_radius = 0.18
        self.cone_height = 0.35
        self.hover_axis = None
        self.drag_axis = None
        self.drag_plane_point = None
        self.drag_offset = Vector3()
        self.mode = "translate"
        self.handle_dl = None
        self.scale_handle_dl = None
        self.rotate_handle_dl = None
        self._build_handle()
        self._build_scale_handle()
        self._build_rotate_handle()
    def _build_scale_handle(self):
        self.scale_handle_dl = glGenLists(1)
        glNewList(self.scale_handle_dl, GL_COMPILE)
        quad = gluNewQuadric()
        gluCylinder(quad, self.axis_thickness, self.axis_thickness, self.axis_len - 0.3, 12, 1)
        glTranslatef(0, 0, self.axis_len - 0.3)
        s = 0.15
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, -s); glVertex3f(s, -s, -s)
        glVertex3f(s, s, -s); glVertex3f(-s, s, -s)
        glEnd()
        glBegin(GL_LINE_LOOP)
        glVertex3f(-s, -s, s); glVertex3f(s, -s, s)
        glVertex3f(s, s, s); glVertex3f(-s, s, s)
        glEnd()
        for x1, y1, z1, x2, y2, z2 in [(-s,-s,-s,-s,-s,s),(s,-s,-s,s,-s,s),(s,s,-s,s,s,s),(-s,s,-s,-s,s,s)]:
            glBegin(GL_LINES)
            glVertex3f(x1, y1, z1); glVertex3f(x2, y2, z2)
            glEnd()
        gluDeleteQuadric(quad)
        glEndList()
    def _build_handle(self):
        self.handle_dl = glGenLists(1)
        glNewList(self.handle_dl, GL_COMPILE)
        quad = gluNewQuadric()
        gluCylinder(quad, self.axis_thickness, self.axis_thickness, self.axis_len - self.cone_height, 12, 1)
        glTranslatef(0, 0, self.axis_len - self.cone_height)
        gluCylinder(quad, self.cone_radius, 0.001, self.cone_height, 12, 1)
        gluDeleteQuadric(quad)
        glEndList()
    def _build_rotate_handle(self):
        self.rotate_handle_dl = glGenLists(1)
        glNewList(self.rotate_handle_dl, GL_COMPILE)
        glLineWidth(3)
        r = self.axis_len * 0.85
        glBegin(GL_LINE_LOOP)
        segs = 40
        for i in range(segs):
            a = 2 * math.pi * i / segs
            glVertex3f(math.cos(a) * r, math.sin(a) * r, 0)
        glEnd()
        glLineWidth(1)
        glEndList()
    def ray_axis_distance(self, ray_origin, ray_dir, axis_origin, axis_dir):
        w0 = ray_origin - axis_origin
        a = ray_dir.dot(ray_dir)
        b = ray_dir.dot(axis_dir)
        c = axis_dir.dot(axis_dir)
        d = ray_dir.dot(w0)
        e = axis_dir.dot(w0)
        denom = a * c - b * b
        if abs(denom) < 1e-8:
            return (w0 - w0.dot(axis_dir) * axis_dir).length(), 0, 0
        t_ray = (b * e - c * d) / denom
        t_axis = (a * e - b * d) / denom
        closest_ray = ray_origin + ray_dir * t_ray
        closest_axis = axis_origin + axis_dir * t_axis
        dist = (closest_ray - closest_axis).length()
        return dist, t_ray, t_axis
    def _ring_plane_hit(self, ray_origin, ray_dir, node_pos, ax_dir):
        denom = ray_dir.dot(ax_dir)
        if abs(denom) < 1e-8:
            return None
        t = (node_pos - ray_origin).dot(ax_dir) / denom
        if t <= 0:
            return None
        return ray_origin + ray_dir * t
    def hit_test(self, ray_origin, ray_dir, node_pos, scale=1.0, rot=None):
        self.hover_axis = None
        best_dist = 1e9
        best_axis = None
        base_axes = [(Vector3(1, 0, 0), GIZMO_X), (Vector3(0, 1, 0), GIZMO_Y), (Vector3(0, 0, 1), GIZMO_Z)]
        axes = self._rotate_axes(base_axes, rot)
        if self.mode == "rotate":
            ring_r = self.axis_len * 0.85 * scale
            threshold = 0.45 * scale
            for i, (ax_dir, col) in enumerate(axes):
                hit = self._ring_plane_hit(ray_origin, ray_dir, node_pos, ax_dir)
                if hit is not None:
                    r = (hit - node_pos).length()
                    ring_dist = abs(r - ring_r)
                    if ring_dist < threshold and ring_dist < best_dist:
                        best_dist = ring_dist
                        best_axis = i
        else:
            for i, (ax_dir, col) in enumerate(axes):
                dist, tr, ta = self.ray_axis_distance(ray_origin, ray_dir, node_pos, ax_dir)
                if 0 <= ta <= self.axis_len * scale and tr > 0 and dist < 0.4 * scale:
                    best_dist = dist
                    best_axis = i
        if best_axis is not None:
            self.hover_axis = best_axis
            return best_axis
        return None
    def start_drag(self, ray_origin, ray_dir, node_pos, axis_idx, rot=None):
        self.drag_axis = axis_idx
        base_axes = [Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1)]
        rotated = self._rotate_axes([(a, None) for a in base_axes], rot)
        self.drag_axis_dir = rotated[axis_idx][0]
        if self.mode == "rotate":
            hit = self._ring_plane_hit(ray_origin, ray_dir, node_pos, self.drag_axis_dir)
            self.drag_plane_point = hit if hit is not None else node_pos
        else:
            _, _, t_ax = self.ray_axis_distance(ray_origin, ray_dir, node_pos, self.drag_axis_dir)
            self.drag_plane_point = node_pos + self.drag_axis_dir * t_ax
    def update_drag(self, ray_origin, ray_dir, node_pos, axis_idx, rot=None):
        ax_dir = self.drag_axis_dir
        if self.mode == "rotate":
            new_point = self._ring_plane_hit(ray_origin, ray_dir, node_pos, ax_dir)
            if new_point is None:
                return 0
            old_vec = self.drag_plane_point - node_pos
            new_vec = new_point - node_pos
            cross_x = old_vec.y * new_vec.z - old_vec.z * new_vec.y
            cross_y = old_vec.z * new_vec.x - old_vec.x * new_vec.z
            cross_z = old_vec.x * new_vec.y - old_vec.y * new_vec.x
            sign = 1 if cross_x * ax_dir.x + cross_y * ax_dir.y + cross_z * ax_dir.z > 0 else -1
            old_len = old_vec.length()
            new_len = new_vec.length()
            if old_len > 0.001 and new_len > 0.001:
                cos_a = old_vec.dot(new_vec) / (old_len * new_len)
                cos_a = max(-1, min(1, cos_a))
                angle = math.degrees(math.acos(cos_a) * sign)
            else:
                angle = 0
            self.drag_plane_point = new_point
            return angle
        else:
            _, _, t_ax = self.ray_axis_distance(ray_origin, ray_dir, node_pos, ax_dir)
            new_point = node_pos + ax_dir * t_ax
            delta = (new_point - self.drag_plane_point).dot(ax_dir)
            self.drag_plane_point = new_point
            return delta
    def end_drag(self):
        self.drag_axis = None
    def _rotate_axes(self, axes, rot):
        if rot is None:
            return axes
        rx, ry, rz = math.radians(rot.x), math.radians(rot.y), math.radians(rot.z)
        cx, sx = math.cos(rx), math.sin(rx)
        cy, sy = math.cos(ry), math.sin(ry)
        cz, sz = math.cos(rz), math.sin(rz)
        def rotate_vec(v):
            x = v.x * (cy*cz) + v.y * (sx*sy*cz - cx*sz) + v.z * (cx*sy*cz + sx*sz)
            y = v.x * (cy*sz) + v.y * (sx*sy*sz + cx*cz) + v.z * (cx*sy*sz - sx*cz)
            z = v.x * (-sy) + v.y * (sx*cy) + v.z * (cx*cy)
            return Vector3(x, y, z)
        return [(rotate_vec(d), c) for d, c in axes]
    def draw(self, pos, scale=1.0, rot=None):
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)
        glPushMatrix()
        glTranslatef(pos.x, pos.y, pos.z)
        if rot is not None:
            glRotatef(rot.z, 0, 0, 1)
            glRotatef(rot.y, 0, 1, 0)
            glRotatef(rot.x, 1, 0, 0)
        base_axes = [
            (Vector3(1, 0, 0), GIZMO_X),
            (Vector3(0, 1, 0), GIZMO_Y),
            (Vector3(0, 0, 1), GIZMO_Z),
        ]
        for i, (ax_dir, col) in enumerate(base_axes):
            if self.hover_axis == i or self.drag_axis == i:
                glColor3f(*GIZMO_HOVER)
            else:
                glColor3f(*col)
            glPushMatrix()
            if ax_dir.x: glRotatef(90, 0, 1, 0)
            elif ax_dir.y: glRotatef(-90, 1, 0, 0)
            glScalef(scale, scale, scale)
            if self.mode == "translate":
                dl = self.handle_dl
            elif self.mode == "scale":
                dl = self.scale_handle_dl
            else:
                dl = self.rotate_handle_dl
            glCallList(dl)
            glPopMatrix()
        glPopMatrix()
        glEnable(GL_DEPTH_TEST)
